package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.model.AcademicStream
import com.example.data.model.AppLanguage
import com.google.firebase.firestore.FirebaseFirestoreException
import java.util.UUID
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class BacMateRepositoryRuleTest : FirestoreEmulatorTestBase() {

    private fun uniqueEmail(prefix: String): String =
        "${prefix}_${UUID.randomUUID().toString().replace("-", "").take(10)}@test.com"

    @Test
    fun createInitialProfile_and_observeUserProfile_succeedsForOwner() = runBlocking {
        val uid = signInTestUser(uniqueEmail("alice"))
        val repository = BacMateRepository(firestore, auth)

        val result = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.createInitialProfile(
                displayName = "ياسين بن عمر",
                examYear = 2026,
                stream = AcademicStream.SCIENCES_EXP,
                language = AppLanguage.AR,
                dailyGoalMinutes = 90
            )
        }
        assertTrue("Expected createInitialProfile to succeed, got ${result.exceptionOrNull()}", result.isSuccess)

        val observed = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeUserProfile(uid).first { it != null }
        }
        assertNotNull(observed)
        assertEquals("ياسين بن عمر", observed?.displayName)
        assertEquals(90, observed?.dailyGoalMinutes)
    }

    @Test
    fun recordQuizAttempt_and_createStudyTask_emitsRealtimeUpdates() = runBlocking {
        val uid = signInTestUser(uniqueEmail("student"))
        val repository = BacMateRepository(firestore, auth)

        val attemptRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.recordQuizAttempt(
                subjectId = "math",
                lessonId = "math_limits",
                mode = "PRACTICE",
                totalQuestions = 5,
                correctCount = 4,
                durationSeconds = 240
            )
        }
        assertTrue(attemptRes.isSuccess)
        val attemptId = attemptRes.getOrThrow()

        val attempts = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeQuizAttempts(uid).first { list -> list.any { it.id == attemptId } }
        }
        assertTrue(attempts.any { it.id == attemptId && it.scorePercent == 80 })

        val taskRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.createStudyTask(
                title = "حل بكالوريا تجريبية في الفيزياء",
                subjectId = "physics",
                dayOfWeek = "MON",
                durationMinutes = 60,
                priority = "HIGH"
            )
        }
        assertTrue(taskRes.isSuccess)
        val taskId = taskRes.getOrThrow()

        val tasks = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeStudyTasks(uid).first { list -> list.any { it.id == taskId } }
        }
        assertTrue(tasks.any { it.id == taskId })
    }

    @Test
    fun getUserProfileById_crossUserAccess_failsWithPermissionDenied() = runBlocking {
        val aliceUid = signInTestUser(uniqueEmail("owner"))
        val aliceRepo = BacMateRepository(firestore, auth)
        withTimeout(DEFAULT_TIMEOUT_MS) {
            aliceRepo.createInitialProfile(displayName = "Alice Student").getOrThrow()
        }

        signInTestUser(uniqueEmail("intruder"))
        val bobRepo = BacMateRepository(firestore, auth)
        val crossResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            bobRepo.getUserProfileById(aliceUid)
        }
        assertTrue(crossResult.isFailure)
        val firestoreEx = crossResult.exceptionOrNull()?.unwrapFirestoreException()
        assertNotNull(firestoreEx)
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreEx?.code)
    }

    @Test
    fun observeStudyTasks_unauthenticatedUser_failsWithPermissionDenied() = runBlocking {
        val aliceUid = signInTestUser(uniqueEmail("unauth"))
        auth.signOut()
        val repository = BacMateRepository(firestore, auth)

        var caught: Exception? = null
        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                repository.observeStudyTasks(aliceUid).first()
            }
        } catch (e: Exception) {
            caught = e
        }
        assertNotNull("Expected exception when observing while signed out", caught)
        val firestoreException = checkNotNull(caught?.unwrapFirestoreException()) {
            "Expected nested FirebaseFirestoreException, got $caught"
        }
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreException.code)
    }

    private companion object {
        const val DEFAULT_TIMEOUT_MS = 5000L
        const val FLOW_TIMEOUT_MS = 3000L
    }
}
