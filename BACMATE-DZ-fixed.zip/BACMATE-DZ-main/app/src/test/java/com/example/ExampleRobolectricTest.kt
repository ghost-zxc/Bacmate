package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.AcademicStream
import com.example.data.model.BacAnalyticsEngine
import com.example.data.model.DifficultyLevel
import com.example.data.model.QuizAttempt
import com.example.data.model.SpacedRepetitionSm2
import com.example.data.model.WeaknessStatus
import com.example.data.seed.AlgerianCurriculumSeed
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read app_name string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("BacMate DZ", appName)
    }

    @Test
    fun `curriculum seed contains over 1000 verified questions ordered from first unit to last unit`() {
        val questions = AlgerianCurriculumSeed.verifiedQuestions
        assertTrue("Expected > 1000 verified questions, found ${questions.size}", questions.size >= 1000)

        questions.forEach { q ->
            assertTrue("Question ${q.id} stemAr blank", q.stemAr.isNotBlank())
            assertTrue("Question ${q.id} stemFr blank", q.stemFr.isNotBlank())
            assertTrue("Question ${q.id} explanationAr blank", q.explanationAr.isNotBlank())
            assertTrue("Question ${q.id} explanationFr blank", q.explanationFr.isNotBlank())
            assertTrue("Question ${q.id} pedagogicalHintAr blank", q.pedagogicalHintAr.isNotBlank())
            assertTrue("Question ${q.id} distractorAnalysisAr blank", q.distractorAnalysisAr(setOf(0)).isNotBlank())
            assertTrue("Question ${q.id} sourceCitationAr blank", q.sourceCitationAr.isNotBlank())
            assertTrue("Question ${q.id} curriculumMappingAr blank", q.curriculumMappingAr.isNotBlank())
            assertTrue("Question ${q.id} correctIndices empty", q.correctIndices.isNotEmpty())
            q.correctIndices.forEach { idx ->
                assertTrue("Question ${q.id} index out of bounds", idx in q.optionsAr.indices)
            }
        }

        // Verify strict sequential unit ordering (Unit 01 -> Last Unit) for SVT, Physics, and Math
        listOf("svt", "physics", "math").forEach { subjectId ->
            val subject = AlgerianCurriculumSeed.subjects.first { it.id == subjectId }
            val unitByLessonId = subject.lessons.associate { it.id to it.unitNumber }
            val orderedSubjectQuestions = AlgerianCurriculumSeed.questionsForSubject(
                subjectId = subjectId,
                lessonId = null
            )
            assertTrue("Subject $subjectId should have questions", orderedSubjectQuestions.size >= 300)

            var lastSeenUnit = 1
            orderedSubjectQuestions.forEach { q ->
                val unitNumber = unitByLessonId[q.lessonId] ?: 1
                assertTrue(
                    "Questions for $subjectId must be ordered from Unit 1 to Last Unit (saw $unitNumber after $lastSeenUnit)",
                    unitNumber >= lastSeenUnit
                )
                lastSeenUnit = unitNumber
            }

            // Verify unit selection returns questions exclusively for the chosen unit
            val firstUnit = subject.lessons.minByOrNull { it.unitNumber }!!
            val lastUnit = subject.lessons.maxByOrNull { it.unitNumber }!!
            val firstUnitQuestions = AlgerianCurriculumSeed.questionsForSubject(
                subjectId = subjectId,
                lessonId = firstUnit.id
            )
            val lastUnitQuestions = AlgerianCurriculumSeed.questionsForSubject(
                subjectId = subjectId,
                lessonId = lastUnit.id
            )
            assertEquals(45, firstUnitQuestions.size)
            assertEquals(45, lastUnitQuestions.size)
            assertTrue(firstUnitQuestions.all { it.lessonId == firstUnit.id })
            assertTrue(lastUnitQuestions.all { it.lessonId == lastUnit.id })
        }
    }

    @Test
    fun `spaced repetition SM2 increases interval on high quality and resets on failure`() {
        val q = AlgerianCurriculumSeed.verifiedQuestions.first()
        val firstReview = SpacedRepetitionSm2.computeNextReview(
            current = null,
            userId = "student_1",
            question = q,
            quality = 5,
            todayEpochDay = 20000
        )
        assertEquals(1, firstReview.repetitionCount)
        assertEquals(1, firstReview.intervalDays)

        val secondReview = SpacedRepetitionSm2.computeNextReview(
            current = firstReview,
            userId = "student_1",
            question = q,
            quality = 5,
            todayEpochDay = 20001
        )
        assertEquals(2, secondReview.repetitionCount)
        assertEquals(3, secondReview.intervalDays)

        val thirdReview = SpacedRepetitionSm2.computeNextReview(
            current = secondReview,
            userId = "student_1",
            question = q,
            quality = 5,
            todayEpochDay = 20004
        )
        assertEquals(3, thirdReview.repetitionCount)
        assertTrue(thirdReview.intervalDays >= 4)
        assertTrue(thirdReview.mastered)

        val failedReview = SpacedRepetitionSm2.computeNextReview(
            current = thirdReview,
            userId = "student_1",
            question = q,
            quality = 1,
            todayEpochDay = 20010
        )
        assertEquals(0, failedReview.repetitionCount)
        assertEquals(1, failedReview.intervalDays)
        assertFalse(failedReview.mastered)

        val periodicMastered = SpacedRepetitionSm2.markAsMasteredWithPeriodicReview(
            current = failedReview,
            userId = "student_1",
            question = q,
            todayEpochDay = 20015
        )
        assertTrue(periodicMastered.mastered)
        assertTrue(periodicMastered.intervalDays >= 14)
    }

    @Test
    fun `daily challenge is deterministic for a given date and stream and weakness engine distinguishes sample size`() {
        val allQ = AlgerianCurriculumSeed.verifiedQuestions
        val testDate = java.time.LocalDate.of(2026, 5, 15)
        val challengeA = BacAnalyticsEngine.getDailyChallengeQuestions(
            stream = AcademicStream.SCIENCES_EXP,
            allQuestions = allQ,
            difficultyFilter = DifficultyLevel.BAC_LEVEL,
            date = testDate,
            count = 7
        )
        val challengeB = BacAnalyticsEngine.getDailyChallengeQuestions(
            stream = AcademicStream.SCIENCES_EXP,
            allQuestions = allQ,
            difficultyFilter = DifficultyLevel.BAC_LEVEL,
            date = testDate,
            count = 7
        )
        assertEquals(7, challengeA.size)
        assertEquals(challengeA.map { it.id }, challengeB.map { it.id })

        val subjects = AlgerianCurriculumSeed.subjectsForStream(AcademicStream.SCIENCES_EXP)
        // 1. With no attempts -> all subjects report INSUFFICIENT_DATA (< 3 questions)
        val emptyInsights = BacAnalyticsEngine.analyzeWeaknesses(
            stream = AcademicStream.SCIENCES_EXP,
            subjects = subjects,
            attempts = emptyList(),
            reviews = emptyList()
        )
        assertTrue(emptyInsights.all { it.status == WeaknessStatus.INSUFFICIENT_DATA })

        // 2. With 10 questions and 2 correct in SVT -> CRITICAL_WEAKNESS (20% < 50%)
        val svtWeakAttempt = QuizAttempt(
            id = "att_1",
            userId = "u1",
            subjectId = "svt",
            lessonId = "svt_protein",
            mode = "PRACTICE",
            totalQuestions = 10,
            correctCount = 2,
            scorePercent = 20,
            bacScoreTimes10 = 40,
            durationSeconds = 300
        )
        val updatedInsights = BacAnalyticsEngine.analyzeWeaknesses(
            stream = AcademicStream.SCIENCES_EXP,
            subjects = subjects,
            attempts = listOf(svtWeakAttempt),
            reviews = emptyList()
        )
        val svtInsight = updatedInsights.first { it.subjectId == "svt" }
        assertEquals(WeaknessStatus.CRITICAL_WEAKNESS, svtInsight.status)
        assertEquals(20, svtInsight.accuracyPercent)
    }

    @Test
    fun `subjectsForStream orders subjects by official stream coefficient`() {
        val mathOrdered = AlgerianCurriculumSeed.subjectsForStream(AcademicStream.MATH)
        assertEquals("math", mathOrdered.first().id)
        assertEquals(7, mathOrdered.first().coefficientFor(AcademicStream.MATH))
    }
}
