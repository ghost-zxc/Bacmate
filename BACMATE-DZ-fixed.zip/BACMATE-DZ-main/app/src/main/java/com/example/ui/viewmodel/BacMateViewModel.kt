package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AcademicStream
import com.example.data.model.AiTutorMode
import com.example.data.model.AppLanguage
import com.example.data.model.BacAnalyticsEngine
import com.example.data.model.CommunityQuestion
import com.example.data.model.DifficultyLevel
import com.example.data.model.Lesson
import com.example.data.model.Question
import com.example.data.model.QuestionProvenance
import com.example.data.model.QuestionType
import com.example.data.model.QuizAttempt
import com.example.data.model.ReviewItem
import com.example.data.model.SpacedRepetitionSm2
import com.example.data.model.StudyTask
import com.example.data.model.Subject
import com.example.data.model.SubscriptionTier
import com.example.data.model.UserProfile
import com.example.data.repository.BacMateRepository
import com.example.data.seed.AlgerianCurriculumSeed
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.generationConfig
import java.time.LocalDate
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout
import org.json.JSONArray
import org.json.JSONObject

private const val TAG = "BacMateViewModel"

sealed interface DataUiState<out T> {
    data object Loading : DataUiState<Nothing>
    data class Success<T>(val data: T) : DataUiState<T>
    data class Error(val message: String) : DataUiState<Nothing>
}

sealed interface AiGenerationState {
    data object Idle : AiGenerationState
    data object Loading : AiGenerationState
    data class ExplanationReady(val questionId: String, val text: String) : AiGenerationState
    data class TutorResponseReady(
        val lessonId: String,
        val modeLabel: String,
        val responseText: String
    ) : AiGenerationState
    data class QuestionGenerated(val question: Question) : AiGenerationState
    data class Error(val message: String) : AiGenerationState
}

data class ActiveQuizSession(
    val titleAr: String,
    val titleFr: String,
    val subjectId: String,
    val lessonId: String,
    val mode: String, // PRACTICE, TIMED_EXAM, SPACED_REVIEW
    val questions: List<Question>,
    val currentIndex: Int = 0,
    val selectedIndicesByQuestion: Map<String, Set<Int>> = emptyMap(),
    val verifiedQuestionIds: Set<String> = emptySet(),
    val revealedHintIds: Set<String> = emptySet(),
    val selfAssessedRubricSteps: Map<String, Set<Int>> = emptyMap(),
    val elapsedSeconds: Int = 0,
    val timeLimitSeconds: Int? = null,
    val isDailyChallenge: Boolean = false,
    val isDailyChallengeRepeat: Boolean = false,
    val isFinished: Boolean = false
) {
    val currentQuestion: Question?
        get() = questions.getOrNull(currentIndex)

    val answeredCount: Int
        get() = selectedIndicesByQuestion.count { it.value.isNotEmpty() }

    val evaluatedTotal: Int
        get() = if (mode == "TIMED_EXAM" || isDailyChallenge) {
            questions.size.coerceAtLeast(1)
        } else {
            answeredCount.coerceAtLeast(1).coerceAtMost(questions.size.coerceAtLeast(1))
        }

    val correctCount: Int
        get() = questions.count { q ->
            val selected = selectedIndicesByQuestion[q.id] ?: emptySet()
            selected.isNotEmpty() && selected == q.correctIndices.toSet()
        }

    val scorePercent: Int
        get() = ((correctCount * 100.0) / evaluatedTotal).toInt().coerceIn(0, 100)

    val bacGradeOutOf20: Double
        get() = ((correctCount * 20.0) / evaluatedTotal).coerceIn(0.0, 20.0)
}

class BacMateViewModel(
    private val repository: BacMateRepository,
    private val currentUserId: String,
    private val currentUserEmail: String?
) : ViewModel() {

    val isCurrentUserAdmin: Boolean =
        currentUserEmail?.equals("younesdjeridane@gmail.com", ignoreCase = true) == true

    // Two-tier Flow error handling for all Firestore streams
    val profileState: StateFlow<DataUiState<UserProfile?>> = repository.observeUserProfile(currentUserId)
        .map<UserProfile?, DataUiState<UserProfile?>> { DataUiState.Success(it) }
        .catch { e ->
            Log.w(TAG, "Error observing profile", e)
            emit(DataUiState.Error(e.localizedMessage ?: "تعذر تحميل الملف الشخصي"))
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), DataUiState.Loading)

    val attemptsState: StateFlow<DataUiState<List<QuizAttempt>>> = repository.observeQuizAttempts(currentUserId)
        .map<List<QuizAttempt>, DataUiState<List<QuizAttempt>>> { DataUiState.Success(it) }
        .catch { e ->
            Log.w(TAG, "Error observing quiz attempts", e)
            emit(DataUiState.Error(e.localizedMessage ?: "تعذر تحميل سجل الاختبارات"))
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), DataUiState.Loading)

    val reviewsState: StateFlow<DataUiState<List<ReviewItem>>> = repository.observeReviewItems(currentUserId)
        .map<List<ReviewItem>, DataUiState<List<ReviewItem>>> { DataUiState.Success(it) }
        .catch { e ->
            Log.w(TAG, "Error observing reviews", e)
            emit(DataUiState.Error(e.localizedMessage ?: "تعذر تحميل كراس الأخطاء"))
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), DataUiState.Loading)

    val studyTasksState: StateFlow<DataUiState<List<StudyTask>>> = repository.observeStudyTasks(currentUserId)
        .map<List<StudyTask>, DataUiState<List<StudyTask>>> { DataUiState.Success(it) }
        .catch { e ->
            Log.w(TAG, "Error observing study tasks", e)
            emit(DataUiState.Error(e.localizedMessage ?: "تعذر تحميل المخطط الدراسي"))
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), DataUiState.Loading)

    val approvedCommunityQuestionsState: StateFlow<List<CommunityQuestion>> =
        repository.observeApprovedCommunityQuestions()
            .catch { e ->
                Log.w(TAG, "Error observing approved community questions", e)
                emit(emptyList())
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val mySubmittedQuestionsState: StateFlow<List<CommunityQuestion>> =
        repository.observeMySubmittedQuestions(currentUserId)
            .catch { e ->
                Log.w(TAG, "Error observing user submitted questions", e)
                emit(emptyList())
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    private val _activeQuiz = MutableStateFlow<ActiveQuizSession?>(null)
    val activeQuiz: StateFlow<ActiveQuizSession?> = _activeQuiz.asStateFlow()

    private val _aiState = MutableStateFlow<AiGenerationState>(AiGenerationState.Idle)
    val aiState: StateFlow<AiGenerationState> = _aiState.asStateFlow()

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    // Student preferences & bookmarks (persisted across session)
    private val _bookmarkedLessonIds = MutableStateFlow<Set<String>>(setOf("svt_protein", "math_limits", "phys_kinetics"))
    val bookmarkedLessonIds: StateFlow<Set<String>> = _bookmarkedLessonIds.asStateFlow()

    private val _leaderboardOptIn = MutableStateFlow(true)
    val leaderboardOptIn: StateFlow<Boolean> = _leaderboardOptIn.asStateFlow()

    private val _quietHoursEnabled = MutableStateFlow(true)
    val quietHoursEnabled: StateFlow<Boolean> = _quietHoursEnabled.asStateFlow()

    private val _blockedChallengePeers = MutableStateFlow<Set<String>>(emptySet())
    val blockedChallengePeers: StateFlow<Set<String>> = _blockedChallengePeers.asStateFlow()

    private var timerJob: Job? = null

    // Lazy Firebase AI Logic initialization per skill mandate
    private val explanationModel by lazy {
        runCatching { Firebase.ai.generativeModel("gemini-3.8-flash") }.getOrNull()
    }

    private val structuredQuestionSchema by lazy {
        Schema.obj(
            properties = mapOf(
                "stemAr" to Schema.string(description = "Arabic question stem following Algerian Baccalaureate curriculum"),
                "stemFr" to Schema.string(description = "French translation of the question stem"),
                "optionsAr" to Schema.array(
                    items = Schema.string(),
                    description = "Exactly 4 Arabic answer options"
                ),
                "optionsFr" to Schema.array(
                    items = Schema.string(),
                    description = "Exactly 4 French answer options"
                ),
                "correctIndex" to Schema.integer(description = "Zero-based index (0..3) of the verified correct option"),
                "explanationAr" to Schema.string(description = "Detailed step-by-step Arabic explanation"),
                "explanationFr" to Schema.string(description = "Detailed step-by-step French explanation"),
                "curriculumMapping" to Schema.string(description = "Algerian curriculum unit and competency reference")
            )
        )
    }

    private val questionGeneratorModel by lazy {
        runCatching {
            Firebase.ai.generativeModel(
                modelName = "gemini-3.8-flash",
                generationConfig = generationConfig {
                    responseMimeType = "application/json"
                    responseSchema = structuredQuestionSchema
                }
            )
        }.getOrNull()
    }

    fun clearBanner() {
        _statusBanner.value = null
    }

    fun clearAiState() {
        _aiState.value = AiGenerationState.Idle
    }

    fun toggleLessonBookmark(lessonId: String) {
        val current = _bookmarkedLessonIds.value
        _bookmarkedLessonIds.value = if (lessonId in current) current - lessonId else current + lessonId
    }

    fun toggleLeaderboardOptIn() {
        _leaderboardOptIn.value = !_leaderboardOptIn.value
        _statusBanner.value = if (_leaderboardOptIn.value) {
            "تم تفعيل المشاركة بالاسم المستعار في لوحة المنافسة الأسبوعية"
        } else {
            "تم إخفاء اسمك من لوحة المنافسة العامة (الوضع الخاص)"
        }
    }

    fun toggleQuietHours() {
        _quietHoursEnabled.value = !_quietHoursEnabled.value
    }

    fun reportOrBlockPeer(peerAlias: String) {
        if (peerAlias.isBlank()) return
        _blockedChallengePeers.value = _blockedChallengePeers.value + peerAlias.trim()
        _statusBanner.value = "تم حظر المستخدم ($peerAlias) وإرسال بلاغ للمراجعة."
    }

    // -----------------------------------------------------------------------
    // Onboarding & Profile Updates
    // -----------------------------------------------------------------------

    fun completeOnboarding(
        displayName: String,
        examYear: Int,
        stream: AcademicStream,
        language: AppLanguage,
        dailyGoalMinutes: Int
    ) {
        viewModelScope.launch {
            val result = repository.createInitialProfile(
                displayName = displayName,
                examYear = examYear,
                stream = stream,
                language = language,
                dailyGoalMinutes = dailyGoalMinutes
            )
            if (result.isFailure) {
                _statusBanner.value = result.exceptionOrNull()?.localizedMessage ?: "تعذر حفظ إعدادات البداية"
            } else {
                repository.createStudyTask(
                    title = "مراجعة الوحدة الأولى وحل اختبار تشخيصي",
                    subjectId = "math",
                    dayOfWeek = "SUN",
                    durationMinutes = 45,
                    priority = "HIGH"
                )
            }
        }
    }

    fun updatePreferences(
        existingProfile: UserProfile,
        displayName: String = existingProfile.displayName,
        examYear: Int = existingProfile.examYear,
        stream: AcademicStream = AcademicStream.fromId(existingProfile.academicStream),
        language: AppLanguage = AppLanguage.fromCode(existingProfile.language),
        dailyGoalMinutes: Int = existingProfile.dailyGoalMinutes
    ) {
        viewModelScope.launch {
            val res = repository.updateProfilePreferences(
                existingProfile = existingProfile,
                displayName = displayName,
                examYear = examYear,
                stream = stream,
                language = language,
                dailyGoalMinutes = dailyGoalMinutes
            )
            if (res.isSuccess) {
                _statusBanner.value = "تم تحديث إعدادات الحساب بنجاح"
            } else {
                _statusBanner.value = res.exceptionOrNull()?.localizedMessage ?: "تعذر تحديث الإعدادات"
            }
        }
    }

    // -----------------------------------------------------------------------
    // Daily Challenge & Advanced Quiz / Timed Exam Engine
    // -----------------------------------------------------------------------

    fun startDailyChallengeSession(
        currentProfile: UserProfile?,
        difficultyFilter: DifficultyLevel? = null
    ): Boolean {
        val stream = AcademicStream.fromId(currentProfile?.academicStream ?: AcademicStream.SCIENCES_EXP.id)
        val approvedExtra = approvedCommunityQuestionsState.value.map { it.toDomainQuestion() }
        val allPool = AlgerianCurriculumSeed.allQuestions(approvedExtra)
        val dailyQuestions = BacAnalyticsEngine.getDailyChallengeQuestions(
            stream = stream,
            allQuestions = allPool,
            difficultyFilter = difficultyFilter,
            count = 7
        )

        val todayChallengeId = BacAnalyticsEngine.dailyChallengeIdForDate()
        val existingAttempts = (attemptsState.value as? DataUiState.Success)?.data.orEmpty()
        val alreadyCompletedToday = existingAttempts.any { it.lessonId == todayChallengeId }

        if (alreadyCompletedToday) {
            _statusBanner.value =
                "لقد أنجزت التحدي اليومي لهذا اليوم بنجاح! يمكنك إعادة حله للمراجعة دون احتساب نقاط مكررة."
        }

        _activeQuiz.value = ActiveQuizSession(
            titleAr = "التحدي اليومي الموحد (7 أسئلة) — شعبة ${stream.titleAr}",
            titleFr = "Défi Quotidien Officiel (7 questions) — ${stream.titleFr}",
            subjectId = dailyQuestions.firstOrNull()?.subjectId ?: "math",
            lessonId = todayChallengeId,
            mode = "PRACTICE",
            questions = dailyQuestions,
            timeLimitSeconds = dailyQuestions.size * 75,
            isDailyChallenge = true,
            isDailyChallengeRepeat = alreadyCompletedToday
        )
        startSessionTimer()
        return true
    }

    fun startSingleQuestionRetry(question: Question) {
        _activeQuiz.value = ActiveQuizSession(
            titleAr = "إعادة محاولة سؤال من كراس الأخطاء",
            titleFr = "Réessayer une question du carnet d'erreurs",
            subjectId = question.subjectId,
            lessonId = question.lessonId,
            mode = "SPACED_REVIEW",
            questions = listOf(question),
            timeLimitSeconds = null
        )
        startSessionTimer()
    }

    fun startQuizSession(
        subject: Subject?,
        lessonId: String?,
        mode: String, // PRACTICE, TIMED_EXAM, SPACED_REVIEW
        currentProfile: UserProfile?,
        difficultyFilter: DifficultyLevel? = null,
        shuffleQuestions: Boolean = false
    ): Boolean {
        val tier = SubscriptionTier.fromId(currentProfile?.subscriptionTier ?: "FREE")
        val todayStr = LocalDate.now().toString()
        val usedToday = if (currentProfile?.lastActiveDate == todayStr) {
            currentProfile.dailyQuizzesUsedToday
        } else {
            0
        }

        if (!tier.isPremium && usedToday >= tier.dailyQuizLimit && mode != "SPACED_REVIEW") {
            _statusBanner.value =
                "لقد استنفدت الحصة اليومية المجانية (${tier.dailyQuizLimit} اختبارات/يوم). يمكنك مراجعة كراس الأخطاء مجاناً أو الترقية إلى باقة الامتياز."
            return false
        }

        val approvedExtra = approvedCommunityQuestionsState.value.map { it.toDomainQuestion() }
        val selectedLesson = subject?.lessons?.find { it.id == lessonId }
            ?: AlgerianCurriculumSeed.subjects.flatMap { it.lessons }.find { it.id == lessonId }

        val baseOrderedPool = when {
            mode == "SPACED_REVIEW" -> {
                val allPool = AlgerianCurriculumSeed.allQuestions(approvedExtra)
                val reviewList = (reviewsState.value as? DataUiState.Success)?.data.orEmpty()
                val dueIds = reviewList.filter { !it.mastered }.map { it.questionId }.toSet()
                val matched = allPool.filter { it.id in dueIds }
                matched.ifEmpty { allPool.take(10) }
            }
            lessonId != null -> {
                AlgerianCurriculumSeed.questionsForLesson(lessonId, approvedExtra).ifEmpty {
                    subject?.let { AlgerianCurriculumSeed.questionsForSubject(it.id, approvedExtra) }.orEmpty()
                }
            }
            subject != null -> {
                AlgerianCurriculumSeed.questionsForSubject(subject.id, approvedExtra)
            }
            else -> AlgerianCurriculumSeed.allQuestions(approvedExtra)
        }.ifEmpty { AlgerianCurriculumSeed.verifiedQuestions }

        val filteredPool = if (difficultyFilter != null) {
            baseOrderedPool.filter { it.difficulty == difficultyFilter }.ifEmpty { baseOrderedPool }
        } else {
            baseOrderedPool
        }

        val orderedOrShuffled = if (shuffleQuestions) filteredPool.shuffled() else filteredPool

        val finalQuestions = if (mode == "TIMED_EXAM") {
            orderedOrShuffled.take(20)
        } else {
            orderedOrShuffled
        }

        val timeLimit = if (mode == "TIMED_EXAM") finalQuestions.size * 90 else null
        val unitLabelAr = selectedLesson?.let { " — الوحدة 0${it.unitNumber}: ${it.titleAr}" }.orEmpty()
        val unitLabelFr = selectedLesson?.let { " — Unité 0${it.unitNumber} : ${it.titleFr}" }.orEmpty()
        val diffBadgeAr = difficultyFilter?.let { " [${it.labelAr}]" }.orEmpty()

        _activeQuiz.value = ActiveQuizSession(
            titleAr = when (mode) {
                "TIMED_EXAM" -> "امتحان بكالوريا مؤقت — ${subject?.nameAr ?: "شامل"}$unitLabelAr$diffBadgeAr"
                "SPACED_REVIEW" -> "جلسة التكرار المتباعد (SM-2) — كراس الأخطاء"
                else -> "سلسلة التدرج المرتبة — ${subject?.nameAr ?: "شامل"}$unitLabelAr$diffBadgeAr"
            },
            titleFr = when (mode) {
                "TIMED_EXAM" -> "Examen Blanc Chronométré — ${subject?.nameFr ?: "Général"}$unitLabelFr"
                "SPACED_REVIEW" -> "Révision Espacée (SM-2) — Carnet d'erreurs"
                else -> "Série progressive ordonnée — ${subject?.nameFr ?: "Général"}$unitLabelFr"
            },
            subjectId = subject?.id ?: selectedLesson?.subjectId ?: "math",
            lessonId = lessonId ?: (subject?.lessons?.firstOrNull()?.id ?: "math_limits"),
            mode = mode,
            questions = finalQuestions,
            timeLimitSeconds = timeLimit
        )

        startSessionTimer()
        return true
    }

    private fun startSessionTimer() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (true) {
                delay(1000L)
                val session = _activeQuiz.value ?: break
                if (session.isFinished) break
                val nextElapsed = session.elapsedSeconds + 1
                val limit = session.timeLimitSeconds
                if (limit != null && nextElapsed >= limit) {
                    _activeQuiz.value = session.copy(elapsedSeconds = limit)
                    finishQuizSession()
                    break
                } else {
                    _activeQuiz.value = session.copy(elapsedSeconds = nextElapsed)
                }
            }
        }
    }

    fun toggleOptionSelection(optionIndex: Int) {
        val session = _activeQuiz.value ?: return
        val question = session.currentQuestion ?: return
        if (session.mode != "TIMED_EXAM" && question.id in session.verifiedQuestionIds) return

        val existing = session.selectedIndicesByQuestion[question.id] ?: emptySet()
        val updatedSelection = if (question.type == QuestionType.MULTIPLE_CHOICE) {
            if (optionIndex in existing) existing - optionIndex else existing + optionIndex
        } else {
            setOf(optionIndex)
        }

        _activeQuiz.value = session.copy(
            selectedIndicesByQuestion = session.selectedIndicesByQuestion + (question.id to updatedSelection)
        )
    }

    fun revealHintForCurrentQuestion() {
        val session = _activeQuiz.value ?: return
        val question = session.currentQuestion ?: return
        _activeQuiz.value = session.copy(
            revealedHintIds = session.revealedHintIds + question.id
        )
    }

    fun toggleSelfAssessedRubricStep(questionId: String, stepIndex: Int) {
        val session = _activeQuiz.value ?: return
        val currentSteps = session.selfAssessedRubricSteps[questionId] ?: emptySet()
        val updated = if (stepIndex in currentSteps) currentSteps - stepIndex else currentSteps + stepIndex
        _activeQuiz.value = session.copy(
            selfAssessedRubricSteps = session.selfAssessedRubricSteps + (questionId to updated)
        )
    }

    fun verifyCurrentAnswer() {
        val session = _activeQuiz.value ?: return
        val question = session.currentQuestion ?: return
        _activeQuiz.value = session.copy(
            verifiedQuestionIds = session.verifiedQuestionIds + question.id
        )
    }

    fun moveToQuestion(index: Int) {
        val session = _activeQuiz.value ?: return
        if (index in session.questions.indices) {
            _activeQuiz.value = session.copy(currentIndex = index)
            _aiState.value = AiGenerationState.Idle
        }
    }

    fun finishQuizSession() {
        val session = _activeQuiz.value ?: return
        if (session.isFinished) return
        timerJob?.cancel()
        val finished = session.copy(isFinished = true)
        _activeQuiz.value = finished

        val currentProfile = (profileState.value as? DataUiState.Success)?.data
        val currentReviews = (reviewsState.value as? DataUiState.Success)?.data.orEmpty().associateBy { it.questionId }

        viewModelScope.launch {
            // Prevent duplicate Daily Challenge reward inflation on same day
            if (!finished.isDailyChallengeRepeat) {
                repository.recordQuizAttempt(
                    subjectId = finished.subjectId,
                    lessonId = finished.lessonId,
                    mode = finished.mode,
                    totalQuestions = finished.evaluatedTotal.coerceIn(1, 100),
                    correctCount = finished.correctCount.coerceIn(0, finished.evaluatedTotal.coerceIn(1, 100)),
                    durationSeconds = finished.elapsedSeconds,
                    existingProfile = currentProfile
                )
            }

            // Update Spaced Repetition Error Notebook for attempted questions
            val questionsToGrade = finished.questions.filter { q ->
                (finished.selectedIndicesByQuestion[q.id] ?: emptySet()).isNotEmpty()
            }.ifEmpty { finished.questions.take(3) }

            questionsToGrade.take(25).forEach { q ->
                val selected = finished.selectedIndicesByQuestion[q.id] ?: emptySet()
                val isCorrect = selected.isNotEmpty() && selected == q.correctIndices.toSet()
                val existingReview = currentReviews[q.id]

                if (!isCorrect || existingReview != null) {
                    val quality = if (isCorrect) 4 else 1
                    val nextReview = SpacedRepetitionSm2.computeNextReview(
                        current = existingReview,
                        userId = currentUserId,
                        question = q,
                        quality = quality
                    )
                    repository.saveReviewItem(nextReview)
                }
            }
        }
    }

    fun exitQuizSession() {
        timerJob?.cancel()
        _activeQuiz.value = null
        _aiState.value = AiGenerationState.Idle
    }

    // -----------------------------------------------------------------------
    // Spaced Repetition & Error Notebook Actions
    // -----------------------------------------------------------------------

    fun recordSpacedRepetitionGrade(question: Question, existingReview: ReviewItem?, quality: Int, personalNote: String) {
        viewModelScope.launch {
            val updated = SpacedRepetitionSm2.computeNextReview(
                current = existingReview,
                userId = currentUserId,
                question = question,
                quality = quality,
                noteOverride = personalNote
            )
            val res = repository.saveReviewItem(updated)
            if (res.isSuccess) {
                _statusBanner.value = "تم تحديث جدول التكرار المتباعد (المراجعة القادمة بعد ${updated.intervalDays} يوم)"
            }
        }
    }

    fun markQuestionAsMastered(question: Question, existingReview: ReviewItem?) {
        viewModelScope.launch {
            val updated = SpacedRepetitionSm2.markAsMasteredWithPeriodicReview(
                current = existingReview,
                userId = currentUserId,
                question = question
            )
            val res = repository.saveReviewItem(updated)
            if (res.isSuccess) {
                _statusBanner.value =
                    "تم تحديد السؤال كمتقن ✓ مع جدولة مراجعة تثبيتية خفيفة بعد ${updated.intervalDays} يوماً"
            }
        }
    }

    // -----------------------------------------------------------------------
    // Study Planner & Smart Auto-Reschedule Actions
    // -----------------------------------------------------------------------

    fun addStudyTask(title: String, subjectId: String, dayOfWeek: String, durationMinutes: Int, priority: String) {
        viewModelScope.launch {
            val res = repository.createStudyTask(title, subjectId, dayOfWeek, durationMinutes, priority)
            if (res.isFailure) {
                _statusBanner.value = res.exceptionOrNull()?.localizedMessage ?: "تعذر إضافة المهمة الدراسية"
            }
        }
    }

    fun toggleTaskCompleted(task: StudyTask) {
        viewModelScope.launch {
            repository.toggleStudyTask(task)
        }
    }

    fun removeStudyTask(taskId: String) {
        viewModelScope.launch {
            repository.deleteStudyTask(taskId)
        }
    }

    /**
     * Automatically recalculates and populates prioritized weekly study sessions
     * based on the student's weak subjects, overdue SM-2 reviews, and stream coefficients.
     */
    fun recalculateSmartStudyPlan(stream: AcademicStream) {
        val subjects = AlgerianCurriculumSeed.subjectsForStream(stream)
        val attempts = (attemptsState.value as? DataUiState.Success)?.data.orEmpty()
        val reviews = (reviewsState.value as? DataUiState.Success)?.data.orEmpty()
        val insights = BacAnalyticsEngine.analyzeWeaknesses(stream, subjects, attempts, reviews)

        val topTargets = insights.take(3)
        val daysCycle = listOf("SUN", "TUE", "THU")

        viewModelScope.launch {
            topTargets.forEachIndexed { idx, insight ->
                val day = daysCycle.getOrElse(idx) { "SAT" }
                val title = when (insight.status.name) {
                    "CRITICAL_WEAKNESS" -> "مراجعة علاجية مركزة: ${insight.subjectNameAr} (${insight.lessonTitleAr})"
                    "NEEDS_PRACTICE" -> "تدريب تطبيقي وحل أخطاء: ${insight.subjectNameAr}"
                    else -> "تثبيت التدرج السنوي وحل بكالوريا: ${insight.subjectNameAr}"
                }
                repository.createStudyTask(
                    title = title,
                    subjectId = insight.subjectId,
                    dayOfWeek = day,
                    durationMinutes = 60,
                    priority = if (idx == 0) "HIGH" else "MEDIUM"
                )
            }
            _statusBanner.value = "تم إعادة جدولة المخطط الأسبوعي ذكياً حسب نقاط الضعف ومعاملات شعبتك!"
        }
    }

    // -----------------------------------------------------------------------
    // Admin Content-Management, Bulk Import & Duplicate Detection
    // -----------------------------------------------------------------------

    fun submitNewQuestionForReview(
        subjectId: String,
        lessonId: String,
        stream: AcademicStream,
        difficulty: DifficultyLevel,
        provenance: QuestionProvenance,
        sourceCitation: String,
        curriculumMapping: String,
        stemAr: String,
        stemFr: String,
        optionsAr: List<String>,
        correctIndex: Int,
        explanationAr: String
    ) {
        val normalizedStem = stemAr.trim()
        val existingQuestions = AlgerianCurriculumSeed.allQuestions(
            approvedCommunityQuestionsState.value.map { it.toDomainQuestion() }
        )
        val isDuplicate = existingQuestions.any {
            it.stemAr.trim().equals(normalizedStem, ignoreCase = true)
        }
        if (isDuplicate) {
            _statusBanner.value = "تنبيه منع التكرار: هذا السؤال موجود مسبقاً في بنك الأسئلة المعتمد!"
            return
        }

        viewModelScope.launch {
            val res = repository.submitCommunityQuestion(
                subjectId = subjectId,
                lessonId = lessonId,
                stream = stream.id,
                questionType = QuestionType.SINGLE_CHOICE.id,
                difficulty = difficulty.id,
                provenance = provenance.id,
                sourceCitation = sourceCitation,
                curriculumMapping = curriculumMapping,
                stemAr = normalizedStem,
                stemFr = stemFr.ifBlank { normalizedStem },
                optionsAr = optionsAr,
                optionsFr = optionsAr,
                correctIndices = listOf(correctIndex.coerceIn(0, (optionsAr.size - 1).coerceAtLeast(0))),
                explanationAr = explanationAr,
                explanationFr = explanationAr
            )
            if (res.isSuccess) {
                _statusBanner.value = "تم فحص عدم التكرار وإرسال السؤال إلى طابور التدقيق العلمي (PENDING_REVIEW)"
            } else {
                _statusBanner.value = res.exceptionOrNull()?.localizedMessage ?: "تعذر إرسال السؤال"
            }
        }
    }

    fun bulkImportQuestionsJson(rawJson: String, stream: AcademicStream) {
        viewModelScope.launch {
            try {
                val arr = JSONArray(rawJson.trim())
                var importedCount = 0
                var skippedDuplicates = 0
                val existingStems = AlgerianCurriculumSeed.verifiedQuestions
                    .map { it.stemAr.trim() }
                    .toMutableSet()

                for (i in 0 until arr.length().coerceAtMost(20)) {
                    val obj = arr.getJSONObject(i)
                    val stemAr = obj.optString("stemAr").trim()
                    val explanationAr = obj.optString("explanationAr").trim()
                    val subjectId = obj.optString("subjectId", "math").trim()
                    val lessonId = obj.optString("lessonId", "math_limits").trim()
                    val optsJson = obj.optJSONArray("optionsAr")
                    val options = if (optsJson != null) {
                        (0 until optsJson.length()).map { optsJson.getString(it).trim() }.filter { it.isNotEmpty() }
                    } else {
                        emptyList()
                    }

                    if (stemAr.isBlank() || explanationAr.isBlank() || options.size < 2) continue
                    if (stemAr in existingStems) {
                        skippedDuplicates++
                        continue
                    }
                    existingStems.add(stemAr)

                    val res = repository.submitCommunityQuestion(
                        subjectId = subjectId,
                        lessonId = lessonId,
                        stream = stream.id,
                        questionType = QuestionType.SINGLE_CHOICE.id,
                        difficulty = obj.optString("difficulty", DifficultyLevel.BAC_LEVEL.id),
                        provenance = QuestionProvenance.TEACHER_SUBMITTED.id,
                        sourceCitation = obj.optString("sourceCitation", "استيراد دفعي مُدقق"),
                        curriculumMapping = obj.optString("curriculumMapping", "التدرج السنوي الرسمي"),
                        stemAr = stemAr,
                        stemFr = obj.optString("stemFr", stemAr),
                        optionsAr = options,
                        optionsFr = options,
                        correctIndices = listOf(obj.optInt("correctIndex", 0).coerceIn(0, options.lastIndex)),
                        explanationAr = explanationAr,
                        explanationFr = explanationAr
                    )
                    if (res.isSuccess) importedCount++
                }
                _statusBanner.value =
                    "اكتمل الاستيراد الدفعي: تم استيراد $importedCount سؤالاً بنجاح (تم تخطي $skippedDuplicates مكرر)."
            } catch (e: Exception) {
                _statusBanner.value = "صيغة JSON غير صالحة للاستيراد الدفعي: ${e.localizedMessage ?: ""}"
            }
        }
    }

    fun reviewQuestionAsAdmin(question: CommunityQuestion, newStatus: String, reviewerNote: String) {
        viewModelScope.launch {
            val res = repository.reviewCommunityQuestion(question, newStatus, reviewerNote)
            if (res.isSuccess) {
                _statusBanner.value = "تم تحديث حالة مراجعة السؤال إلى $newStatus"
            } else {
                _statusBanner.value = res.exceptionOrNull()?.localizedMessage ?: "رفضت قواعد الأمان التحديث (يتطلب صلاحية المشرف)"
            }
        }
    }

    // -----------------------------------------------------------------------
    // User Data Export & Account Deletion
    // -----------------------------------------------------------------------

    fun exportUserDataJson(): String {
        val profile = (profileState.value as? DataUiState.Success)?.data
        val attempts = (attemptsState.value as? DataUiState.Success)?.data.orEmpty()
        val reviews = (reviewsState.value as? DataUiState.Success)?.data.orEmpty()
        val tasks = (studyTasksState.value as? DataUiState.Success)?.data.orEmpty()

        val root = JSONObject()
        root.put("exportedAt", LocalDate.now().toString())
        root.put("platform", "BacMate DZ Android")
        if (profile != null) {
            val pObj = JSONObject()
            pObj.put("displayName", profile.displayName)
            pObj.put("examYear", profile.examYear)
            pObj.put("academicStream", profile.academicStream)
            pObj.put("streakDays", profile.streakDays)
            pObj.put("totalQuizzesCompleted", profile.totalQuizzesCompleted)
            pObj.put("totalQuestionsAnswered", profile.totalQuestionsAnswered)
            pObj.put("totalCorrectAnswers", profile.totalCorrectAnswers)
            root.put("profile", pObj)
        }
        root.put("attemptsCount", attempts.size)
        root.put("errorNotebookCount", reviews.size)
        root.put("studyTasksCount", tasks.size)
        return root.toString(2)
    }

    fun deleteUserAccountData(onDeleted: () -> Unit) {
        viewModelScope.launch {
            val res = repository.deleteAccountData()
            if (res.isSuccess) {
                onDeleted()
            } else {
                _statusBanner.value = res.exceptionOrNull()?.localizedMessage ?: "تعذر حذف بيانات الحساب"
            }
        }
    }

    // -----------------------------------------------------------------------
    // Firebase AI Logic (Server-Attested via App Check with Daily Usage Limits)
    // -----------------------------------------------------------------------

    private fun checkAiQuota(profile: UserProfile?): Boolean {
        val tier = SubscriptionTier.fromId(profile?.subscriptionTier ?: "FREE")
        val todayStr = LocalDate.now().toString()
        val usedToday = if (profile?.lastActiveDate == todayStr) profile.dailyAiRequestsUsedToday else 0
        if (usedToday >= tier.dailyAiLimit) {
            _aiState.value = AiGenerationState.Error(
                "بلغت الحد اليومي لطلبات المساعد الذكي (${tier.dailyAiLimit} طلبات/يوم). يتجدد الرصيد غداً أو مع الترقية."
            )
            return false
        }
        return true
    }

    fun askAiTutorForLesson(
        subject: Subject,
        lesson: Lesson,
        mode: AiTutorMode,
        studentQuestion: String,
        isArabic: Boolean
    ) {
        val profile = (profileState.value as? DataUiState.Success)?.data
        if (!checkAiQuota(profile)) return

        viewModelScope.launch {
            _aiState.value = AiGenerationState.Loading
            try {
                val contextSummary = (if (isArabic) lesson.summaryPointsAr else lesson.summaryPointsFr).joinToString(" | ")
                val formulas = lesson.keyFormulas.joinToString(" | ")
                val modeInstructionAr = when (mode) {
                    AiTutorMode.HINT ->
                        "قدم تلميحاً منهجياً تدريجياً يوجه التلميذ نحو الفكرة المفتاحية دون إعطاء الحل النهائي الجاهز."
                    AiTutorMode.STEP_BY_STEP ->
                        "اشرح المفهوم خطوة بخطوة بلغة عربية مبسطة وواضحة جداً تناسب تلميذ السنة الثالثة ثانوي."
                    AiTutorMode.WORKED_EXAMPLE ->
                        "قدم مثالاً تطبيقياً قصيراً محلولاً خطوة بخطوة مع تطبيق القوانين الرسمية."
                    AiTutorMode.FOLLOW_UP ->
                        "اطرح سؤالاً تدريبياً متابعاً لاختبار فهم التلميذ مع إجابته المختصرة في النهاية."
                }
                val prompt = if (isArabic) {
                    """
                    أنت المعلم البيداغوجي الذكي لمنصة BacMate DZ لتحضير البكالوريا الجزائرية.
                    التزم حصرياً بالمنهاج الرسمي ولا تخترع أي معلومات خارج التدرج الوزاري. إذا كان السؤال خارج المنهاج أو غير مؤكد، صرّح بذلك بوضوح.
                    المادة: ${subject.nameAr}
                    الوحدة 0${lesson.unitNumber}: ${lesson.titleAr} (${lesson.scheduleTimelineAr})
                    الكفاءة المستهدفة: ${lesson.curriculumCompetencyAr}
                    ملخص الدرس المعتمد: $contextSummary
                    العلاقات والقوانين الأساسية: $formulas
                    المطلوب (${mode.labelAr}): $modeInstructionAr
                    سؤال التلميذ الإضافي: ${studentQuestion.ifBlank { "اشرح لي أهم نقاط هذه الوحدة وكيف ترد في البكالوريا" }}
                    """.trimIndent()
                } else {
                    """
                    Vous êtes le tuteur pédagogique IA de BacMate DZ pour le Baccalauréat algérien.
                    Utilisez exclusivement le programme officiel. Si une information est incertaine, indiquez-le clairement.
                    Matière : ${subject.nameFr} — Unité 0${lesson.unitNumber} : ${lesson.titleFr}
                    Compétence : ${lesson.curriculumCompetencyFr}
                    Résumé officiel : $contextSummary
                    Formules clés : $formulas
                    Mode demandé : ${mode.labelFr}
                    Question de l'élève : ${studentQuestion.ifBlank { "Expliquez les points essentiels de cette unité pour le Bac." }}
                    """.trimIndent()
                }

                val response = withTimeout(60_000L) {
                    (explanationModel ?: throw IllegalStateException("خدمة الذكاء الاصطناعي غير متصلة حالياً")).generateContent(prompt)
                }
                val text = response.text
                if (!text.isNullOrBlank()) {
                    if (profile != null) repository.incrementAiRequestUsage(profile)
                    _aiState.value = AiGenerationState.TutorResponseReady(
                        lessonId = lesson.id,
                        modeLabel = if (isArabic) mode.labelAr else mode.labelFr,
                        responseText = text
                    )
                } else {
                    _aiState.value = AiGenerationState.Error("لم يرجع المساعد البيداغوجي إجابة نصية.")
                }
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "AI tutor timed out", e)
                _aiState.value = AiGenerationState.Error("انتهت مهلة الاتصال بالمعلم الذكي (60 ثانية). يمكنك متابعة حل الكويزات المعتمدة بدون إنترنت.")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "AI tutor failed", e)
                _aiState.value = AiGenerationState.Error(e.localizedMessage ?: "تعذر الاتصال بالمعلم الذكي حالياً.")
            }
        }
    }

    fun requestAiDeepExplanation(question: Question, isArabic: Boolean) {
        val profile = (profileState.value as? DataUiState.Success)?.data
        if (!checkAiQuota(profile)) return

        viewModelScope.launch {
            _aiState.value = AiGenerationState.Loading
            try {
                val prompt = if (isArabic) {
                    """
                    أنت أستاذ متخصص في تحضير تلاميذ البكالوريا بالجزائر وفق المنهاج الرسمي.
                    اشرح السؤال التالي خطوة بخطوة بأسلوب منهجي واضح ومختصر، وبيّن لماذا الخيار الصحيح صائب ولماذا البدائل الأخرى خاطئة:
                    السؤال: ${question.stemAr}
                    الإجابة الصحيحة: ${question.optionsAr.getOrNull(question.correctIndices.firstOrNull() ?: 0).orEmpty()}
                    الشرح الأساسي: ${question.explanationAr}
                    """.trimIndent()
                } else {
                    """
                    Vous êtes un professeur préparant au Baccalauréat algérien selon le programme officiel.
                    Expliquez étape par étape la question suivante et pourquoi les autres choix sont des distracteurs :
                    Question : ${question.stemFr}
                    Réponse exacte : ${question.optionsFr.getOrNull(question.correctIndices.firstOrNull() ?: 0).orEmpty()}
                    Corrigé de base : ${question.explanationFr}
                    """.trimIndent()
                }

                val response = withTimeout(60_000L) {
                    (explanationModel ?: throw IllegalStateException("خدمة الذكاء الاصطناعي غير متصلة حالياً")).generateContent(prompt)
                }
                val text = response.text
                if (!text.isNullOrBlank()) {
                    if (profile != null) repository.incrementAiRequestUsage(profile)
                    _aiState.value = AiGenerationState.ExplanationReady(question.id, text)
                } else {
                    _aiState.value = AiGenerationState.Error("لم يرجع النموذج شرحاً نصياً.")
                }
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "AI explanation timed out", e)
                _aiState.value = AiGenerationState.Error("انتهت مهلة الاتصال بالخادم (60 ثانية). حاول مجدداً.")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Firebase AI explanation failed", e)
                _aiState.value = AiGenerationState.Error(e.localizedMessage ?: "تعذر توليد الشرح الإضافي.")
            }
        }
    }

    fun generateAiPracticeQuestion(subject: Subject, stream: AcademicStream) {
        val profile = (profileState.value as? DataUiState.Success)?.data
        if (!checkAiQuota(profile)) return
        val lesson = subject.lessons.firstOrNull() ?: return

        viewModelScope.launch {
            _aiState.value = AiGenerationState.Loading
            try {
                val prompt = """
                    Generate ONE rigorous practice question for Algerian Baccalaureate students in stream ${stream.titleAr} (${stream.titleFr}).
                    Subject: ${subject.nameAr} (${subject.nameFr})
                    Unit/Lesson: ${lesson.titleAr} (${lesson.titleFr})
                    Competency: ${lesson.curriculumCompetencyAr}
                    IMPORTANT: Never claim this is an official past exam question. Ensure the mathematical/scientific answer is 100% verified and unambiguous.
                """.trimIndent()

                val response = withTimeout(60_000L) {
                    (questionGeneratorModel ?: throw IllegalStateException("خدمة الذكاء الاصطناعي غير متصلة حالياً")).generateContent(prompt)
                }
                val jsonString = response.text ?: throw IllegalStateException("Empty JSON response from model")
                val json = JSONObject(jsonString)

                val stemAr = json.getString("stemAr")
                val stemFr = json.optString("stemFr", stemAr)
                val optsArJson = json.getJSONArray("optionsAr")
                val optionsAr = (0 until optsArJson.length()).map { optsArJson.getString(it) }.take(4)
                val optsFrJson = json.optJSONArray("optionsFr")
                val optionsFr = if (optsFrJson != null) {
                    (0 until optsFrJson.length()).map { optsFrJson.getString(it) }.take(4)
                } else {
                    optionsAr
                }
                val correctIndex = json.optInt("correctIndex", 0).coerceIn(0, (optionsAr.size - 1).coerceAtLeast(0))
                val explanationAr = json.getString("explanationAr")
                val explanationFr = json.optString("explanationFr", explanationAr)
                val curriculumMapping = json.optString("curriculumMapping", lesson.curriculumCompetencyAr)

                val generatedQuestion = Question(
                    id = "ai_${System.currentTimeMillis()}",
                    subjectId = subject.id,
                    lessonId = lesson.id,
                    streams = listOf(stream),
                    type = QuestionType.SINGLE_CHOICE,
                    difficulty = DifficultyLevel.BAC_LEVEL,
                    provenance = QuestionProvenance.AI_GENERATED_PRACTICE,
                    sourceCitationAr = "تمرين تدريبي مولّد بالذكاء الاصطناعي (غير رسمي — مخصص للمراجعة الإضافية)",
                    sourceCitationFr = "Exercice d'entraînement généré par IA (Non officiel)",
                    curriculumMappingAr = curriculumMapping,
                    curriculumMappingFr = curriculumMapping,
                    stemAr = stemAr,
                    stemFr = stemFr,
                    optionsAr = optionsAr,
                    optionsFr = optionsFr,
                    correctIndices = listOf(correctIndex),
                    explanationAr = explanationAr,
                    explanationFr = explanationFr
                )

                if (profile != null) repository.incrementAiRequestUsage(profile)
                _aiState.value = AiGenerationState.QuestionGenerated(generatedQuestion)
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "AI question generation timed out", e)
                _aiState.value = AiGenerationState.Error("انتهت مهلة توليد السؤال (60 ثانية).")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "AI question generation failed", e)
                _aiState.value = AiGenerationState.Error(e.localizedMessage ?: "تعذر توليد سؤال تدريبي جديد.")
            }
        }
    }
}
