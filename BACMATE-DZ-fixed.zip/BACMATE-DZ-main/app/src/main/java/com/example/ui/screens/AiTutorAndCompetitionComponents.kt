package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.AcademicStream
import com.example.data.model.AchievementBadge
import com.example.data.model.AiTutorMode
import com.example.data.model.BacAnalyticsEngine
import com.example.data.model.DifficultyLevel
import com.example.data.model.Lesson
import com.example.data.model.QuizAttempt
import com.example.data.model.ReviewItem
import com.example.data.model.StudyTask
import com.example.data.model.Subject
import com.example.data.model.SubscriptionTier
import com.example.data.model.TopicWeaknessInsight
import com.example.data.model.UserProfile
import com.example.data.model.WeaknessStatus
import com.example.data.seed.AlgerianCurriculumSeed
import com.example.ui.theme.BacAmberWarning
import com.example.ui.theme.BacCoralError
import com.example.ui.theme.BacGoldAccent
import com.example.ui.theme.BacMintSuccess
import com.example.ui.theme.EmeraldPrimaryDark
import com.example.ui.theme.EmeraldPrimaryLight
import com.example.ui.viewmodel.AiGenerationState

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DailyChallengeBannerCard(
    stream: AcademicStream,
    attempts: List<QuizAttempt>,
    isArabic: Boolean,
    onStartDailyChallenge: (DifficultyLevel?) -> Unit
) {
    val todayChallengeId = remember { BacAnalyticsEngine.dailyChallengeIdForDate() }
    val todayAttempt = remember(attempts, todayChallengeId) {
        attempts.find { it.lessonId == todayChallengeId }
    }
    var selectedDifficulty by rememberSaveable { mutableStateOf<DifficultyLevel?>(null) }

    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("daily_challenge_card"),
        shape = RoundedCornerShape(22.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        colors = listOf(EmeraldPrimaryLight, Color(0xFF0F2942))
                    )
                )
                .padding(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = BacGoldAccent.copy(alpha = 0.25f),
                        shape = CircleShape
                    ) {
                        Icon(
                            imageVector = Icons.Default.Bolt,
                            contentDescription = null,
                            tint = Color(0xFFFFE082),
                            modifier = Modifier
                                .padding(8.dp)
                                .size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = if (isArabic) "التحدي اليومي الموحد (7 أسئلة)" else "Défi Quotidien Officiel (7 QCM)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                        Text(
                            text = if (isArabic) {
                                "مجموعة موحدة يومياً لجميع تلاميذ شعبة ${stream.titleAr}"
                            } else {
                                "Série quotidienne identique pour la filière ${stream.titleFr}"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                    }
                }

                Surface(
                    color = if (todayAttempt != null) BacMintSuccess else BacGoldAccent.copy(alpha = 0.28f),
                    shape = RoundedCornerShape(50)
                ) {
                    Text(
                        text = if (todayAttempt != null) {
                            if (isArabic) "مكتمل اليوم ✓ (${todayAttempt.scorePercent}%)" else "Terminé ✓ (${todayAttempt.scorePercent}%)"
                        } else {
                            if (isArabic) "تحدي جديد" else "Nouveau"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Configurable Difficulty Filter for Daily Challenge
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                contentPadding = PaddingValues(vertical = 2.dp)
            ) {
                item {
                    Surface(
                        color = if (selectedDifficulty == null) Color.White else Color.White.copy(alpha = 0.16f),
                        shape = RoundedCornerShape(50),
                        onClick = { selectedDifficulty = null }
                    ) {
                        Text(
                            text = if (isArabic) "تدرج مختلط" else "Mixte",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (selectedDifficulty == null) EmeraldPrimaryLight else Color.White,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }
                }
                items(DifficultyLevel.entries, key = { it.id }) { diff ->
                    val isSel = selectedDifficulty == diff
                    Surface(
                        color = if (isSel) Color.White else Color.White.copy(alpha = 0.16f),
                        shape = RoundedCornerShape(50),
                        onClick = { selectedDifficulty = diff }
                    ) {
                        Text(
                            text = if (isArabic) diff.labelAr else diff.labelFr,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (isSel) EmeraldPrimaryLight else Color.White,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = { onStartDailyChallenge(selectedDifficulty) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("start_daily_challenge_button"),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (todayAttempt != null) {
                        if (isArabic) "مراجعة التحدي اليومي (بدون مضاعفة النقاط)" else "Revoir le défi du jour (sans doublon)"
                    } else {
                        if (isArabic) "ابدأ التحدي اليومي الآن" else "Lancer le Défi Quotidien"
                    },
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun InteractiveAiTutorPanel(
    stream: AcademicStream,
    profile: UserProfile,
    aiState: AiGenerationState,
    isArabic: Boolean,
    onAskTutor: (Subject, Lesson, AiTutorMode, String) -> Unit,
    onDismissResponse: () -> Unit
) {
    val subjects = remember(stream) { AlgerianCurriculumSeed.subjectsForStream(stream) }
    var selectedSubjectId by rememberSaveable(stream) { mutableStateOf(subjects.firstOrNull()?.id ?: "svt") }
    val selectedSubject = remember(subjects, selectedSubjectId) {
        subjects.find { it.id == selectedSubjectId } ?: subjects.first()
    }
    val orderedLessons = remember(selectedSubject) {
        selectedSubject.lessons.sortedBy { it.unitNumber }
    }
    var selectedLessonId by rememberSaveable(selectedSubjectId) {
        mutableStateOf(orderedLessons.firstOrNull()?.id ?: "")
    }
    val selectedLesson = remember(orderedLessons, selectedLessonId) {
        orderedLessons.find { it.id == selectedLessonId } ?: orderedLessons.first()
    }
    var selectedMode by rememberSaveable { mutableStateOf(AiTutorMode.HINT) }
    var studentQuestion by rememberSaveable { mutableStateOf("") }

    val tier = SubscriptionTier.fromId(profile.subscriptionTier)

    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("ai_tutor_interactive_panel"),
        shape = RoundedCornerShape(22.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = if (isArabic) "المعلم البيداغوجي الذكي (AI Tutor)" else "Tuteur Pédagogique IA",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isArabic) {
                                "تلميحات تدريجية، شرح مبسط، وأمثلة محلولة مرتبطة بالمنهاج الرسمي"
                            } else {
                                "Indices progressifs, explications simplifiées et exemples corrigés"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(
                        text = "${profile.dailyAiRequestsUsedToday}/${tier.dailyAiLimit}",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Subject Selector
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(subjects, key = { "tutor_subj_${it.id}" }) { subj ->
                    FilterChip(
                        selected = subj.id == selectedSubject.id,
                        onClick = { selectedSubjectId = subj.id },
                        label = { Text(if (isArabic) subj.nameAr else subj.nameFr) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Lesson Selector
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(orderedLessons, key = { "tutor_lesson_${it.id}" }) { lesson ->
                    FilterChip(
                        selected = lesson.id == selectedLesson.id,
                        onClick = { selectedLessonId = lesson.id },
                        label = {
                            Text(
                                if (isArabic) "الوحدة 0${lesson.unitNumber}: ${lesson.titleAr}"
                                else "Unité 0${lesson.unitNumber}: ${lesson.titleFr}"
                            )
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Pedagogical Mode Chips (Hint first, Step-by-Step, Worked Example, Follow-up)
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                AiTutorMode.entries.forEach { mode ->
                    FilterChip(
                        selected = selectedMode == mode,
                        onClick = { selectedMode = mode },
                        label = { Text(if (isArabic) mode.labelAr else mode.labelFr) },
                        modifier = Modifier.testTag("ai_tutor_mode_${mode.id}")
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = studentQuestion,
                onValueChange = { studentQuestion = it },
                label = {
                    Text(
                        if (isArabic) "اطرح سؤالك حول الوحدة أو اطلب تبسيط فكرة معينة..."
                        else "Posez votre question sur cette unité..."
                    )
                },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("ai_tutor_question_input")
            )

            Spacer(modifier = Modifier.height(10.dp))

            Button(
                onClick = {
                    onAskTutor(selectedSubject, selectedLesson, selectedMode, studentQuestion)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("ai_tutor_ask_button"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isArabic) {
                        "اطلب: ${selectedMode.labelAr}"
                    } else {
                        "Demander : ${selectedMode.labelFr}"
                    },
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = if (isArabic) {
                    "تنبيه الأمانة العلمية: شروحات المساعد الذكي مخصصة للفهم الإضافي وقد تحتمل الخطأ؛ اعتمد دائماً على الملخصات والحلول الرسمية المعتمدة."
                } else {
                    "Note : Le tuteur IA est un outil d'accompagnement complémentaire et ne remplace pas les corrigés officiels."
                },
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            AnimatedVisibility(visible = aiState is AiGenerationState.Loading || aiState is AiGenerationState.TutorResponseReady || aiState is AiGenerationState.Error) {
                Column(modifier = Modifier.padding(top = 12.dp)) {
                    HorizontalDivider()
                    Spacer(modifier = Modifier.height(10.dp))
                    when (aiState) {
                        is AiGenerationState.Loading -> {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = if (isArabic) "جاري تحضير الشرح البيداغوجي المعتمد..." else "Préparation de l'explication...",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                        is AiGenerationState.TutorResponseReady -> {
                            Surface(
                                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = aiState.modeLabel,
                                            style = MaterialTheme.typography.labelLarge,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        OutlinedButton(onClick = onDismissResponse) {
                                            Text(if (isArabic) "إغلاق" else "Fermer")
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = aiState.responseText,
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                }
                            }
                        }
                        is AiGenerationState.Error -> {
                            Text(
                                text = aiState.message,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                        else -> {}
                    }
                }
            }
        }
    }
}

@Composable
fun PersonalizedWeaknessAnalysisPanel(
    stream: AcademicStream,
    attempts: List<QuizAttempt>,
    reviews: List<ReviewItem>,
    isArabic: Boolean,
    onStartTargetedPractice: (Subject) -> Unit
) {
    val subjects = remember(stream) { AlgerianCurriculumSeed.subjectsForStream(stream) }
    val insights: List<TopicWeaknessInsight> = remember(stream, subjects, attempts, reviews) {
        BacAnalyticsEngine.analyzeWeaknesses(stream, subjects, attempts, reviews)
    }

    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("weakness_analysis_panel"),
        shape = RoundedCornerShape(22.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.TrendingUp,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = if (isArabic) {
                            "التشخيص الشخصي لنقاط الضعف والتوصيات"
                        } else {
                            "Diagnostic personnalisé des lacunes & Recommandations"
                        },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (isArabic) {
                            "يميز التشخيص بين نقص البيانات (< 3 أسئلة) ونقاط الضعف الحقيقية لتوجيه مراجعتك بدقة."
                        } else {
                            "Distingue le manque de données (< 3 questions) des lacunes confirmées."
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            insights.forEach { insight ->
                val badgeColor = when (insight.status) {
                    WeaknessStatus.CRITICAL_WEAKNESS -> BacCoralError
                    WeaknessStatus.NEEDS_PRACTICE -> BacAmberWarning
                    WeaknessStatus.INSUFFICIENT_DATA -> MaterialTheme.colorScheme.outline
                    WeaknessStatus.MASTERED -> BacMintSuccess
                }
                val badgeText = when (insight.status) {
                    WeaknessStatus.CRITICAL_WEAKNESS -> if (isArabic) "نقطة ضعف مؤكدة (${insight.accuracyPercent}%)" else "Lacune (${insight.accuracyPercent}%)"
                    WeaknessStatus.NEEDS_PRACTICE -> if (isArabic) "يحتاج تثبيت (${insight.accuracyPercent}%)" else "À consolider (${insight.accuracyPercent}%)"
                    WeaknessStatus.INSUFFICIENT_DATA -> if (isArabic) "بيانات غير كافية (${insight.totalQuestionsAnswered}/3)" else "Données insuffisantes (${insight.totalQuestionsAnswered}/3)"
                    WeaknessStatus.MASTERED -> if (isArabic) "إتقان جيد (${insight.accuracyPercent}%)" else "Maîtrisé (${insight.accuracyPercent}%)"
                }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 5.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                    )
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (isArabic) insight.subjectNameAr else insight.subjectNameFr,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Surface(
                                color = badgeColor.copy(alpha = 0.16f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = badgeText,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = badgeColor,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (isArabic) insight.recommendationAr else insight.recommendationFr,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (isArabic) {
                                    "المحاولات: ${insight.attemptsCount} • الأسئلة المجابة: ${insight.totalQuestionsAnswered}"
                                } else {
                                    "Essais : ${insight.attemptsCount} • Questions : ${insight.totalQuestionsAnswered}"
                                },
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            val targetSubj = subjects.find { it.id == insight.subjectId }
                            if (targetSubj != null) {
                                OutlinedButton(
                                    onClick = { onStartTargetedPractice(targetSubj) },
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text(
                                        text = if (isArabic) "تدريب علاجي" else "S'entraîner",
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isArabic) {
                            "تنبيه منهجي: تُقاس هذه النسب من محاولاتك الفعلية داخل التطبيق لتوجيه المراجعة، ولا تدّعي التنبؤ الدقيق بنقطة البكالوريا الرسمية."
                        } else {
                            "Note : Ces indicateurs reposent sur vos réponses réelles et ne prétendent pas prédire votre note officielle au Bac."
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun StudentCompetitionAndAchievementsPanel(
    profile: UserProfile,
    stream: AcademicStream,
    attempts: List<QuizAttempt>,
    reviews: List<ReviewItem>,
    tasks: List<StudyTask>,
    leaderboardOptIn: Boolean,
    blockedPeers: Set<String>,
    isArabic: Boolean,
    onToggleLeaderboardOptIn: () -> Unit,
    onReportOrBlockPeer: (String) -> Unit,
    onStartFriendChallenge: () -> Unit
) {
    val badges: List<AchievementBadge> = remember(profile, attempts, reviews, tasks) {
        BacAnalyticsEngine.computeAchievements(profile, attempts, reviews, tasks)
    }

    // Verified quality score: rewards accuracy & verified completions, not raw guessing volume
    val verifiedQualityScore = remember(attempts, reviews) {
        val attemptPoints = attempts.sumOf { att ->
            val qualityMultiplier = if (att.scorePercent >= 70) 3 else if (att.scorePercent >= 50) 2 else 1
            (att.correctCount * qualityMultiplier)
        }
        val masteredBonus = reviews.count { it.mastered } * 15
        attemptPoints + masteredBonus
    }

    val friendChallengeCode = remember(stream, profile.examYear) {
        "BAC-${stream.id.take(3)}-${java.time.LocalDate.now().dayOfYear}"
    }
    var joinChallengeCodeInput by rememberSaveable { mutableStateOf("") }

    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        // 1. Achievements & Retention Milestones Card
        ElevatedCard(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("achievements_card"),
            shape = RoundedCornerShape(22.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.EmojiEvents,
                        contentDescription = null,
                        tint = BacGoldAccent
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = if (isArabic) "أوسمة الإتقان والمثابرة الأكاديمية" else "Badges de Maîtrise & Persévérance",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isArabic) {
                                "تُمنح الأوسمة بناءً على جودة التعلم وإتقان الأخطاء وليس مجرد الوقت المنقضي."
                            } else {
                                "Récompense la qualité d'apprentissage et la maîtrise des concepts."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                badges.forEach { badge ->
                    Surface(
                        color = if (badge.unlocked) {
                            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)
                        } else {
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                        },
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = if (badge.unlocked) Icons.Default.Verified else Icons.Default.EmojiEvents,
                                    contentDescription = null,
                                    tint = if (badge.unlocked) BacMintSuccess else MaterialTheme.colorScheme.outline
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = if (isArabic) badge.titleAr else badge.titleFr,
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = if (isArabic) badge.descriptionAr else badge.descriptionFr,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Surface(
                                color = if (badge.unlocked) BacMintSuccess else MaterialTheme.colorScheme.surface,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = badge.progressText,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (badge.unlocked) Color.White else MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // 2. Student Competition, Friend Challenge & Privacy-Protected Leaderboard
        ElevatedCard(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("student_competition_card"),
            shape = RoundedCornerShape(22.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = if (isArabic) {
                                    "المنافسة الأسبوعية وتحدي الأصدقاء (${stream.badgeAr})"
                                } else {
                                    "Compétition Hebdomadaire & Défi Amis"
                                },
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (isArabic) {
                                    "تُحتسب النقاط وفق الدقة والإنجاز الموثق فقط — مع حماية كاملة للخصوصية."
                                } else {
                                    "Classement basé sur la précision vérifiée — respect strict de la vie privée."
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Privacy Opt-In / Opt-Out Switch
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isArabic) {
                            "إظهار اسمي المستعار (${profile.displayName}) في لوحة المنافسة"
                        } else {
                            "Afficher mon pseudonyme (${profile.displayName}) au classement"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.weight(1f)
                    )
                    Switch(
                        checked = leaderboardOptIn,
                        onCheckedChange = { onToggleLeaderboardOptIn() },
                        modifier = Modifier.testTag("competition_opt_in_switch")
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Student's Own Verified Standing Card
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.65f),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = if (leaderboardOptIn) {
                                    "${profile.displayName} (أنت)"
                                } else {
                                    if (isArabic) "وضع عدم الظهور العام مفعّل (خاص)" else "Mode privé actif"
                                },
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (isArabic) {
                                    "الاختبارات الموثقة: ${attempts.size} • سلسلة الالتزام: ${profile.streakDays} يوم"
                                } else {
                                    "Quiz vérifiés : ${attempts.size} • Série : ${profile.streakDays} j"
                                },
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        Surface(
                            color = MaterialTheme.colorScheme.primary,
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(
                                text = if (isArabic) "$verifiedQualityScore نقطة إتقان" else "$verifiedQualityScore pts",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Friend Challenge Code Share / Join
                Text(
                    text = if (isArabic) {
                        "كود تحدي الأصدقاء اليومي לשعبتك: $friendChallengeCode"
                    } else {
                        "Code de défi entre amis : $friendChallengeCode"
                    },
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = joinChallengeCodeInput,
                        onValueChange = { joinChallengeCodeInput = it },
                        label = {
                            Text(if (isArabic) "أدخل كود تحدي صديق أو اسم مستعار للإبلاغ/الحظر" else "Code défi ou signaler un pseudo")
                        },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        onClick = onStartFriendChallenge,
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(if (isArabic) "ابدأ التحدي" else "Défier")
                    }
                    IconButton(
                        onClick = {
                            if (joinChallengeCodeInput.isNotBlank()) {
                                onReportOrBlockPeer(joinChallengeCodeInput)
                                joinChallengeCodeInput = ""
                            }
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Flag,
                            contentDescription = if (isArabic) "إبلاغ أو حظر" else "Signaler / Bloquer",
                            tint = MaterialTheme.colorScheme.error
                        )
                    }
                }
                if (blockedPeers.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (isArabic) {
                            "الحسابات المحظورة: ${blockedPeers.joinToString("، ")}"
                        } else {
                            "Comptes bloqués : ${blockedPeers.joinToString(", ")}"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
