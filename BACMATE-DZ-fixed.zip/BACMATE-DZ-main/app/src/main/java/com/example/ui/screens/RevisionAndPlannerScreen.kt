package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.AcademicStream
import com.example.data.model.BacAnalyticsEngine
import com.example.data.model.Question
import com.example.data.model.QuizAttempt
import com.example.data.model.ReviewItem
import com.example.data.model.StudyTask
import com.example.data.model.Subject
import com.example.data.model.UserProfile
import com.example.data.seed.AlgerianCurriculumSeed
import java.time.LocalDate

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ErrorNotebookAndSm2Screen(
    reviews: List<ReviewItem>,
    extraQuestions: List<Question>,
    isArabic: Boolean,
    onStartSpacedReviewQuiz: () -> Unit,
    onRecordSm2Grade: (Question, ReviewItem?, Int, String) -> Unit,
    onStartSingleQuestionRetry: (Question) -> Unit = {},
    onMarkMasteredWithPeriodicReview: (Question, ReviewItem?) -> Unit = { _, _ -> }
) {
    val allQuestions = remember(extraQuestions) {
        AlgerianCurriculumSeed.allQuestions(extraQuestions).associateBy { it.id }
    }
    val subjectsById = remember {
        AlgerianCurriculumSeed.subjects.associateBy { it.id }
    }
    val lessonsById = remember {
        AlgerianCurriculumSeed.subjects.flatMap { it.lessons }.associateBy { it.id }
    }
    val todayEpoch = remember { LocalDate.now().toEpochDay().toInt() }

    var selectedSubjectFilter by rememberSaveable { mutableStateOf<String?>(null) }
    var selectedFrequencyFilter by rememberSaveable { mutableStateOf("ALL") } // ALL, DUE_TODAY, REPEATED, MASTERED

    val filteredReviews = remember(reviews, selectedSubjectFilter, selectedFrequencyFilter, todayEpoch) {
        reviews.filter { item ->
            val matchesSubject = selectedSubjectFilter == null || item.subjectId == selectedSubjectFilter
            val matchesFreq = when (selectedFrequencyFilter) {
                "DUE_TODAY" -> item.nextReviewEpochDay <= todayEpoch && !item.mastered
                "REPEATED" -> item.mistakeCount >= 2
                "MASTERED" -> item.mastered
                else -> true
            }
            matchesSubject && matchesFreq
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (isArabic) "كراس الأخطاء الذكي والتكرار المتباعد (SM-2)" else "Carnet d'erreurs intelligent & SM-2",
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = if (isArabic) {
                            "يتم حفظ أخطائك وتصنيفها حسب المادة والوحدة وتكرار الخطأ، مع جدولة مراجعتها وفق خوارزمية SuperMemo-2."
                        } else {
                            "Vos erreurs sont classées par matière, unité et fréquence selon l'algorithme SuperMemo-2."
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Button(
                    onClick = onStartSpacedReviewQuiz,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.testTag("start_sm2_quiz_button")
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (isArabic) "جلسة مراجعة" else "Session")
                }
            }
        }

        // Smart Filters Bar (Frequency & Subject)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                )
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = if (isArabic) "تصفية حسب حالة الإتقان وتكرار الخطأ:" else "Filtrer par statut et fréquence d'erreur :",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val freqOptions = listOf(
                            "ALL" to (if (isArabic) "الكل (${reviews.size})" else "Tous (${reviews.size})"),
                            "DUE_TODAY" to (if (isArabic) "مستحق اليوم" else "À réviser"),
                            "REPEATED" to (if (isArabic) "أخطاء متكررة (≥2)" else "Erreurs fréquentes (≥2)"),
                            "MASTERED" to (if (isArabic) "متقن ✓" else "Maîtrisé ✓")
                        )
                        freqOptions.forEach { (code, label) ->
                            FilterChip(
                                selected = selectedFrequencyFilter == code,
                                onClick = { selectedFrequencyFilter = code },
                                label = { Text(label) },
                                modifier = Modifier.testTag("error_filter_freq_$code")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (isArabic) "تصفية حسب المادة:" else "Filtrer par matière :",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        FilterChip(
                            selected = selectedSubjectFilter == null,
                            onClick = { selectedSubjectFilter = null },
                            label = { Text(if (isArabic) "جميع المواد" else "Toutes") }
                        )
                        AlgerianCurriculumSeed.subjects.forEach { subj ->
                            FilterChip(
                                selected = selectedSubjectFilter == subj.id,
                                onClick = {
                                    selectedSubjectFilter = if (selectedSubjectFilter == subj.id) null else subj.id
                                },
                                label = { Text(if (isArabic) subj.nameAr else subj.nameFr) }
                            )
                        }
                    }
                }
            }
        }

        if (filteredReviews.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.Psychology,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(44.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = if (reviews.isEmpty()) {
                                if (isArabic) "كراس الأخطاء فارغ حالياً!" else "Votre carnet d'erreurs est vide !"
                            } else {
                                if (isArabic) "لا توجد عناصر مطابقة لمرشحات البحث الحالية" else "Aucun élément ne correspond aux filtres"
                            },
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isArabic) {
                                "كلما أجبت عن اختبار أو امتحان مؤقت، تُضاف الأسئلة الصعبة هنا تلقائياً مع جدول مراجعتها."
                            } else {
                                "Les questions manquées lors des quiz apparaîtront automatiquement ici."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        } else {
            items(filteredReviews, key = { it.id.ifBlank { it.questionId } }) { item ->
                val question = allQuestions[item.questionId] ?: AlgerianCurriculumSeed.verifiedQuestions.first()
                val subject = subjectsById[question.subjectId]
                val lesson = lessonsById[question.lessonId]
                var personalNote by remember(item.personalNote) { mutableStateOf(item.personalNote) }
                val isDue = item.nextReviewEpochDay <= todayEpoch && !item.mastered

                ElevatedCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                color = if (item.mastered) {
                                    MaterialTheme.colorScheme.primaryContainer
                                } else if (isDue) {
                                    MaterialTheme.colorScheme.errorContainer
                                } else {
                                    MaterialTheme.colorScheme.secondaryContainer
                                },
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text(
                                    text = when {
                                        item.mastered -> if (isArabic) "متقن ✓ (مراجعة دورية كل ${item.intervalDays}ي)" else "Maîtrisé ✓ (${item.intervalDays}j)"
                                        isDue -> if (isArabic) "مستحق للمراجعة اليوم" else "À réviser aujourd'hui"
                                        else -> if (isArabic) "الفاصل: ${item.intervalDays} يوم" else "Intervalle : ${item.intervalDays} j"
                                    },
                                    style = MaterialTheme.typography.labelMedium,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                                )
                            }

                            Text(
                                text = "EF ${(item.easeFactorPermille / 1000.0)} • أخطاء: ${item.mistakeCount}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (isArabic) {
                                "${subject?.nameAr ?: question.subjectId} • الوحدة 0${lesson?.unitNumber ?: 1}: ${lesson?.titleAr ?: question.lessonId}"
                            } else {
                                "${subject?.nameFr ?: question.subjectId} • Unité 0${lesson?.unitNumber ?: 1} : ${lesson?.titleFr ?: question.lessonId}"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.SemiBold
                        )

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (isArabic) question.stemAr else question.stemFr,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (isArabic) "الخلاصة: ${question.explanationAr}" else "Corrigé : ${question.explanationFr}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedTextField(
                            value = personalNote,
                            onValueChange = { personalNote = it },
                            label = {
                                Text(if (isArabic) "ملاحظتي الشخصية لتجنب الخطأ يوم البكالوريا" else "Note personnelle")
                            },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = { onRecordSm2Grade(question, item, 1, personalNote) },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(if (isArabic) "صعب (1ي)" else "Difficile")
                            }
                            OutlinedButton(
                                onClick = { onRecordSm2Grade(question, item, 3, personalNote) },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(if (isArabic) "متوسط" else "Moyen")
                            }
                            Button(
                                onClick = { onRecordSm2Grade(question, item, 5, personalNote) },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(if (isArabic) "متقن" else "Facile")
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = { onStartSingleQuestionRetry(question) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("retry_single_question_${question.id}"),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (isArabic) "إعادة حل السؤال" else "Réessayer",
                                    style = MaterialTheme.typography.labelMedium
                                )
                            }

                            if (!item.mastered) {
                                OutlinedButton(
                                    onClick = { onMarkMasteredWithPeriodicReview(question, item) },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("mark_mastered_${question.id}"),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (isArabic) "تم الإتقان (14ي+)" else "Maîtrisé (14j+)",
                                        style = MaterialTheme.typography.labelMedium
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun StudyPlannerAndAnalyticsScreen(
    stream: AcademicStream,
    attempts: List<QuizAttempt>,
    tasks: List<StudyTask>,
    isArabic: Boolean,
    onAddTask: (String, String, String, Int, String) -> Unit,
    onToggleTask: (StudyTask) -> Unit,
    onDeleteTask: (String) -> Unit,
    profile: UserProfile = UserProfile(),
    reviews: List<ReviewItem> = emptyList(),
    leaderboardOptIn: Boolean = true,
    quietHoursEnabled: Boolean = true,
    blockedPeers: Set<String> = emptySet(),
    onRecalculateSmartPlan: () -> Unit = {},
    onToggleQuietHours: () -> Unit = {},
    onToggleLeaderboardOptIn: () -> Unit = {},
    onReportOrBlockPeer: (String) -> Unit = {},
    onStartTargetedPractice: (Subject, String?) -> Unit = { _, _ -> }
) {
    val subjects = remember(stream) { AlgerianCurriculumSeed.subjectsForStream(stream) }

    var newTaskTitle by remember { mutableStateOf("") }
    var selectedSubjectId by remember { mutableStateOf(subjects.firstOrNull()?.id ?: "math") }
    var selectedDay by remember { mutableStateOf("SUN") }
    var selectedDuration by remember { mutableIntStateOf(60) }
    var selectedPriority by remember { mutableStateOf("HIGH") }

    val daysOfWeek = listOf(
        "SUN" to (if (isArabic) "الأحد" else "Dim"),
        "MON" to (if (isArabic) "الإثنين" else "Lun"),
        "TUE" to (if (isArabic) "الثلاثاء" else "Mar"),
        "WED" to (if (isArabic) "الأربعاء" else "Mer"),
        "THU" to (if (isArabic) "الخميس" else "Jeu"),
        "FRI" to (if (isArabic) "الجمعة" else "Ven"),
        "SAT" to (if (isArabic) "السبت" else "Sam")
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = if (isArabic) "المخطط الذكي، تشخيص النقائص، والمنافسة" else "Planning Intelligent, Diagnostic & Compétition",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.primary
            )
        }

        // 1. Personalized Weakness Analysis Panel (Distinguishes sample size vs true weakness)
        item {
            PersonalizedWeaknessAnalysisPanel(
                stream = stream,
                attempts = attempts,
                reviews = reviews,
                isArabic = isArabic,
                onStartTargetedPractice = { subj ->
                    onStartTargetedPractice(subj, null)
                }
            )
        }

        // 2. Smart Study Plan Auto-Recalculate & Quiet Hours Card
        item {
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isArabic) "إعادة الجدولة التلقائية الذكية" else "Replanification automatique intelligente",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (isArabic) {
                                    "توليد حصص مراجعة أسبوعية تلقائياً حسب معاملات المواد، الوحدات المتعثرة، وكراس الأخطاء."
                                } else {
                                    "Génère automatiquement des séances selon vos coefficients et points faibles."
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = onRecalculateSmartPlan,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.testTag("recalculate_smart_plan_button")
                        ) {
                            Icon(Icons.Default.AutoFixHigh, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (isArabic) "تحديث الخطة" else "Recalculer")
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider()
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Icon(
                                imageVector = Icons.Default.NotificationsOff,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = if (isArabic) "ساعات الهدوء الليلية (22:00 – 06:00)" else "Heures calmes (22h00 – 06h00)",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = if (isArabic) "إيقاف التنبيهات غير الضرورية أثناء النوم والراحة" else "Suspendre les notifications pendant la nuit",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Switch(
                            checked = quietHoursEnabled,
                            onCheckedChange = { onToggleQuietHours() },
                            modifier = Modifier.testTag("quiet_hours_switch")
                        )
                    }
                }
            }
        }

        // 3. Progress Chart Card (Custom Canvas Bar Chart of Bac Scores /20)
        item {
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isArabic) "تطور النقاط في الاختبارات الأخيرة (/20)" else "Évolution des notes (/20)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    val recent = attempts.take(7).reversed()
                    val primaryColor = MaterialTheme.colorScheme.primary
                    val secondaryColor = MaterialTheme.colorScheme.secondary
                    val trackColor = MaterialTheme.colorScheme.surfaceVariant

                    if (recent.isEmpty()) {
                        Text(
                            text = if (isArabic) {
                                "أكمل أول اختبار تطبيقي أو امتحان مؤقت لعرض منحنى تطور نقاطك الفعلية (/20)."
                            } else {
                                "Terminez un quiz pour visualiser la courbe de vos notes réelles (/20)."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        Canvas(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(130.dp)
                        ) {
                            val count = recent.size
                            val slotWidth = size.width / count.coerceAtLeast(1)
                            val barWidth = (slotWidth * 0.52f).coerceAtMost(48.dp.toPx())

                            recent.forEachIndexed { idx, attempt ->
                                val ratio = (attempt.bacScoreTimes10 / 200f).coerceIn(0.05f, 1f)
                                val barHeight = size.height * ratio
                                val x = idx * slotWidth + (slotWidth - barWidth) / 2f

                                drawRoundRect(
                                    color = trackColor,
                                    topLeft = Offset(x, 0f),
                                    size = Size(barWidth, size.height),
                                    cornerRadius = CornerRadius(12f, 12f)
                                )
                                drawRoundRect(
                                    color = if (attempt.bacScoreTimes10 >= 100) primaryColor else secondaryColor,
                                    topLeft = Offset(x, size.height - barHeight),
                                    size = Size(barWidth, barHeight),
                                    cornerRadius = CornerRadius(12f, 12f)
                                )
                            }
                        }
                    }
                }
            }
        }

        // 4. Add New Study Task Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isArabic) "إضافة حصة مراجعة أسبوعية" else "Ajouter une séance de révision",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = newTaskTitle,
                        onValueChange = { newTaskTitle = it },
                        label = {
                            Text(if (isArabic) "عنوان الحصة (مثال: حل موضوع بكالوريا دوال أسية)" else "Titre de la séance")
                        },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("planner_task_title_input")
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        daysOfWeek.forEach { (code, label) ->
                            FilterChip(
                                selected = selectedDay == code,
                                onClick = { selectedDay = code },
                                label = { Text(label) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        subjects.forEach { subj ->
                            FilterChip(
                                selected = selectedSubjectId == subj.id,
                                onClick = { selectedSubjectId = subj.id },
                                label = { Text(if (isArabic) subj.nameAr else subj.nameFr) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(45, 60, 90).forEach { mins ->
                                FilterChip(
                                    selected = selectedDuration == mins,
                                    onClick = { selectedDuration = mins },
                                    label = { Text("${mins}m") }
                                )
                            }
                        }

                        Button(
                            onClick = {
                                val titleToSave = newTaskTitle.ifBlank {
                                    if (isArabic) "حصة مراجعة مركزة" else "Séance de révision"
                                }
                                onAddTask(titleToSave, selectedSubjectId, selectedDay, selectedDuration, selectedPriority)
                                newTaskTitle = ""
                            },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.testTag("planner_add_task_button")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (isArabic) "إضافة" else "Ajouter")
                        }
                    }
                }
            }
        }

        // Scheduled Study Tasks List
        items(tasks, key = { it.id }) { task ->
            val subj = subjects.find { it.id == task.subjectId }
            val dayLabel = daysOfWeek.find { it.first == task.dayOfWeek }?.second ?: task.dayOfWeek

            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = task.completed,
                        onCheckedChange = { onToggleTask(task) }
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = task.title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "$dayLabel • ${if (isArabic) subj?.nameAr ?: task.subjectId else subj?.nameFr ?: task.subjectId} • ${task.durationMinutes} min",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = { onDeleteTask(task.id) }) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "حذف المهمة",
                            tint = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }
        }

        // 5. Student Competition, Achievements & Anti-Cheat Moderation Panel
        item {
            StudentCompetitionAndAchievementsPanel(
                profile = profile,
                stream = stream,
                attempts = attempts,
                reviews = reviews,
                tasks = tasks,
                leaderboardOptIn = leaderboardOptIn,
                blockedPeers = blockedPeers,
                isArabic = isArabic,
                onToggleLeaderboardOptIn = onToggleLeaderboardOptIn,
                onReportOrBlockPeer = onReportOrBlockPeer,
                onStartFriendChallenge = {
                    val firstSubj = subjects.firstOrNull()
                    if (firstSubj != null) {
                        onStartTargetedPractice(firstSubj, null)
                    }
                }
            )
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}
