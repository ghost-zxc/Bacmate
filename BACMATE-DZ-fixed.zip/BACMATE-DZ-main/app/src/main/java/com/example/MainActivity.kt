package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.data.firebase.configureAppCheck
import com.example.data.model.AcademicStream
import com.example.data.model.AppLanguage
import com.example.data.repository.BacMateRepository
import com.example.ui.auth.AuthScreen
import com.example.ui.auth.signOut
import com.example.ui.screens.ActiveQuizAndExamPlayer
import com.example.ui.screens.ErrorNotebookAndSm2Screen
import com.example.ui.screens.HomeDashboardScreen
import com.example.ui.screens.OnboardingWizardScreen
import com.example.ui.screens.ProfileSettingsAndAdminScreen
import com.example.ui.screens.StudyPlannerAndAnalyticsScreen
import com.example.ui.screens.SubjectsAndCurriculumScreen
import com.example.ui.theme.BacMateTheme
import com.example.ui.viewmodel.BacMateViewModel
import com.example.ui.viewmodel.DataUiState
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // STEP 1: Configure App Check with launch intent before any UI or Firebase operations
        configureAppCheck(this, intent)

        enableEdgeToEdge()

        // STEP 2: Initialize UI
        setContent {
            BacMateRootApp()
        }
    }
}

internal fun FirebaseAuth.authStateFlow(): Flow<FirebaseUser?> = callbackFlow {
    val listener = FirebaseAuth.AuthStateListener { auth ->
        trySend(auth.currentUser)
    }
    addAuthStateListener(listener)
    awaitClose { removeAuthStateListener(listener) }
}

enum class MainTab(
    val route: String,
    val labelAr: String,
    val labelFr: String,
    val icon: ImageVector
) {
    HOME("home", "الرئيسية", "Accueil", Icons.Default.Home),
    SUBJECTS("subjects", "المنهاج", "Matières", Icons.AutoMirrored.Filled.MenuBook),
    REVISION("revision", "كراس الأخطاء", "Erreurs SM-2", Icons.Default.Psychology),
    PLANNER("planner", "المخطط", "Planning", Icons.Default.CalendarMonth),
    PROFILE("profile", "حسابي", "Profil", Icons.Default.Person)
}

data class AppUserSession(
    val uid: String,
    val email: String?,
    val displayName: String? = null
)

@Composable
fun BacMateRootApp() {
    val safeAuth = remember { runCatching { Firebase.auth }.getOrNull() }
    val authUser by if (safeAuth != null) {
        safeAuth.authStateFlow().collectAsStateWithLifecycle(initialValue = safeAuth.currentUser)
    } else {
        remember { mutableStateOf<FirebaseUser?>(null) }
    }
    var guestUserSession by rememberSaveable { mutableStateOf<String?>(null) }
    var unauthArabic by rememberSaveable { mutableStateOf(true) }
    var isDarkTheme by rememberSaveable { mutableStateOf(false) }

    val activeSession: AppUserSession? = when {
        authUser != null -> AppUserSession(authUser!!.uid, authUser!!.email, authUser!!.displayName)
        guestUserSession != null -> AppUserSession(guestUserSession!!, "student@bacmate.dz", "طالب البكالوريا")
        else -> null
    }

    if (activeSession == null) {
        BacMateTheme(darkTheme = isDarkTheme, isRtl = unauthArabic) {
            AuthScreen(
                isArabic = unauthArabic,
                onToggleLanguage = { unauthArabic = !unauthArabic },
                onAuthSuccess = {},
                onGuestLogin = {
                    guestUserSession = "guest_student_" + System.currentTimeMillis()
                }
            )
        }
    } else {
        AuthenticatedBacMateShell(
            userSession = activeSession,
            isDarkTheme = isDarkTheme,
            onToggleDarkTheme = { isDarkTheme = !isDarkTheme },
            onSignOut = {
                guestUserSession = null
                safeAuth?.signOut()
            }
        )
    }
}

@Composable
private fun AuthenticatedBacMateShell(
    userSession: AppUserSession,
    isDarkTheme: Boolean,
    onToggleDarkTheme: () -> Unit,
    onSignOut: () -> Unit = {}
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    // Keyed by user.uid so switching accounts instantiates a fresh ViewModel
    val viewModel: BacMateViewModel = viewModel(
        key = userSession.uid,
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) {
                    "APPLICATION_KEY missing from CreationExtras"
                }
                val databaseId = runCatching { app.getString(R.string.firestore_database_id) }.getOrNull().orEmpty()
                val db = runCatching { FirebaseFirestore.getInstance(databaseId) }.getOrNull()
                val safeAuth = runCatching { Firebase.auth }.getOrNull()
                BacMateViewModel(
                    repository = BacMateRepository(db, safeAuth),
                    currentUserId = userSession.uid,
                    currentUserEmail = userSession.email
                )
            }
        }
    )

    val profileState by viewModel.profileState.collectAsStateWithLifecycle()
    val attemptsState by viewModel.attemptsState.collectAsStateWithLifecycle()
    val reviewsState by viewModel.reviewsState.collectAsStateWithLifecycle()
    val studyTasksState by viewModel.studyTasksState.collectAsStateWithLifecycle()
    val approvedCommunityQuestions by viewModel.approvedCommunityQuestionsState.collectAsStateWithLifecycle()
    val mySubmittedQuestions by viewModel.mySubmittedQuestionsState.collectAsStateWithLifecycle()
    val activeQuiz by viewModel.activeQuiz.collectAsStateWithLifecycle()
    val aiState by viewModel.aiState.collectAsStateWithLifecycle()
    val statusBanner by viewModel.statusBanner.collectAsStateWithLifecycle()
    val bookmarkedLessonIds by viewModel.bookmarkedLessonIds.collectAsStateWithLifecycle()
    val leaderboardOptIn by viewModel.leaderboardOptIn.collectAsStateWithLifecycle()
    val quietHoursEnabled by viewModel.quietHoursEnabled.collectAsStateWithLifecycle()
    val blockedChallengePeers by viewModel.blockedChallengePeers.collectAsStateWithLifecycle()

    var currentTab by rememberSaveable { mutableStateOf(MainTab.HOME) }

    val profile = (profileState as? DataUiState.Success)?.data
    val isArabic = profile?.language != AppLanguage.FR.code

    // Handle system back button when on non-home tab
    BackHandler(enabled = activeQuiz == null && currentTab != MainTab.HOME) {
        currentTab = MainTab.HOME
    }

    BacMateTheme(darkTheme = isDarkTheme, isRtl = isArabic) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            if (activeQuiz != null) {
                Scaffold(
                    contentWindowInsets = WindowInsets.safeDrawing
                ) { innerPadding ->
                    Box(modifier = Modifier.padding(innerPadding)) {
                        ActiveQuizAndExamPlayer(
                            session = activeQuiz!!,
                            isArabic = isArabic,
                            aiState = aiState,
                            onSelectOption = viewModel::toggleOptionSelection,
                            onVerifyAnswer = viewModel::verifyCurrentAnswer,
                            onMoveToQuestion = viewModel::moveToQuestion,
                            onFinishSession = viewModel::finishQuizSession,
                            onRequestAiExplanation = { q ->
                                viewModel.requestAiDeepExplanation(q, isArabic)
                            },
                            onExitSession = viewModel::exitQuizSession,
                            onRevealHint = viewModel::revealHintForCurrentQuestion
                        )
                    }
                }
                return@Surface
            }

            when (val pState = profileState) {
                is DataUiState.Loading -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
                is DataUiState.Error -> {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = pState.message,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                }
                is DataUiState.Success -> {
                    val currentProfile = pState.data
                    if (currentProfile == null) {
                        Scaffold(
                            contentWindowInsets = WindowInsets.safeDrawing
                        ) { innerPadding ->
                            Box(modifier = Modifier.padding(innerPadding)) {
                                OnboardingWizardScreen(
                                    defaultName = user.displayName ?: "طالب البكالوريا",
                                    isArabic = isArabic,
                                    onComplete = { name, year, stream, lang, goal ->
                                        viewModel.completeOnboarding(name, year, stream, lang, goal)
                                    }
                                )
                            }
                        }
                    } else {
                        val attempts = (attemptsState as? DataUiState.Success)?.data.orEmpty()
                        val reviews = (reviewsState as? DataUiState.Success)?.data.orEmpty()
                        val tasks = (studyTasksState as? DataUiState.Success)?.data.orEmpty()
                        val stream = AcademicStream.fromId(currentProfile.academicStream)

                        Scaffold(
                            contentWindowInsets = WindowInsets.safeDrawing,
                            topBar = {
                                Surface(
                                    color = MaterialTheme.colorScheme.surface,
                                    tonalElevation = 2.dp
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 16.dp, vertical = 10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Surface(
                                                color = MaterialTheme.colorScheme.primaryContainer,
                                                shape = RoundedCornerShape(10.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.School,
                                                    contentDescription = null,
                                                    tint = MaterialTheme.colorScheme.primary,
                                                    modifier = Modifier
                                                        .padding(8.dp)
                                                        .size(20.dp)
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(10.dp))
                                            Column {
                                                Text(
                                                    text = "BacMate DZ",
                                                    style = MaterialTheme.typography.titleMedium,
                                                    fontWeight = FontWeight.ExtraBold,
                                                    color = MaterialTheme.colorScheme.primary
                                                )
                                                Text(
                                                    text = if (isArabic) {
                                                        "بكالوريا ${currentProfile.examYear} • ${stream.titleAr}"
                                                    } else {
                                                        "Bac ${currentProfile.examYear} • ${stream.titleFr}"
                                                    },
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }

                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            TextButton(
                                                onClick = {
                                                    val nextLang = if (isArabic) AppLanguage.FR else AppLanguage.AR
                                                    viewModel.updatePreferences(
                                                        existingProfile = currentProfile,
                                                        displayName = currentProfile.displayName,
                                                        examYear = currentProfile.examYear,
                                                        stream = stream,
                                                        language = nextLang,
                                                        dailyGoalMinutes = currentProfile.dailyGoalMinutes
                                                    )
                                                },
                                                modifier = Modifier.testTag("top_bar_language_toggle")
                                            ) {
                                                Text(
                                                    text = if (isArabic) "FR" else "عربي",
                                                    style = MaterialTheme.typography.labelLarge,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                            IconButton(
                                                onClick = onToggleDarkTheme,
                                                modifier = Modifier.testTag("top_bar_theme_toggle")
                                            ) {
                                                Icon(
                                                    imageVector = if (isDarkTheme) Icons.Default.LightMode else Icons.Default.DarkMode,
                                                    contentDescription = if (isArabic) "تبديل المظهر" else "Changer le thème"
                                                )
                                            }
                                        }
                                    }
                                }
                            },
                            bottomBar = {
                                NavigationBar {
                                    MainTab.entries.forEach { tab ->
                                        NavigationBarItem(
                                            selected = currentTab == tab,
                                            onClick = { currentTab = tab },
                                            icon = {
                                                Icon(
                                                    imageVector = tab.icon,
                                                    contentDescription = if (isArabic) tab.labelAr else tab.labelFr
                                                )
                                            },
                                            label = {
                                                Text(if (isArabic) tab.labelAr else tab.labelFr)
                                            },
                                            modifier = Modifier.testTag("nav_tab_${tab.route}")
                                        )
                                    }
                                }
                            }
                        ) { innerPadding ->
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(innerPadding)
                            ) {
                                if (statusBanner != null) {
                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 16.dp, vertical = 6.dp),
                                        colors = CardDefaults.cardColors(
                                            containerColor = MaterialTheme.colorScheme.secondaryContainer
                                        )
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 14.dp, vertical = 10.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = statusBanner.orEmpty(),
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                                modifier = Modifier.weight(1f)
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            IconButton(
                                                onClick = viewModel::clearBanner,
                                                modifier = Modifier.size(24.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Close,
                                                    contentDescription = "إغلاق التنبيه",
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }
                                        }
                                    }
                                }

                                Box(modifier = Modifier.weight(1f)) {
                                    when (currentTab) {
                                        MainTab.HOME -> HomeDashboardScreen(
                                            profile = currentProfile,
                                            attempts = attempts,
                                            reviews = reviews,
                                            isArabic = isArabic,
                                            onStartPracticeQuiz = { subj ->
                                                viewModel.startQuizSession(subj, null, "PRACTICE", currentProfile)
                                            },
                                            onStartTimedExam = { subj ->
                                                viewModel.startQuizSession(subj, null, "TIMED_EXAM", currentProfile)
                                            },
                                            onStartUnitPracticeQuiz = { subj, lessonId ->
                                                viewModel.startQuizSession(subj, lessonId, "PRACTICE", currentProfile)
                                            },
                                            onStartUnitTimedExam = { subj, lessonId ->
                                                viewModel.startQuizSession(subj, lessonId, "TIMED_EXAM", currentProfile)
                                            },
                                            onStartSpacedReview = {
                                                viewModel.startQuizSession(null, null, "SPACED_REVIEW", currentProfile)
                                            },
                                            onStartDailyChallenge = { diff ->
                                                viewModel.startDailyChallengeSession(currentProfile, diff)
                                            },
                                            onNavigateToSubjects = { currentTab = MainTab.SUBJECTS },
                                            onNavigateToRevision = { currentTab = MainTab.REVISION },
                                            onNavigateToPlanner = { currentTab = MainTab.PLANNER },
                                            onNavigateToSubscription = { currentTab = MainTab.PROFILE },
                                            tasks = tasks
                                        )
                                        MainTab.SUBJECTS -> SubjectsAndCurriculumScreen(
                                            stream = stream,
                                            isArabic = isArabic,
                                            aiState = aiState,
                                            onStartPractice = { subj, lessonId ->
                                                viewModel.startQuizSession(subj, lessonId, "PRACTICE", currentProfile)
                                            },
                                            onStartTimedExam = { subj, lessonId ->
                                                viewModel.startQuizSession(subj, lessonId, "TIMED_EXAM", currentProfile)
                                            },
                                            onGenerateAiQuestion = { subj ->
                                                viewModel.generateAiPracticeQuestion(subj, stream)
                                            },
                                            onSubmitGeneratedToReviewQueue = { q ->
                                                viewModel.submitNewQuestionForReview(
                                                    subjectId = q.subjectId,
                                                    lessonId = q.lessonId,
                                                    stream = stream,
                                                    difficulty = q.difficulty,
                                                    provenance = q.provenance,
                                                    sourceCitation = q.sourceCitationAr,
                                                    curriculumMapping = q.curriculumMappingAr,
                                                    stemAr = q.stemAr,
                                                    stemFr = q.stemFr,
                                                    optionsAr = q.optionsAr,
                                                    correctIndex = q.correctIndices.firstOrNull() ?: 0,
                                                    explanationAr = q.explanationAr
                                                )
                                                viewModel.clearAiState()
                                            },
                                            onDismissAiState = viewModel::clearAiState,
                                            profile = currentProfile,
                                            bookmarkedLessonIds = bookmarkedLessonIds,
                                            onToggleBookmark = viewModel::toggleLessonBookmark,
                                            onStartConfiguredPractice = { subj, lessonId, diff, shuffle ->
                                                viewModel.startQuizSession(
                                                    subject = subj,
                                                    lessonId = lessonId,
                                                    mode = "PRACTICE",
                                                    currentProfile = currentProfile,
                                                    difficultyFilter = diff,
                                                    shuffleQuestions = shuffle
                                                )
                                            },
                                            onAskAiTutor = { subj, lesson, mode, customQ ->
                                                viewModel.askAiTutorForLesson(subj, lesson, mode, customQ, isArabic)
                                            }
                                        )
                                        MainTab.REVISION -> ErrorNotebookAndSm2Screen(
                                            reviews = reviews,
                                            extraQuestions = approvedCommunityQuestions.map { it.toDomainQuestion() },
                                            isArabic = isArabic,
                                            onStartSpacedReviewQuiz = {
                                                viewModel.startQuizSession(null, null, "SPACED_REVIEW", currentProfile)
                                            },
                                            onRecordSm2Grade = viewModel::recordSpacedRepetitionGrade,
                                            onStartSingleQuestionRetry = viewModel::startSingleQuestionRetry,
                                            onMarkMasteredWithPeriodicReview = viewModel::markQuestionAsMastered
                                        )
                                        MainTab.PLANNER -> StudyPlannerAndAnalyticsScreen(
                                            stream = stream,
                                            attempts = attempts,
                                            tasks = tasks,
                                            isArabic = isArabic,
                                            onAddTask = viewModel::addStudyTask,
                                            onToggleTask = viewModel::toggleTaskCompleted,
                                            onDeleteTask = viewModel::removeStudyTask,
                                            profile = currentProfile,
                                            reviews = reviews,
                                            leaderboardOptIn = leaderboardOptIn,
                                            quietHoursEnabled = quietHoursEnabled,
                                            blockedPeers = blockedChallengePeers,
                                            onRecalculateSmartPlan = { viewModel.recalculateSmartStudyPlan(stream) },
                                            onToggleQuietHours = viewModel::toggleQuietHours,
                                            onToggleLeaderboardOptIn = viewModel::toggleLeaderboardOptIn,
                                            onReportOrBlockPeer = viewModel::reportOrBlockPeer,
                                            onStartTargetedPractice = { subj, lessonId ->
                                                viewModel.startQuizSession(subj, lessonId, "PRACTICE", currentProfile)
                                            }
                                        )
                                        MainTab.PROFILE -> ProfileSettingsAndAdminScreen(
                                            profile = currentProfile,
                                            userEmail = user.email,
                                            isCurrentUserAdmin = viewModel.isCurrentUserAdmin,
                                            mySubmittedQuestions = mySubmittedQuestions,
                                            approvedCommunityQuestions = approvedCommunityQuestions,
                                            isArabic = isArabic,
                                            isDarkTheme = isDarkTheme,
                                            onToggleDarkTheme = onToggleDarkTheme,
                                            onUpdatePreferences = { name, year, st, lang, goal ->
                                                viewModel.updatePreferences(currentProfile, name, year, st, lang, goal)
                                            },
                                            onSubmitQuestion = { subjId, lessonId, st, diff, prov, src, map, stem, opts, cIdx, exp ->
                                                viewModel.submitNewQuestionForReview(
                                                    subjectId = subjId,
                                                    lessonId = lessonId,
                                                    stream = st,
                                                    difficulty = diff,
                                                    provenance = prov,
                                                    sourceCitation = src,
                                                    curriculumMapping = map,
                                                    stemAr = stem,
                                                    stemFr = stem,
                                                    optionsAr = opts,
                                                    correctIndex = cIdx,
                                                    explanationAr = exp
                                                )
                                            },
                                            onReviewQuestion = viewModel::reviewQuestionAsAdmin,
                                            onSignOut = {
                                                onSignOut()
                                                runCatching {
                                                    signOut(
                                                        credentialManager = credentialManager,
                                                        onSignOutComplete = {},
                                                        scope = coroutineScope
                                                    )
                                                }
                                            },
                                            onExportDataJson = viewModel::exportUserDataJson,
                                            onDeleteAccountData = {
                                                viewModel.deleteUserAccountData {
                                                    signOut(
                                                        credentialManager = credentialManager,
                                                        onSignOutComplete = {},
                                                        scope = coroutineScope
                                                    )
                                                }
                                            },
                                            onBulkImportQuestionsJson = viewModel::bulkImportQuestionsJson
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
