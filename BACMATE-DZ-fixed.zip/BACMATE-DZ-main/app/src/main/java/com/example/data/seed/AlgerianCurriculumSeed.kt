package com.example.data.seed

import com.example.data.model.AcademicStream
import com.example.data.model.DifficultyLevel
import com.example.data.model.Lesson
import com.example.data.model.Question
import com.example.data.model.QuestionProvenance
import com.example.data.model.QuestionType
import com.example.data.model.Subject

object AlgerianCurriculumSeed {

    val subjects: List<Subject> = listOf(
        // =====================================================================
        // 1. علوم الطبيعة والحياة (SVT) — التوزيع السنوي الرسمي (3 ثانوي علوم تجريبية)
        // =====================================================================
        Subject(
            id = "svt",
            nameAr = "علوم الطبيعة والحياة",
            nameFr = "Sciences de la Nature et de la Vie (SVT)",
            coefficientsByStream = mapOf(
                AcademicStream.SCIENCES_EXP to 6,
                AcademicStream.MATH to 2,
                AcademicStream.TECH_MATH to 1,
                AcademicStream.GESTION_ECO to 1,
                AcademicStream.LETTRES_PHILO to 1,
                AcademicStream.LANGUES to 1
            ),
            accentHex = 0xFF059669L,
            lessons = listOf(
                Lesson(
                    id = "svt_protein",
                    subjectId = "svt",
                    unitNumber = 1,
                    titleAr = "تركيب البروتين (الاستنساخ والترجمة)",
                    titleFr = "Synthèse des protéines (Transcription et Traduction)",
                    curriculumCompetencyAr = "المجال 01 (التخصص الوظيفي للبروتينات) — الوحدة 01: تحديد آليات تركيب البروتين (الاستنساخ والترجمة)",
                    curriculumCompetencyFr = "Domaine 01 — Unité 01 : Mécanismes de synthèse des protéines (Transcription et Traduction)",
                    summaryPointsAr = listOf(
                        "مقر تركيب البروتين في الخلية الهيولى، مع وجود وسيط جزيئي ناقل للمعلومة الوراثية هو الـ ARNm.",
                        "الاستنساخ يتم في النواة بتدخل إنزيم ARN بوليميراز وباستهلاك النيكليوتيدات الريبية الحرة.",
                        "تنشيط الأحماض الأمينية يتم بربط الحمض الأميني بالـ ARNt النوعي بتدخل إنزيم التنشيط ووجود الـ ATP.",
                        "مراحل الترجمة على مستوى الريبوزوم (البوليزوم): البداية (AUG)، الاستطالة، والنهاية (UAA/UAG/UGA)."
                    ),
                    summaryPointsFr = listOf(
                        "Siège de la synthèse protéique dans le cytoplasme via l'intermédiaire ARNm.",
                        "Transcription nucléaire par l'ARN polymérase à partir du brin transcrit d'ADN.",
                        "Activation des acides aminés par liaison à l'ARNt spécifique en présence d'ATP.",
                        "Étapes de la traduction au niveau du polysome : initiation (AUG), élongation, terminaison."
                    ),
                    keyFormulas = listOf(
                        "ADN (نواة) ──[ARN بوليميراز]──> ARNm ──[ريبوزوم + ARNt]──> متعدد ببتيد",
                        "AUG = الميثيونين (رامزة الانطلاق) • UAA, UAG, UGA = رامزات التوقف"
                    ),
                    estimatedMinutes = 50,
                    trimester = 1,
                    scheduleTimelineAr = "سبتمبر – أكتوبر • الأسابيع 02–03",
                    scheduleTimelineFr = "Septembre – Octobre • Semaines 02–03",
                    progressionPercentage = 14
                ),
                Lesson(
                    id = "svt_structure_function",
                    subjectId = "svt",
                    unitNumber = 2,
                    titleAr = "العلاقة بين بنية ووظيفة البروتين",
                    titleFr = "Relation entre structure et fonction de la protéine",
                    curriculumCompetencyAr = "المجال 01 — الوحدة 02: إيجاد العلاقة بين البنية الفراغية والتخصص الوظيفي للبروتين",
                    curriculumCompetencyFr = "Domaine 01 — Unité 02 : Relation entre structure spatiale et spécialisation fonctionnelle",
                    summaryPointsAr = listOf(
                        "مميزات البنيات الفراغية الأربع للبروتينات (الأولية، الثانوية α وβ، الثالثية، والرابعية).",
                        "تصنيف الأحماض الأمينية العشرين (حامضية، قاعدية، متعادلة) والخاصية الأمفوتيرية (الحمقلية) حسب pH الوسط وpHi.",
                        "تشكل الرابطة الببتيدية (-CO-NH-) بين الوظيفة الكربوكسيلية لحمض أميني والوظيفة الأمينية للحمض الموالي مع طرح ماء.",
                        "ثبات البنية الفراغية يتوقف على الروابط الكيميائية (ثنائية الكبريت، الشاردية، الهيدروجينية، وتجاذب الجذور الكارهة للماء)."
                    ),
                    summaryPointsFr = listOf(
                        "Structures spatiales : primaire, secondaire (α, β), tertiaire et quaternaire.",
                        "Classification des 20 acides aminés et propriété amphotère selon le pH et le pHi.",
                        "Formation de la liaison peptidique (-CO-NH-) avec élimination d'une molécule d'eau.",
                        "Maintien de la structure 3D par ponts disulfures, liaisons ioniques, hydrogène et hydrophobes."
                    ),
                    keyFormulas = listOf(
                        "pH < pHi ⇒ شحنة موجبة (+)  |  pH > pHi ⇒ شحنة سالبة (-)  |  pH = pHi ⇒ شحنة معدومة (0)",
                        "H₂N-CH(R₁)-COOH + H₂N-CH(R₂)-COOH → رابطة ببتيدية (-CO-NH-) + H₂O"
                    ),
                    estimatedMinutes = 45,
                    trimester = 1,
                    scheduleTimelineAr = "أكتوبر • الأسبوع 04",
                    scheduleTimelineFr = "Octobre • Semaine 04",
                    progressionPercentage = 24
                ),
                Lesson(
                    id = "svt_enzymes",
                    subjectId = "svt",
                    unitNumber = 3,
                    titleAr = "دور البروتينات في التحفيز الإنزيمي",
                    titleFr = "Rôle des protéines dans la catalyse enzymatique",
                    curriculumCompetencyAr = "المجال 01 — الوحدة 03: إظهار التخصص الوظيفي للبروتينات في التحفيز الإنزيمي",
                    curriculumCompetencyFr = "Domaine 01 — Unité 03 : Spécialisation fonctionnelle dans la catalyse enzymatique",
                    summaryPointsAr = listOf(
                        "الإنزيم وسيط حيوي من طبيعة بروتينية يسرع التفاعلات الكيميائية في شروط حيوية محددة ولا يُستهلك.",
                        "يمتاز الإنزيم بتأثير نوعي مزدوج (نوعية اتجاه مادة التفاعل S ونوعية اتجاه نوع التفاعل) بفضل بنية الموقع الفعال.",
                        "التكامل المحفز: تغير شكل الموقع الفعال عند اقتراب الركيزة ليصبح مكملاً لها.",
                        "تأثير درجة الحموضة pH (تغير الحالة الأيونية للموقع الفعال) ودرجة الحرارة (تخريب الروابط في الحرارة المرتفعة وتثبيط حركية الجزيئات في المنخفضة)."
                    ),
                    summaryPointsFr = listOf(
                        "L'enzyme est un biocatalyseur protéique agissant à faible concentration sans être consommé.",
                        "Double spécificité (de substrat et d'action) assurée par le site actif (fixation + catalyse).",
                        "Complémentarité induite lors de la formation du complexe enzyme-substrat [ES].",
                        "Effet du pH (ionisation du site actif) et de la température (dénaturation thermique ou inactivité au froid)."
                    ),
                    keyFormulas = listOf(
                        "E + S ⇄ [ES] → E + P",
                        "T_opt = 37°C (عند الإنسان) • pH = pH_opt ⇒ السرعة الأعظمية V_max"
                    ),
                    estimatedMinutes = 45,
                    trimester = 1,
                    scheduleTimelineAr = "أكتوبر • الأسبوع 05",
                    scheduleTimelineFr = "Octobre • Semaine 05",
                    progressionPercentage = 34
                ),
                Lesson(
                    id = "svt_immunity",
                    subjectId = "svt",
                    unitNumber = 4,
                    titleAr = "دور البروتينات في الدفاع عن الذات (المناعة)",
                    titleFr = "Rôle des protéines dans la défense du soi (Immunologie)",
                    curriculumCompetencyAr = "المجال 01 — الوحدة 04: الذات واللاذات، الرد الخلطي والخلوي، التعاون المناعي، وفيروس VIH",
                    curriculumCompetencyFr = "Domaine 01 — Unité 04 : Le soi et le non-soi, réponses humorale et cellulaire, et VIH",
                    summaryPointsAr = listOf(
                        "مؤشرات الذات: معقد التوافق النسيجي CMH (HLA I وHLA II) ومؤشرات الزمر الدموية ABO والريزوس Rh.",
                        "الرد المناعي الخلطي: انتقاء لمي للـ LB، تمايزها إلى خلايا بلازمية منتجة للأجسام المضادة، وتشكل المعقد المناعي والتخلص منه بالبلعمة.",
                        "الرد المناعي الخلوي: انتقاء الـ LT8 وتمايزها إلى LTc تدمر الخلايا المصابة عبر البيرفورين والغرانزيم.",
                        "التعاون الخلوي وفيروس VIH: دور البلعميات (CPA) والـ LT4 المفرزة للإنترلوكينات (IL2)، واستهداف فيروس VIH للـ LT4 والبلعميات مما يسبب العجز المناعي (السيدا)."
                    ),
                    summaryPointsFr = listOf(
                        "Marqueurs du soi : CMH (HLA I et HLA II) et systèmes ABO / Rhésus.",
                        "Immunité humorale : sélection clonale des LB, plasmocytes, anticorps et complexe immun.",
                        "Immunité cellulaire : sélection des LT8, différenciation en LTc et lyse par perforine.",
                        "Coopération cellulaire (CPA, LT4, IL-2) et infection des LT4 par le rétrovirus VIH."
                    ),
                    keyFormulas = listOf(
                        "HLA I : جميع الخلايا المنواة  |  HLA II : الخلايا العارضة CPA والـ LB",
                        "LT4 ──[IL-2]──> تنشيط وتكاثر وتمايز LB (خلطي) و LT8 إلى LTc (خلوي)"
                    ),
                    estimatedMinutes = 65,
                    trimester = 1,
                    scheduleTimelineAr = "نوفمبر – جانفي • الأسابيع 06–15",
                    scheduleTimelineFr = "Novembre – Janvier • Semaines 06–15",
                    progressionPercentage = 55
                ),
                Lesson(
                    id = "svt_neuro",
                    subjectId = "svt",
                    unitNumber = 5,
                    titleAr = "دور البروتينات في الاتصال العصبي",
                    titleFr = "Rôle des protéines dans la communication nerveuse",
                    curriculumCompetencyAr = "المجال 01 — الوحدة 05: كمون الراحة، كمون العمل، النقل المشبكي، والإدماج العصبي",
                    curriculumCompetencyFr = "Domaine 01 — Unité 05 : Potentiel de repos, potentiel d'action, synapse et intégration",
                    summaryPointsAr = listOf(
                        "كمون الراحة (-70 mV) يؤمنه التوزيع غير المتساوي لـ Na⁺ وK⁺ عبر قنوات الميز ومضخة Na⁺/K⁺ المستهلكة للـ ATP.",
                        "كمون العمل يتولد بتدخل القنوات الفولطية لـ Na⁺ (زوال الاستقطاب) ثم القنوات الفولطية لـ K⁺ (عودة الاستقطاب وفرطه).",
                        "النقل المشبكي: تغير نمط التشفير من كهربائي (تواتر كمونات العمل) إلى كيميائي (تركيز الأستيل كولين أو الـ GABA) ثم كهربائي بعد مشبكي (PPSE أو PPSI).",
                        "الإدماج العصبي (التجميع الفضائي والزمني) وتأثير المخدرات مثل المورفين على عمل المشابك."
                    ),
                    summaryPointsFr = listOf(
                        "Potentiel de repos (-70 mV) maintenu par les canaux de fuite et la pompe Na⁺/K⁺ ATPase.",
                        "Potentiel d'action généré par les canaux voltage-dépendants à Na⁺ et K⁺.",
                        "Transmission synaptique : codage électrique → chimique (Acétylcholine / GABA) → PPSE ou PPSI.",
                        "Intégration neuronale (sommation spatiale et temporelle) et mode d'action de la morphine."
                    ),
                    keyFormulas = listOf(
                        "مضخة Na⁺/K⁺ : إخراج 3 Na⁺ وإدخال 2 K⁺ عكس التدرج مع إماهة ATP",
                        "Σ (PPSE + PPSI) ≥ عتبة زوال الاستقطاب ⇒ تولد كمون عمل بعد مشبكي"
                    ),
                    estimatedMinutes = 55,
                    trimester = 2,
                    scheduleTimelineAr = "جانفي – فيفري • الأسابيع 16–19",
                    scheduleTimelineFr = "Janvier – Février • Semaines 16–19",
                    progressionPercentage = 68
                ),
                Lesson(
                    id = "svt_photosynthesis",
                    subjectId = "svt",
                    unitNumber = 6,
                    titleAr = "آليات تحويل الطاقة الضوئية إلى طاقة كيميائية كامنة (التركيب الضوئي)",
                    titleFr = "Conversion de l'énergie lumineuse en énergie chimique (Photosynthèse)",
                    curriculumCompetencyAr = "المجال 02 (التحولات الطاقوية) — الوحدة 01: المرحلة الكيموضوئية في التيلاكويد والكيموحيوية في الحشوة",
                    curriculumCompetencyFr = "Domaine 02 — Unité 01 : Phase photochimique (thylakoïde) et phase biochimique (stroma)",
                    summaryPointsAr = listOf(
                        "ما فوق بنية الصانعة الخضراء: حجيرتان أساسيتان هما التيلاكويد (مقر المرحلة الكيموضوئية) والحشوة (مقر المرحلة الكيموحيوية).",
                        "المرحلة الكيموضوئية: أكسدة الماء ضوئياً (انطلاق O₂)، نقل الإلكترونات، إرجاع NADP⁺ إلى NADPH,H⁺، والفسفرة الضوئية للـ ADP إلى ATP.",
                        "المرحلة الكيموحيوية (حلقة كالفن): تثبيت CO₂ بإنزيم الريبولوز ثنائي الفوسفات كربوكسيلاز (Rubisco) واستهلاك نواتج المرحلة الكيموضوئية (ATP وNADPH,H⁺) لتركيب السكريات.",
                        "تكامل المرحلتين: لا تستمر حلقة كالفن في الحشوة إلا بتوفر نواتج التيلاكويد، ولا يستمر نشاط التيلاكويد إلا بتجديد لواقطه (ADP وNADP⁺) في الحشوة."
                    ),
                    summaryPointsFr = listOf(
                        "Ultrastructure du chloroplaste : thylakoïdes (phase photochimique) et stroma (cycle de Calvin).",
                        "Phase photochimique : photolyse de l'eau (O₂), réduction de NADP⁺ et photophosphorylation d'ATP.",
                        "Phase biochimique : fixation du CO₂ sur le RuBP (Rubisco) utilisant l'ATP et le NADPH,H⁺.",
                        "Couplage énergétique étroit entre le thylakoïde et le stroma."
                    ),
                    keyFormulas = listOf(
                        "6 CO₂ + 12 H₂O ──[ضوء + يخضور]──> C₆H₁₂O₆ + 6 O₂ + 6 H₂O",
                        "2 H₂O + 2 NADP⁺ + n(ADP + Pi) ──> O₂ + 2 NADPH,H⁺ + n ATP"
                    ),
                    estimatedMinutes = 50,
                    trimester = 2,
                    scheduleTimelineAr = "فيفري – مارس • الأسابيع 20–21",
                    scheduleTimelineFr = "Février – Mars • Semaines 20–21",
                    progressionPercentage = 80
                ),
                Lesson(
                    id = "svt_respiration",
                    subjectId = "svt",
                    unitNumber = 7,
                    titleAr = "تحويل الطاقة الكيميائية الكامنة إلى ATP (التنفس والتخمر)",
                    titleFr = "Conversion de l'énergie chimique en ATP (Respiration et Fermentation)",
                    curriculumCompetencyAr = "المجال 02 — الوحدة 02–03: هدم الغلوكوز في وجود وغياب الأكسجين وحوصلة التحولات الطاقوية",
                    curriculumCompetencyFr = "Domaine 02 — Unités 02–03 : Respiration cellulaire, fermentation et bilan énergétique",
                    summaryPointsAr = listOf(
                        "التحلل السكري في الهيولى: هدم جزيئة غلوكوز إلى جزيئتين من حمض البيروفيك مع إنتاج 2 ATP و2 NADH,H⁺.",
                        "في وجود O₂ (الميتوكندري): أكسدة حمض البيروفيك وحلقة كريبس في المادة الأساسية، والفسفرة التأكسدية على مستوى الغشاء الداخلي (الأعراف) بحصيلة 38 ATP.",
                        "في غياب O₂ (التخمر): هدم جزئي للغلوكوز في الهيولى لتجديد NAD⁺ بحصيلة طاقوية ضعيفة (2 ATP)."
                    ),
                    summaryPointsFr = listOf(
                        "Glycolyse cytoplasmique : Glucose → 2 Acides pyruviques + 2 ATP + 2 NADH,H⁺.",
                        "En aérobiose (mitochondrie) : Cycle de Krebs (matrice) et phosphorylation oxydative (crêtes) → 38 ATP.",
                        "En anaérobiose (fermentation) : Dégradation partielle dans le hyaloplasme → 2 ATP."
                    ),
                    keyFormulas = listOf(
                        "التنفس الخلوي: C₆H₁₂O₆ + 6 O₂ + 6 H₂O → 6 CO₂ + 12 H₂O + 38 ATP + حرارة",
                        "التخمر الكحولي: C₆H₁₂O₆ → 2 C₂H₅OH + 2 CO₂ + 2 ATP"
                    ),
                    estimatedMinutes = 50,
                    trimester = 3,
                    scheduleTimelineAr = "أفريل • الأسابيع 24–25",
                    scheduleTimelineFr = "Avril • Semaines 24–25",
                    progressionPercentage = 90
                ),
                Lesson(
                    id = "svt_geology",
                    subjectId = "svt",
                    unitNumber = 8,
                    titleAr = "التكتونية العامة وبنية الكرة الأرضية",
                    titleFr = "Tectonique globale et structure interne du globe terrestre",
                    curriculumCompetencyAr = "المجال 03 (التكتونية العامة) — الوحدة 01–02: البنية الداخلية للكرة الأرضية والنشاط التكتوني (التباعد والتقارب)",
                    curriculumCompetencyFr = "Domaine 03 — Unités 01–02 : Modèle sismologique/minéralogique, divergence et subduction",
                    summaryPointsAr = listOf(
                        "البنية الداخلية للكرة الأرضية: استغلال النموذج السيسمولوجي (انقطاعات موهو، غوتنبرغ، ليمان) والنموذج المعدني الكيميائي (القشرة، البرنس الليتوسفيري والأستينوسفيري، النواة).",
                        "حركات التباعد على مستوى الظهرات: تشكل لوح محيطي جديد (البازلت والغابرو) بفعل تيارات الحمل الحراري الصاعدة.",
                        "حركات التقارب والغوص: اختفاء اللوح المحيطي الأقدم والأكثر كثافة تحت اللوح القاري أو المحيطي، والظواهر المرتبطة به (البراكين الانفجارية، الزلازل لبنيوف، وتشكل الماغما الأنديزيتية)."
                    ),
                    summaryPointsFr = listOf(
                        "Structure interne : discontinuités de Moho, Gutenberg et Lehmann (Lithosphère, Asthénosphère, Noyau).",
                        "Divergence aux dorsales : accrétion océanique (basalte, gabbro) par courants de convection.",
                        "Convergence et subduction : plongement de la lithosphère océanique dense, plan de Benioff et magmatisme calco-alcalin."
                    ),
                    keyFormulas = listOf(
                        "الليتوسفير = القشرة (قارية/محيطية) + الجزء العلوي الصلب من البرنس العلوي",
                        "الظهرة المحيطية (تباعد وبناء) ⇄ خندق الغوص (تقارب وهدم)"
                    ),
                    estimatedMinutes = 45,
                    trimester = 3,
                    scheduleTimelineAr = "أفريل – ماي • الأسابيع 26–28",
                    scheduleTimelineFr = "Avril – Mai • Semaines 26–28",
                    progressionPercentage = 100
                )
            )
        ),

        // =====================================================================
        // 2. العلوم الفيزيائية (Physics) — التوزيع السنوي الرسمي (3 ع.تجريبية / رياضيات)
        // =====================================================================
        Subject(
            id = "physics",
            nameAr = "العلوم الفيزيائية",
            nameFr = "Sciences Physiques",
            coefficientsByStream = mapOf(
                AcademicStream.SCIENCES_EXP to 5,
                AcademicStream.MATH to 6,
                AcademicStream.TECH_MATH to 6,
                AcademicStream.GESTION_ECO to 1,
                AcademicStream.LETTRES_PHILO to 1,
                AcademicStream.LANGUES to 1
            ),
            accentHex = 0xFF1E3A8AL,
            lessons = listOf(
                Lesson(
                    id = "phys_kinetics",
                    subjectId = "physics",
                    unitNumber = 1,
                    titleAr = "المتابعة الزمنية لتحول كيميائي في وسط مائي",
                    titleFr = "Suivi temporel d'une transformation chimique en milieu aqueux",
                    curriculumCompetencyAr = "الوحدة 01 (06 سا + 03 أ.م): قياس الناقلية، المعايرة اللونية، السرعة الحجمية، وزمن نصف التفاعل t½",
                    curriculumCompetencyFr = "Unité 01 (06h + 03 TP) : Conductimétrie, titrage, vitesse volumique et temps de demi-réaction t½",
                    summaryPointsAr = listOf(
                        "زمن نصف التفاعل t½ هو المدة الزمنية اللازمة لبلوغ تقدم التفاعل نصف قيمته النهائية: x(t½) = x_f / 2.",
                        "السرعة الحجمية للتفاعل: v_vol = (1/V_T) · (dx/dt) وتتناقص بمرور الزمن لتناقص التراكيز المولية للمتفاعلات.",
                        "العوامل الحركية (درجة الحرارة، التركيز الابتدائي، الوسيط، سطح التلامس) تسرع التفاعل وتقلل t½ دون تغيير x_max في التفاعل التام."
                    ),
                    summaryPointsFr = listOf(
                        "Le temps de demi-réaction t½ vérifie x(t½) = x_f / 2.",
                        "Vitesse volumique de réaction : v_vol = (1/V_T) · (dx/dt).",
                        "Facteurs cinétiques : température, concentrations initiales et catalyseur."
                    ),
                    keyFormulas = listOf(
                        "v_vol(t) = (1 / V_T) · (dx / dt)  |  x(t₁/₂) = x_f / 2",
                        "σ(t) = Σ λ_i · [X_i](t)  |  G(t) = k · σ(t)"
                    ),
                    estimatedMinutes = 45,
                    trimester = 1,
                    scheduleTimelineAr = "سبتمبر – أكتوبر • الأسابيع 02–04 (06 سا + 03 أ.م)",
                    scheduleTimelineFr = "Septembre – Octobre • Semaines 02–04 (06h + 03 TP)",
                    progressionPercentage = 12
                ),
                Lesson(
                    id = "phys_mechanics",
                    subjectId = "physics",
                    unitNumber = 2,
                    titleAr = "تطور جملة ميكانيكية (الأقمار، السقوط، القذيفة، المستوي)",
                    titleFr = "Évolution d'un système mécanique (Satellites, Chute, Projectile)",
                    curriculumCompetencyAr = "الوحدة 02 (10 سا + 05 أ.م): قوانين نيوتن، حركة الكواكب والأقمار، السقوط الشاقولي، القذيفة، والمستوي",
                    curriculumCompetencyFr = "Unité 02 (10h + 05 TP) : Lois de Newton, satellites, chute verticale, projectile et plan",
                    summaryPointsAr = listOf(
                        "حركة الكواكب والأقمار الاصطناعية: القانون الثاني لنيوتن في معلم عطالي يعطي السرعة المدارية v = √(G·M / r) وقانون كبلر الثالث T²/r³ = 4π²/(G·M).",
                        "السقوط الشاقولي في الهواء: يخضع الجسم للثقل P، دافعة أرخميدس Π، وقوة الاحتكاك f = k·v (أو k·v²) وتؤول سرعته إلى السرعة الحدية v_lim.",
                        "حركة قذيفة في معلم متجانس: حركة مستقيمة منتظمة على المحور الأفقي (Ox) ومتغيرة بانتظام على المحور الشاقولي (Oy) بمعادلة مسار قطع مكافئ."
                    ),
                    summaryPointsFr = listOf(
                        "Satellites et planètes : vitesse orbitale v = √(G·M / r) et 3e loi de Kepler T²/r³ = 4π²/(G·M).",
                        "Chute verticale dans un fluide : Poids P, poussée d'Archimède Π, frottement f = k·v et vitesse limite v_lim.",
                        "Mouvement d'un projectile : MRU selon (Ox), MRUV selon (Oy) et trajectoire parabolique."
                    ),
                    keyFormulas = listOf(
                        "v = √(G·M / (R + h))  |  T² / r³ = 4π² / (G·M)",
                        "dv/dt + (k/m)·v = g·(1 - ρ₀·V/m)  |  y(x) = -g / [2·v₀²·cos²(α)] · x² + tan(α)·x"
                    ),
                    estimatedMinutes = 60,
                    trimester = 1,
                    scheduleTimelineAr = "أكتوبر – نوفمبر • الأسابيع 05–10 (10 سا + 05 أ.م)",
                    scheduleTimelineFr = "Octobre – Novembre • Semaines 05–10 (10h + 05 TP)",
                    progressionPercentage = 34
                ),
                Lesson(
                    id = "phys_rc",
                    subjectId = "physics",
                    unitNumber = 3,
                    titleAr = "دراسة ظواهر كهربائية (ثنائي القطب RC و RL)",
                    titleFr = "Étude de phénomènes électriques (Dipôles RC et RL)",
                    curriculumCompetencyAr = "الوحدة 03 (08 سا + 03 أ.م): المعادلات التفاضلية لشحن وتفريغ مكثفة (RC) وتأسيس/قطع التيار في وشيعة (RL)",
                    curriculumCompetencyFr = "Unité 03 (08h + 03 TP) : Équations différentielles des dipôles RC et RL et constantes de temps",
                    summaryPointsAr = listOf(
                        "ثنائي القطب RC: معادلة الشحن u_C + R·C·(du_C/dt) = E، وثابت الزمن τ = R·C حيث u_C(τ) = 0.63 E.",
                        "ثنائي القطب RL: معادلة ظهور التيار i + (L / (R+r))·(di/dt) = E / (R+r)، وثابت الزمن τ = L / (R+r).",
                        "الطاقة المخزنة في المكثفة E_c = ½·C·u_C² والطاقة المخزنة في الوشيعة E_b = ½·L·i²."
                    ),
                    summaryPointsFr = listOf(
                        "Dipôle RC : u_C + R·C·(du_C/dt) = E, constante de temps τ = R·C.",
                        "Dipôle RL : i + (L/(R+r))·(di/dt) = E/(R+r), constante de temps τ = L/(R+r).",
                        "Énergies : E_c = ½·C·u_C² (condensateur) et E_b = ½·L·i² (bobine)."
                    ),
                    keyFormulas = listOf(
                        "RC : τ = R·C  |  u_C(t) = E·(1 - e^(-t/τ))  |  E_c = ½·C·u_C²",
                        "RL : τ = L / (R + r)  |  i(t) = I₀·(1 - e^(-t/τ))  |  E_b = ½·L·i²"
                    ),
                    estimatedMinutes = 55,
                    trimester = 1,
                    scheduleTimelineAr = "نوفمبر – جانفي • الأسابيع 11–17 (08 سا + 03 أ.م)",
                    scheduleTimelineFr = "Novembre – Janvier • Semaines 11–17 (08h + 03 TP)",
                    progressionPercentage = 50
                ),
                Lesson(
                    id = "phys_equilibrium",
                    subjectId = "physics",
                    unitNumber = 4,
                    titleAr = "تطور جملة كيميائية نحو حالة التوازن (الأحماض والأسس)",
                    titleFr = "Évolution d'un système chimique vers l'état d'équilibre (pH)",
                    curriculumCompetencyAr = "الوحدة 04 (08 سا + 04 أ.م): الـ pH، كسر التفاعل Qr، ثابت الحموضة Ka وpKa، والمعايرة الـ pH مترية",
                    curriculumCompetencyFr = "Unité 04 (08h + 04 TP) : pH, quotient de réaction Qr, constante d'acidité Ka/pKa et titrage pH-métrique",
                    summaryPointsAr = listOf(
                        "نسبة التقدم النهائي τ_f = x_f / x_max: إذا كان τ_f = 1 فالتحول تام (حمض أو أساس قوي)، وإذا كان τ_f < 1 فالتحول غير تام (توازن كيميائي).",
                        "علاقة أندرسون-هاسلبالخ للثنائية (HA/A⁻): pH = pKa + log([A⁻]_f / [HA]_f)، وعند نصف التكافؤ يكون pH = pKa.",
                        "المعايرة الـ pH مترية: عند نقطة التكافؤ E يتحقق C_A · V_A = C_B · V_BE، ونختار الكاشف الملون الذي يشمل مجال تغيره اللوني قيمة pH_E."
                    ),
                    summaryPointsFr = listOf(
                        "Taux d'avancement final τ_f = x_f / x_max (τ_f = 1 : réaction totale ; τ_f < 1 : équilibre).",
                        "Relation d'Henderson : pH = pKa + log([A⁻]_f / [HA]_f) ; à la demi-équivalence pH = pKa.",
                        "Titrage pH-métrique : à l'équivalence C_A · V_A = C_B · V_BE."
                    ),
                    keyFormulas = listOf(
                        "pH = -log[H₃O⁺]  |  Ke = [H₃O⁺]·[HO⁻] = 10⁻¹⁴ (عند 25°C)",
                        "pH = pKa + log([A⁻] / [HA])  |  C_A · V_A = C_B · V_BE"
                    ),
                    estimatedMinutes = 55,
                    trimester = 2,
                    scheduleTimelineAr = "جانفي – فيفري • الأسابيع 18–21 (08 سا + 04 أ.م)",
                    scheduleTimelineFr = "Janvier – Février • Semaines 18–21 (08h + 04 TP)",
                    progressionPercentage = 66
                ),
                Lesson(
                    id = "phys_nuclear",
                    subjectId = "physics",
                    unitNumber = 5,
                    titleAr = "التحولات النووية (النشاط الإشعاعي، الانشطار، والاندماج)",
                    titleFr = "Transformations nucléaires (Radioactivité, Fission et Fusion)",
                    curriculumCompetencyAr = "الوحدة 05 (06 سا + 04 أ.م): قانون التناقص الإشعاعي، زمن نصف العمر t½، طاقة الربط، والحصيلة الطاقوية",
                    curriculumCompetencyFr = "Unité 05 (06h + 04 TP) : Décroissance radioactive, demi-vie t½, énergie de liaison et bilan",
                    summaryPointsAr = listOf(
                        "الأنماط الإشعاعية (α, β⁻, β⁺, γ) تخضع لقانوني صودي لانحفاظ العدد الكتلي A والعدد الشحني Z.",
                        "قانون التناقص الإشعاعي: N(t) = N₀ · e^(-λt) والنشاط الإشعاعي A(t) = λ · N(t) بالبيكريل (Bq)، وزمن نصف العمر t½ = ln(2) / λ.",
                        "طاقة الربط النووية E_l = Δm · c²، وتكون النواة أكثر استقراراً كلما كانت طاقة الربط لكل نوية (E_l / A) أكبر."
                    ),
                    summaryPointsFr = listOf(
                        "Lois de conservation de Soddy (A et Z) pour les désintégrations α, β⁻, β⁺ et désexcitation γ.",
                        "Loi de décroissance : N(t) = N₀ · e^(-λt), activité A(t) = λ·N(t) et demi-vie t½ = ln(2)/λ.",
                        "Énergie de liaison E_l = Δm · c² et stabilité nucléaire évaluée par E_l / A."
                    ),
                    keyFormulas = listOf(
                        "N(t) = N₀ · e^(-λt)  |  A(t) = A₀ · e^(-λt)  |  t₁/₂ = ln(2) / λ",
                        "E_l = [Z·m_p + (A - Z)·m_n - m(X)] · 931.5 MeV"
                    ),
                    estimatedMinutes = 50,
                    trimester = 2,
                    scheduleTimelineAr = "فيفري • الأسابيع 22–24 (06 سا + 04 أ.م)",
                    scheduleTimelineFr = "Février • Semaines 22–24 (06h + 04 TP)",
                    progressionPercentage = 76
                ),
                Lesson(
                    id = "phys_ester_control",
                    subjectId = "physics",
                    unitNumber = 6,
                    titleAr = "مراقبة تطور جملة كيميائية (الأسترة والإماهة والأعمدة)",
                    titleFr = "Contrôle de l'évolution d'un système chimique (Estérification)",
                    curriculumCompetencyAr = "الوحدة 06 (08 سا + 03 أ.م): معيار التطور التلقائي Qr,i، تفاعل الأسترة والإماهة، ومردود التصنيع r",
                    curriculumCompetencyFr = "Unité 06 (08h + 03 TP) : Critère d'évolution spontanée, estérification-hydrolyse et rendement r",
                    summaryPointsAr = listOf(
                        "معيار التطور التلقائي: تتطور الجملة تلقائياً نحو حالة التوازن حيث Qr,f = K.",
                        "تفاعل الأسترة والإماهة تفاعل محدود، لا حراري، وبطيء؛ مردوده لمزيج متساوي المولات هو 67% مع كحول أولي، 60% مع ثانوي، و5% مع ثالثي.",
                        "لتحسين المردود ومراقبة التطور: إزالة أحد النواتج (الماء)، استعمال مزيج غير متساوي المولات، أو تعويض الحمض الكربوكسيلي بكلور الأسيل (تفاعل تام وسريع)."
                    ),
                    summaryPointsFr = listOf(
                        "Critère d'évolution spontanée : le système évolue vers l'équilibre Qr,f = K.",
                        "L'estérification est lente, limitée et athermique (r = 67% alcool I, 60% alcool II, 5% alcool III).",
                        "Amélioration du rendement : excès d'un réactif, élimination d'un produit ou chlorure d'acyle."
                    ),
                    keyFormulas = listOf(
                        "R-COOH + R'-OH ⇄ R-COO-R' + H₂O  |  K = 4 (كحول أولي)",
                        "r (%) = (x_f / x_max) × 100"
                    ),
                    estimatedMinutes = 45,
                    trimester = 3,
                    scheduleTimelineAr = "مارس – أفريل • الأسابيع 25–32 (08 سا + 03 أ.م)",
                    scheduleTimelineFr = "Mars – Avril • Semaines 25–32 (08h + 03 TP)",
                    progressionPercentage = 92
                ),
                Lesson(
                    id = "phys_oscillations",
                    subjectId = "physics",
                    unitNumber = 7,
                    titleAr = "التطورات المهتزة (الميكانيكية والكهربائية RLC)",
                    titleFr = "Évolutions oscillantes (Mécaniques et Électriques RLC)",
                    curriculumCompetencyAr = "الوحدة 07 (06 سا + 02 أ.م): الاهتزازات الحرة غير المتخامدة والمتخامدة في النواس المرن والدارة المهتزة LC/RLC",
                    curriculumCompetencyFr = "Unité 07 (06h + 02 TP) : Oscillations libres mécaniques (pendule élastique) et électriques (LC/RLC)",
                    summaryPointsAr = listOf(
                        "النواس المرن الأفقي غير المتخامد: المعادلة التفاضلية d²x/dt² + (k/m)·x = 0، والدور الذاتي T₀ = 2π·√(m/k).",
                        "الدارة المهتزة المثالية LC: المعادلة التفاضلية d²u_C/dt² + (1/(L·C))·u_C = 0، والدور الذاتي لتومسون T₀ = 2π·√(L·C).",
                        "انحفاظ الطاقة الكلية في الجملة غير المتخامدة: E_T = E_c + E_p = ثابت، وتناقصها بتبدد حراري (فعل جول أو الاحتكاك) في النظام شبه الدوري."
                    ),
                    summaryPointsFr = listOf(
                        "Pendule élastique : d²x/dt² + (k/m)·x = 0 et période propre T₀ = 2π·√(m/k).",
                        "Circuit LC idéal : d²u_C/dt² + (1/(L·C))·u_C = 0 et formule de Thomson T₀ = 2π·√(L·C).",
                        "Conservation de l'énergie totale sans amortissement et dissipation par effet Joule avec R."
                    ),
                    keyFormulas = listOf(
                        "ميكانيك: d²x/dt² + ω₀²·x = 0  حيث  ω₀ = √(k/m)  و  T₀ = 2π·√(m/k)",
                        "كهرباء: d²u_C/dt² + ω₀²·u_C = 0  حيث  ω₀ = 1/√(L·C)  و  T₀ = 2π·√(L·C)"
                    ),
                    estimatedMinutes = 45,
                    trimester = 3,
                    scheduleTimelineAr = "أفريل – ماي • الأسابيع 33–34 (06 سا + 02 أ.م)",
                    scheduleTimelineFr = "Avril – Mai • Semaines 33–34 (06h + 02 TP)",
                    progressionPercentage = 100
                )
            )
        ),

        // =====================================================================
        // 3. الرياضيات (Mathématiques) — التوزيع السنوي الرسمي (3 ثانوي 2025/2026)
        // =====================================================================
        Subject(
            id = "math",
            nameAr = "الرياضيات",
            nameFr = "Mathématiques",
            coefficientsByStream = mapOf(
                AcademicStream.SCIENCES_EXP to 5,
                AcademicStream.MATH to 7,
                AcademicStream.TECH_MATH to 6,
                AcademicStream.GESTION_ECO to 5,
                AcademicStream.LETTRES_PHILO to 2,
                AcademicStream.LANGUES to 2
            ),
            accentHex = 0xFF064E3BL,
            lessons = listOf(
                Lesson(
                    id = "math_limits",
                    subjectId = "math",
                    unitNumber = 1,
                    titleAr = "الاشتقاقية والاستمرارية والنهايات",
                    titleFr = "Dérivabilité, Continuité et Limites",
                    curriculumCompetencyAr = "المحور 01 & 03: الاستمرارية، مبرهنة القيم المتوسطة TVI، اشتقاق الدالة المركبة، نقطة الانعطاف، والمستقيمات المقاربة",
                    curriculumCompetencyFr = "Axes 01 & 03 : Continuité, TVI, dérivée composée, point d'inflexion et asymptotes",
                    summaryPointsAr = listOf(
                        "مبرهنة القيم المتوسطة (TVI): إذا كانت f مستمرة ورتيبة تماماً على [a,b] وكان f(a)×f(b) < 0 فإن المعادلة f(x)=0 تقبل حلاً وحيداً α في ]a,b[.",
                        "مشتقة الدالة المركبة (v∘u)'(x) = u'(x)·v'(u(x))، ونقطة الانعطاف هي النقطة التي تنعدم عندها المشتقة الثانية f'' وتغير إشارتها.",
                        "المستقيم المقارب المائل: إذا كانت lim [f(x) - (ax+b)] = 0 بجوار ±∞ فإن y = ax+b مقارب مائل."
                    ),
                    summaryPointsFr = listOf(
                        "Théorème des Valeurs Intermédiaires (TVI) sur [a,b] pour f continue et strictement monotone.",
                        "Dérivée d'une fonction composée et point d'inflexion (annulation de f'' avec changement de signe).",
                        "Asymptote oblique : lim [f(x) - (ax+b)] = 0 en ±∞."
                    ),
                    keyFormulas = listOf(
                        "T : y = f'(x₀)(x - x₀) + f(x₀)  |  f(a)·f(b) < 0 ⇒ ∃! α ∈ ]a,b[ : f(α) = 0",
                        "lim (x→0) [sin(x)/x] = 1  |  lim (x→±∞) [f(x) - (ax+b)] = 0"
                    ),
                    estimatedMinutes = 50,
                    trimester = 1,
                    scheduleTimelineAr = "سبتمبر – أكتوبر • الأسابيع 02–03 و 06",
                    scheduleTimelineFr = "Septembre – Octobre • Semaines 02–03 et 06",
                    progressionPercentage = 18
                ),
                Lesson(
                    id = "math_exp_ln",
                    subjectId = "math",
                    unitNumber = 2,
                    titleAr = "الدالتان الأسية واللوغاريتمية والتزايد المقارن",
                    titleFr = "Fonctions Exponentielle, Logarithme et Croissances Comparées",
                    curriculumCompetencyAr = "المحور 02 & 03: خواص exp و ln، دوال القوى، التزايد المقارن، والمعادلات التفاضلية y' = ay + b",
                    curriculumCompetencyFr = "Axes 02 & 03 : Propriétés de exp et ln, croissances comparées et équations y' = ay + b",
                    summaryPointsAr = listOf(
                        "الدالة الأسية exp والدالة اللوغاريتمية النيبيرية ln متعاكستان: من أجل x>0 لدينا e^(ln x) = x ومن أجل كل y لدينا ln(e^y) = y.",
                        "التزايد المقارن بجوار +∞: الدالة الأسية تغلب دوال القوى x^n، ودوال القوى تغلب الدالة اللوغاريتمية ln(x).",
                        "حلول المعادلة التفاضلية y' = a·y + b (مع a≠0) على R هي الدوال f(x) = C·e^(ax) - b/a."
                    ),
                    summaryPointsFr = listOf(
                        "Réciprocité de exp et ln : e^(ln x) = x (x > 0) et ln(e^y) = y.",
                        "Croissances comparées en +∞ : exp(x) l'emporte sur x^n, qui l'emporte sur ln(x).",
                        "Solutions de l'équation différentielle y' = a·y + b : f(x) = C·e^(ax) - b/a."
                    ),
                    keyFormulas = listOf(
                        "lim (x→+∞) [e^x / x^n] = +∞  |  lim (x→-∞) [x^n · e^x] = 0  |  lim (x→0) [(e^x - 1)/x] = 1",
                        "lim (x→+∞) [ln(x) / x^n] = 0  |  lim (x→0⁺) [x^n · ln(x)] = 0  |  y' = ay+b ⇔ y = C·e^(ax) - b/a"
                    ),
                    estimatedMinutes = 55,
                    trimester = 1,
                    scheduleTimelineAr = "أكتوبر – نوفمبر • الأسابيع 04–05 و 07–08",
                    scheduleTimelineFr = "Octobre – Novembre • Semaines 04–05 et 07–08",
                    progressionPercentage = 34
                ),
                Lesson(
                    id = "math_sequences",
                    subjectId = "math",
                    unitNumber = 3,
                    titleAr = "المتتاليات العددية والبرهان بالتراجع",
                    titleFr = "Suites Numériques et Raisonnement par Récurrence",
                    curriculumCompetencyAr = "المحور 04: توليد متتالية، المتتالية الحسابية والهندسية، الاستدلال بالتراجع، والمتتاليتان المتجاورتان",
                    curriculumCompetencyFr = "Axe 04 : Suites arithmétiques, géométriques, récurrence et suites adjacentes",
                    summaryPointsAr = listOf(
                        "الاستدلال بالتراجع: التحقق من صحة الخاصية P(n₀) في البداية، ثم فرض صحتها عند n والبرهان على صحتها عند n+1.",
                        "التقارب المطرد: كل متتالية متزايدة ومحدودة من الأعلى متقاربة، وكل متتالية متناقصة ومحدودة من الأدنى متقاربة.",
                        "المتتاليتان المتجاورتان: إذا كانت إحداهما متزايدة والأخرى متناقصة ونهاية فرقهما lim (u_n - v_n) = 0 فهما متقاربتان نحو نفس النهاية l."
                    ),
                    summaryPointsFr = listOf(
                        "Raisonnement par récurrence : initialisation, hérédité et conclusion.",
                        "Théorème de convergence monotone (croissante majorée / décroissante minorée).",
                        "Suites adjacentes : l'une croissante, l'autre décroissante et lim (u_n - v_n) = 0."
                    ),
                    keyFormulas = listOf(
                        "حسابية: u_n = u_p + (n - p)·r  |  هندسية: v_n = v_p · q^(n - p)",
                        "مجموع هندسية (q≠1): S = v₀ · (1 - q^N) / (1 - q)"
                    ),
                    estimatedMinutes = 50,
                    trimester = 1,
                    scheduleTimelineAr = "نوفمبر – ديسمبر • الأسابيع 09–11",
                    scheduleTimelineFr = "Novembre – Décembre • Semaines 09–11",
                    progressionPercentage = 46
                ),
                Lesson(
                    id = "math_integrals",
                    subjectId = "math",
                    unitNumber = 4,
                    titleAr = "الدوال الأصلية والحساب التكاملي",
                    titleFr = "Primitives et Calcul Intégral",
                    curriculumCompetencyAr = "المحور 05: تعيين الدوال الأصلية، حساب المساحات والحجوم، القيمة المتوسطة، والتكامل بالتجزئة",
                    curriculumCompetencyFr = "Axe 05 : Primitives, calcul d'aires et de volumes, valeur moyenne et intégration par parties",
                    summaryPointsAr = listOf(
                        "كل دالة مستمرة على مجال I تقبل ما لا نهاية من الدوال الأصلية تختلف عن بعضها بثابت حقيقي C، وتوجد دالة أصلية وحيدة تحقق الشرط F(x₀) = y₀.",
                        "القيمة المتوسطة لدالة مستمرة f على مجال [a,b] هي μ = [1 / (b - a)] · ∫(a→b) f(x) dx.",
                        "التكامل بالتجزئة: ∫(a→b) u(x)·v'(x) dx = [u(x)·v(x)]_(a→b) - ∫(a→b) u'(x)·v(x) dx."
                    ),
                    summaryPointsFr = listOf(
                        "Unique primitive F d'une fonction continue f sur I vérifiant la condition initiale F(x₀) = y₀.",
                        "Valeur moyenne sur [a,b] : μ = [1 / (b - a)] · ∫(a→b) f(x) dx.",
                        "Intégration par parties et calcul de volumes de solides de révolution V = π · ∫ [f(x)]² dx."
                    ),
                    keyFormulas = listOf(
                        "∫(a→b) f(x) dx = F(b) - F(a)  |  μ = [1 / (b - a)] · ∫(a→b) f(x) dx",
                        "∫ u·v' dx = [u·v] - ∫ u'·v dx  |  V = π · ∫(a→b) [f(x)]² dx"
                    ),
                    estimatedMinutes = 50,
                    trimester = 2,
                    scheduleTimelineAr = "جانفي • الأسابيع 12–14",
                    scheduleTimelineFr = "Janvier • Semaines 12–14",
                    progressionPercentage = 58
                ),
                Lesson(
                    id = "math_arithmetic_z",
                    subjectId = "math",
                    unitNumber = 5,
                    titleAr = "الأعداد والحساب في Z (الموافقات وبيزو وغوص)",
                    titleFr = "Arithmétique dans Z (Congruences, Bézout et Gauss)",
                    curriculumCompetencyAr = "المحور 06 (شعبتا الرياضيات وتقني رياضي): القسمة الإقليدية، الموافقات في Z، التعداد، ومبرهنتا بيزو وغوص",
                    curriculumCompetencyFr = "Axe 06 (Maths & Tech-Maths) : Division euclidienne, congruences, numération, Bézout et Gauss",
                    summaryPointsAr = listOf(
                        "الموافقات في Z: نقول إن a ≡ b [n] إذا وفقط إذا كان (a - b) مضاعفاً للعدد الطبيعي غير المعدوم n.",
                        "مبرهنة بيزو: يكون العددان الصحيحان a و b أوليين فيما بينهما (PGCD(a,b) = 1) إذا وفقط إذا وُجد عددان صحيحان u و v يحققان a·u + b·v = 1.",
                        "مبرهنة غوص: إذا كان a يقسم الجداء b·c وكان a أولياً مع b، فإن a يقسم حتماً c."
                    ),
                    summaryPointsFr = listOf(
                        "Congruence modulo n : a ≡ b [n] si et seulement si n divise (a - b).",
                        "Théorème de Bézout : PGCD(a,b) = 1 ⇔ ∃ (u,v) ∈ Z² tels que a·u + b·v = 1.",
                        "Théorème de Gauss : Si a divise b·c et PGCD(a,b) = 1, alors a divise c."
                    ),
                    keyFormulas = listOf(
                        "a = b·q + r (0 ≤ r < b)  |  PGCD(a, b) × PPCM(a, b) = |a × b|",
                        "بيزو: PGCD(a,b) = 1 ⇔ a·u + b·v = 1  |  غوص: (a | bc ∧ PGCD(a,b)=1) ⇒ a | c"
                    ),
                    estimatedMinutes = 55,
                    trimester = 2,
                    scheduleTimelineAr = "جانفي – فيفري • الأسابيع 15–17",
                    scheduleTimelineFr = "Janvier – Février • Semaines 15–17",
                    progressionPercentage = 72
                ),
                Lesson(
                    id = "math_probabilities",
                    subjectId = "math",
                    unitNumber = 6,
                    titleAr = "العد والاحتمالات (التحليل التوفيقي والاحتمالات الشرطية)",
                    titleFr = "Dénombrement et Probabilités Conditionnelles",
                    curriculumCompetencyAr = "المحور 07: القوائم والترتيبات والتوفيقات، المتغير العشوائي، دستور ثنائي الحد، ودستور الاحتمالات الكلية",
                    curriculumCompetencyFr = "Axe 07 : Analyse combinatoire, variable aléatoire, binôme de Newton et probabilités totales",
                    summaryPointsAr = listOf(
                        "طرق السحب القياسية: السحب في آن واحد يوظف التوفيقات C_n^p، السحب على التوالي دون إرجاع يوظف الترتيبات A_n^p، والسحب على التوالي مع الإرجاع يوظف القوائم n^p.",
                        "الأمل الرياضياتي E(X) = Σ x_i · P(X = x_i)، والتباين V(X) = E(X²) - [E(X)]²، والانحراف المعياري σ(X) = √V(X).",
                        "الاحتمال الشرطي: P_A(B) = P(A ∩ B) / P(A)، وتكون الحادثتان A و B مستقلتين إذا وفقط إذا كان P(A ∩ B) = P(A) × P(B)."
                    ),
                    summaryPointsFr = listOf(
                        "Tirages : simultané → Combinaisons C_n^p ; successif sans remise → Arrangements A_n^p ; avec remise → n^p.",
                        "Variable aléatoire : Espérance E(X), Variance V(X) = E(X²) - [E(X)]² et écart-type σ(X).",
                        "Probabilité conditionnelle P_A(B) = P(A ∩ B)/P(A) et formule des probabilités totales."
                    ),
                    keyFormulas = listOf(
                        "C_n^p = n! / [p! · (n - p)!]  |  A_n^p = n! / (n - p)!",
                        "P_A(B) = P(A ∩ B) / P(A)  |  E(X) = Σ x_i·p_i  |  V(X) = Σ x_i²·p_i - [E(X)]²"
                    ),
                    estimatedMinutes = 45,
                    trimester = 2,
                    scheduleTimelineAr = "فيفري • الأسابيع 18–19",
                    scheduleTimelineFr = "Février • Semaines 18–19",
                    progressionPercentage = 82
                ),
                Lesson(
                    id = "math_complex_space",
                    subjectId = "math",
                    unitNumber = 7,
                    titleAr = "الأعداد المركبة والتحويلات النقطية والهندسة في الفضاء",
                    titleFr = "Nombres Complexes, Transformations et Géométrie dans l'Espace",
                    curriculumCompetencyAr = "المحوران 08 & 09: الشكل الأسي أولر، دستور موافر، التحويلات النقطية والتشابهات المباشرة، والجداء السلمي في الفضاء",
                    curriculumCompetencyFr = "Axes 08 & 09 : Notation d'Euler, Moivre, similitudes directes et géométrie dans l'espace",
                    summaryPointsAr = listOf(
                        "الشكل المثلثي والأسي لعدد مركب غير معدوم: z = r(cos θ + i sin θ) = r·e^(iθ) ودستور موافر (cos θ + i sin θ)^n = cos(nθ) + i sin(nθ).",
                        "التحويل النقطي z' = a·z + b: إذا كان a=1 فهو انسحاب؛ إذا كان a حقيقي يختلف عن 0 و1 فهو تحاكٍ؛ إذا كان |a|=1 وa≠1 فهو دوران؛ وفي الحالة العامة تشابه مباشر نسبته |a| وزاويته arg(a).",
                        "الهندسة في الفضاء: معادلة مستوٍ ناظمي n(a,b,c) هي ax + by + cz + d = 0، والمسافة بين نقطة A(x₀,y₀,z₀) والمستوي هي d = |ax₀+by₀+cz₀+d| / √(a²+b²+c²)."
                    ),
                    summaryPointsFr = listOf(
                        "Forme exponentielle z = r·e^(iθ), formule de Moivre et interprétation géométrique du module et de l'argument.",
                        "Similitude plane directe z' = a·z + b (translation, homothétie, rotation) de rapport |a| et d'angle arg(a).",
                        "Géométrie dans l'espace : produit scalaire, équation cartésienne d'un plan et distance point-plan."
                    ),
                    keyFormulas = listOf(
                        "z = r·e^(iθ)  |  (e^(iθ))^n = e^(inθ)  |  z' - ω = k·e^(iθ)·(z - ω)",
                        "d(A, (P)) = |a·x_A + b·y_A + c·z_A + d| / √(a² + b² + c²)"
                    ),
                    estimatedMinutes = 60,
                    trimester = 3,
                    scheduleTimelineAr = "مارس – ماي • الأسابيع 21–26",
                    scheduleTimelineFr = "Mars – Mai • Semaines 21–26",
                    progressionPercentage = 100
                )
            )
        ),

        // =====================================================================
        // 4. الفلسفة (Philosophie)
        // =====================================================================
        Subject(
            id = "philosophy",
            nameAr = "الفلسفة",
            nameFr = "Philosophie",
            coefficientsByStream = mapOf(
                AcademicStream.SCIENCES_EXP to 2,
                AcademicStream.MATH to 2,
                AcademicStream.TECH_MATH to 2,
                AcademicStream.GESTION_ECO to 2,
                AcademicStream.LETTRES_PHILO to 6,
                AcademicStream.LANGUES to 2
            ),
            accentHex = 0xFFB45309L,
            lessons = listOf(
                Lesson(
                    id = "philo_method",
                    subjectId = "philosophy",
                    unitNumber = 1,
                    titleAr = "منهجيات المقال الفلسفي (الجدل، الاستقصاء، المقارنة)",
                    titleFr = "Méthodologies de la dissertation philosophique",
                    curriculumCompetencyAr = "الإشكالية الأولى: ضبط خطوات بناء المقال الفلسفي وفق سلم التنقيط الرسمي للبكالوريا",
                    curriculumCompetencyFr = "Problématique 01 : Maîtriser les étapes de la dissertation selon le barème officiel",
                    summaryPointsAr = listOf(
                        "الطريقة الجدلية: طرح المشكلة (تمهيد + عناد فكري + سؤال) ← الأطروحة الأولى ونقدها ← نقيض الأطروحة ونقده ← التركيب/التجاوز ← حل المشكلة.",
                        "الاستقصاء بالوضع: الدفاع عن أطروحة تبدو غير شائعة عبر عرض منطقها، تدعيمها بحجج شخصية، ودحض حجج الخصوم.",
                        "طريقة المقارنة: أوجه الاختلاف، أوجه التشابه، ومواطن التداخل الوظيفي بين مفهومين (مثل المشكلة والإشكالية، أو الرياضيات الكلاسيكية والمعاصرة)."
                    ),
                    summaryPointsFr = listOf(
                        "Méthode dialectique : Thèse + critique → Antithèse + critique → Synthèse/Dépassement → Conclusion.",
                        "Investigation par affirmation : Défendre une thèse avec arguments personnels et réfutation des adversaires.",
                        "Comparaison : Différences, ressemblances et rapport d'interdépendance."
                    ),
                    keyFormulas = listOf(
                        "طرح المشكلة (4 ن) + محاولة حل المشكلة (12 ن) + حل المشكلة (4 ن) = 20/20"
                    ),
                    estimatedMinutes = 35,
                    trimester = 1,
                    scheduleTimelineAr = "الفصل الأول والثاني • منهجية رسمية",
                    scheduleTimelineFr = "Trimestres 1 & 2 • Méthodologie officielle",
                    progressionPercentage = 50
                )
            )
        ),

        // =====================================================================
        // 5. العلوم الإسلامية (Sciences Islamiques)
        // =====================================================================
        Subject(
            id = "islamic",
            nameAr = "العلوم الإسلامية",
            nameFr = "Sciences Islamiques",
            coefficientsByStream = mapOf(
                AcademicStream.SCIENCES_EXP to 2,
                AcademicStream.MATH to 2,
                AcademicStream.TECH_MATH to 2,
                AcademicStream.GESTION_ECO to 2,
                AcademicStream.LETTRES_PHILO to 2,
                AcademicStream.LANGUES to 2
            ),
            accentHex = 0xFF047857L,
            lessons = listOf(
                Lesson(
                    id = "islamic_maqasid",
                    subjectId = "islamic",
                    unitNumber = 1,
                    titleAr = "العقيدة الإسلامية ومقاصد الشريعة ومصادر التشريع",
                    titleFr = "Dogme islamique, Maqasid al-Charia et Sources législatives",
                    curriculumCompetencyAr = "الوحدات التأسيسية: ترتيب مقاصد الشريعة (الضروريات، الحاجيات، التحسينيات) ومصادر التشريع",
                    curriculumCompetencyFr = "Unités fondamentales : Hiérarchie des Maqasid et sources de la législation",
                    summaryPointsAr = listOf(
                        "مقاصد الشريعة ثلاثة أقسام مرتبة حسب الأهمية: الضروريات، ثم الحاجيات، ثم التحسينيات.",
                        "الكليات الخمس الضرورية مرتبة: حفظ الدين، حفظ النفس، حفظ العقل، حفظ النسل (العِرض)، وحفظ المال.",
                        "من مصادر التشريع المرنة لبيان مرونة الشريعة: الإجماع، القياس، والمصالح المرسلة."
                    ),
                    summaryPointsFr = listOf(
                        "Trois niveaux de Maqasid : Daruriyyat (Nécessités), Hajiyyat (Besoins), Tahsiniyyat (Améliorations).",
                        "Les 5 nécessités : Religion, Vie, Raison, Descendance, Biens.",
                        "Sources législatives : Ijma, Qiyas et Masalih Mursala."
                    ),
                    keyFormulas = listOf(
                        "الضروريات الخمس: الدين ← النفس ← العقل ← النسل ← المال"
                    ),
                    estimatedMinutes = 30,
                    trimester = 1,
                    scheduleTimelineAr = "الفصل الأول والثاني • الوحدات المقررة",
                    scheduleTimelineFr = "Trimestres 1 & 2 • Unités au programme",
                    progressionPercentage = 60
                )
            )
        ),

        // =====================================================================
        // 6. التاريخ والجغرافيا (Histoire et Géographie)
        // =====================================================================
        Subject(
            id = "hist_geo",
            nameAr = "التاريخ والجغرافيا",
            nameFr = "Histoire et Géographie",
            coefficientsByStream = mapOf(
                AcademicStream.SCIENCES_EXP to 2,
                AcademicStream.MATH to 2,
                AcademicStream.TECH_MATH to 2,
                AcademicStream.GESTION_ECO to 4,
                AcademicStream.LETTRES_PHILO to 4,
                AcademicStream.LANGUES to 2
            ),
            accentHex = 0xFF7C2D12L,
            lessons = listOf(
                Lesson(
                    id = "hist_revolution",
                    subjectId = "hist_geo",
                    unitNumber = 2,
                    titleAr = "الثورة التحريرية الجزائرية الكبرى (1954–1962)",
                    titleFr = "La Révolution Algérienne (1954–1962)",
                    curriculumCompetencyAr = "الوحدة التعلمية 02: العمل المسلح ورد فعل الاستعمار، مؤتمر الصومام، واستعادة السيادة الوطنية",
                    curriculumCompetencyFr = "Unité 02 : Action armée, Congrès de la Soummam et recouvrement de la souveraineté",
                    summaryPointsAr = listOf(
                        "مؤتمر الصومام (20 أوت 1956): التنظيم المؤسساتي والعسكري للثورة (المجلس الوطني للثورة CNRA ولجنة التنسيق والتنفيذ CCE) وتقسيم الجزائر إلى 6 ولايات تاريخية.",
                        "المخططات الاستعمارية: مخطط شال وموريس (الأسلاك الشائكة المكهربة)، المحتشدات، ومشروع قسنطينة الإغرائي (1958).",
                        "مفاوضات إيفيان وتوقيع وقف إطلاق النار في 19 مارس 1962 واستفتاء تقرير المصير في 1 جويلية 1962."
                    ),
                    summaryPointsFr = listOf(
                        "Congrès de la Soummam (20 août 1956) : Structuration politique et militaire (CNRA, CCE, 6 Wilayas historiques).",
                        "Plans coloniaux : Lignes Challe et Morice, Plan de Constantine (1958).",
                        "Accords d'Évian, cessez-le-feu du 19 mars 1962 et indépendance le 5 juillet 1962."
                    ),
                    keyFormulas = listOf(
                        "01 نوفمبر 1954 ← 20 أوت 1955 (هجومات الشمال القسنطيني) ← 20 أوت 1956 (مؤتمر الصومام) ← 19 مارس 1962 (وقف إطلاق النار)"
                    ),
                    estimatedMinutes = 40,
                    trimester = 2,
                    scheduleTimelineAr = "الفصل الثاني • الوحدة التعلمية الثانية",
                    scheduleTimelineFr = "Trimestre 2 • Unité d'apprentissage 02",
                    progressionPercentage = 65
                )
            )
        )
    )

    // -----------------------------------------------------------------------
    // Flagship Hand-Crafted Seed Questions + 1,125+ Ordered Bank (Unit 01 -> Last Unit)
    // -----------------------------------------------------------------------
    private val flagshipQuestions: List<Question> = listOf(
        // 1. Math - Single Choice (TVI)
        Question(
            id = "q_math_tvi_1",
            subjectId = "math",
            lessonId = "math_limits",
            streams = AcademicStream.entries,
            type = QuestionType.SINGLE_CHOICE,
            difficulty = DifficultyLevel.BAC_LEVEL,
            provenance = QuestionProvenance.CURRICULUM_VERIFIED,
            sourceCitationAr = "التوزيع السنوي الرسمي لمادة الرياضيات — محور الاشتقاقية والاستمرارية",
            sourceCitationFr = "Progression annuelle officielle de Mathématiques — Continuité et Dérivabilité",
            curriculumMappingAr = "المحور 01: مبرهنة القيم المتوسطة وإثبات وحدانية الحل",
            curriculumMappingFr = "Axe 01 : Théorème des valeurs intermédiaires",
            stemAr = "لتكن الدالة f المعرفة والمستمرة على المجال [1, 2] بـ: f(x) = x³ + 2x - 5. ما هو الشرط الكافي لإثبات أن المعادلة f(x) = 0 تقبل حلاً وحيداً α في المجال المفتوح ]1, 2[؟",
            stemFr = "Soit f la fonction définie sur [1, 2] par f(x) = x³ + 2x - 5. Quelle condition justifie l'existence d'une unique solution α à f(x) = 0 dans ]1, 2[ ?",
            optionsAr = listOf(
                "الدالة f مستمرة ورتيبة تماماً (متزايدة تماماً) على [1, 2] و f(1)×f(2) = (-2)×(7) < 0",
                "الدالة f تقبل الاشتقاق عند 1 و 2 ومجموع f(1) + f(2) موجب",
                "المنحنى (Cf) يقبل مماساً أفقياً عند النقطة ذات الفاصلة 1",
                "نهاية الدالة f عند +∞ تساوي +∞ فقط"
            ),
            optionsFr = listOf(
                "f est continue et strictement croissante sur [1, 2] et f(1)×f(2) = (-2)×(7) < 0",
                "f est dérivable en 1 et 2 et f(1) + f(2) > 0",
                "La courbe (Cf) admet une tangente horizontale en x = 1",
                "La limite de f en +∞ vaut +∞ uniquement"
            ),
            correctIndices = listOf(0),
            explanationAr = "بما أن f دالة كثير حدود فهي مستمرة وقابلة للاشتقاق على [1, 2]، ومشتقتها f'(x) = 3x² + 2 > 0 موجبة تماماً، إذن f متزايدة تماماً. ولدينا f(1) = -2 و f(2) = 7 أي f(1)×f(2) < 0. حسب مبرهنة القيم المتوسطة للمعادلة f(x)=0 حل وحيد α في ]1, 2[.",
            explanationFr = "f est continue sur [1, 2] et strictement croissante car f'(x) = 3x² + 2 > 0. De plus, f(1) = -2 et f(2) = 7 sont de signes contraires. D'après le TVI, l'équation f(x) = 0 admet une unique solution α dans ]1, 2[."
        ),

        // 2. Math - Multiple Choice (Exp & Ln)
        Question(
            id = "q_math_exp_2",
            subjectId = "math",
            lessonId = "math_exp_ln",
            streams = listOf(AcademicStream.SCIENCES_EXP, AcademicStream.MATH, AcademicStream.TECH_MATH, AcademicStream.GESTION_ECO),
            type = QuestionType.MULTIPLE_CHOICE,
            difficulty = DifficultyLevel.HARD,
            provenance = QuestionProvenance.CURRICULUM_VERIFIED,
            sourceCitationAr = "التوزيع السنوي لمادة الرياضيات — محور التزايد المقارن والدوال الأسية",
            sourceCitationFr = "Progression officielle — Croissances comparées et fonction exponentielle",
            curriculumMappingAr = "المحور 02 & 03: النهايات الشهيرة والتزايد المقارن (الأسبوع 07)",
            curriculumMappingFr = "Axes 02 & 03 : Limites de référence et croissances comparées",
            stemAr = "اختر كل النهايات الصحيحة من بين العلاقات التالية الخاصة بالدالة الأسية واللوغاريتمية:",
            stemFr = "Sélectionnez toutes les limites exactes parmi les propositions suivantes :",
            optionsAr = listOf(
                "lim (x→+∞) [x · e^(-x)] = 0",
                "lim (x→0) [(e^x - 1) / x] = 1",
                "lim (x→+∞) [ln(x) / x] = +∞",
                "lim (x→0⁺) [x · ln(x)] = 0"
            ),
            optionsFr = listOf(
                "lim (x→+∞) [x · e^(-x)] = 0",
                "lim (x→0) [(e^x - 1) / x] = 1",
                "lim (x→+∞) [ln(x) / x] = +∞",
                "lim (x→0⁺) [x · ln(x)] = 0"
            ),
            correctIndices = listOf(0, 1, 3),
            explanationAr = "العبارات (1) و(2) و(4) هي نهايات شهيرة صحيحة في البرنامج الرسمي. أما العبارة (3) فخاطئة لأن lim (x→+∞) [ln(x)/x] = 0 بالتزايد المقارن وليس +∞.",
            explanationFr = "Les propositions 1, 2 et 4 sont des limites de référence exactes. La proposition 3 est fausse car lim (x→+∞) [ln(x)/x] = 0 par croissance comparée."
        ),

        // 3. Math - Structured Bac Question (Sequences)
        Question(
            id = "q_math_seq_3",
            subjectId = "math",
            lessonId = "math_sequences",
            streams = listOf(AcademicStream.SCIENCES_EXP, AcademicStream.MATH, AcademicStream.TECH_MATH, AcademicStream.GESTION_ECO),
            type = QuestionType.STRUCTURED,
            difficulty = DifficultyLevel.BAC_LEVEL,
            provenance = QuestionProvenance.CURRICULUM_VERIFIED,
            sourceCitationAr = "التوزيع السنوي لمادة الرياضيات — المتتاليات العددية (الأسبوع 09–11)",
            sourceCitationFr = "Progression officielle — Suites numériques",
            curriculumMappingAr = "المحور 04: المتتاليات التراجعية والمتتالية الهندسية المساعدة",
            curriculumMappingFr = "Axe 04 : Suites récurrentes et suite géométrique auxiliaire",
            stemAr = "لتكن المتتالية (u_n) المعرفة بـ u₀ = 5 ومن أجل كل عدد طبيعي n: u_(n+1) = (1/2)u_n + 2. نضع v_n = u_n - 4. ما هي طبيعة المتتالية (v_n) ونهاية المتتالية (u_n)؟",
            stemFr = "Soit (u_n) définie par u₀ = 5 et u_(n+1) = (1/2)u_n + 2. On pose v_n = u_n - 4. Quelle est la nature de (v_n) et la limite de (u_n) ?",
            optionsAr = listOf(
                "(v_n) متتالية هندسية أساسها q = 1/2 وحدها الأول v₀ = 1، ونهاية (u_n) هي l = 4",
                "(v_n) متتالية حسابية أساسها r = 2، ونهاية (u_n) هي +∞",
                "(v_n) متتالية هندسية أساسها q = 2، ونهاية (u_n) هي 0",
                "(v_n) متتالية ثابتة، ونهاية (u_n) هي 5"
            ),
            optionsFr = listOf(
                "(v_n) est géométrique de raison q = 1/2 et v₀ = 1, et lim u_n = 4",
                "(v_n) est arithmétique de raison r = 2, et lim u_n = +∞",
                "(v_n) est géométrique de raison q = 2, et lim u_n = 0",
                "(v_n) est constante, et lim u_n = 5"
            ),
            correctIndices = listOf(0),
            structuredRubricStepsAr = listOf(
                "الخطوة 1 (0.5 ن): حساب v_(n+1) = u_(n+1) - 4 = (1/2)u_n + 2 - 4 = (1/2)(u_n - 4) = (1/2)v_n.",
                "الخطوة 2 (0.5 ن): استنتاج أن (v_n) هندسية أساسها q = 1/2 وحدها الأول v₀ = u₀ - 4 = 1.",
                "الخطوة 3 (0.5 ن): كتابة عبارة الحد العام: v_n = (1/2)^n ومنه u_n = 4 + (1/2)^n.",
                "الخطوة 4 (0.5 ن): بما أن -1 < 1/2 < 1 فإن lim (1/2)^n = 0 ومنه lim u_n = 4."
            ),
            structuredRubricStepsFr = listOf(
                "Étape 1 (0,5 pt) : Calculer v_(n+1) = u_(n+1) - 4 = (1/2)(u_n - 4) = (1/2)v_n.",
                "Étape 2 (0,5 pt) : Conclure que (v_n) est géométrique de raison q = 1/2 et de premier terme v₀ = 1.",
                "Étape 3 (0,5 pt) : Exprimer u_n en fonction de n : u_n = 4 + (1/2)^n.",
                "Étape 4 (0,5 pt) : Comme -1 < 1/2 < 1, lim (1/2)^n = 0 d'où lim u_n = 4."
            ),
            explanationAr = "بتعويض u_(n+1) نجد v_(n+1) = (1/2)v_n، فهي هندسية أساسها 1/2 وحدها الأول v₀ = 5 - 4 = 1. وبما أن الأساس محصور بين -1 و 1 فإن v_n تؤول إلى 0 وبالتالي u_n تؤول إلى 4.",
            explanationFr = "On montre que v_(n+1) = (1/2)v_n avec v₀ = 1. La raison 1/2 étant dans ]-1, 1[, v_n tend vers 0 et u_n converge vers 4."
        ),

        // 4. Math - Arithmetic in Z (Bézout & Gauss - Week 15-17)
        Question(
            id = "q_math_z_4",
            subjectId = "math",
            lessonId = "math_arithmetic_z",
            streams = listOf(AcademicStream.MATH, AcademicStream.TECH_MATH),
            type = QuestionType.SINGLE_CHOICE,
            difficulty = DifficultyLevel.BAC_LEVEL,
            provenance = QuestionProvenance.CURRICULUM_VERIFIED,
            sourceCitationAr = "التوزيع السنوي لمادة الرياضيات — الأعداد والحساب (الأسابيع 15–17)",
            sourceCitationFr = "Progression officielle — Arithmétique dans Z (Semaines 15–17)",
            curriculumMappingAr = "المحور 06: الموافقات في Z ومبرهنتا بيزو وغوص",
            curriculumMappingFr = "Axe 06 : Congruences dans Z, théorèmes de Bézout et de Gauss",
            stemAr = "نعتبر في Z² المعادلة الديوفانتية (E): 7x - 5y = 1. علماً أن الثنائية (3, 4) حل خاص للمعادلة (E)، فما هي مجموعة الحلول العامة (x, y) في Z² حيث k عدد صحيح؟",
            stemFr = "Dans Z², on considère l'équation (E) : 7x - 5y = 1, dont (3, 4) est une solution particulière. Quel est l'ensemble des solutions (x, y) avec k ∈ Z ?",
            optionsAr = listOf(
                "(x, y) = (5k + 3 , 7k + 4)",
                "(x, y) = (7k + 3 , 5k + 4)",
                "(x, y) = (5k - 3 , 7k - 4)",
                "(x, y) = (3k + 5 , 4k + 7)"
            ),
            optionsFr = listOf(
                "(x, y) = (5k + 3 , 7k + 4)",
                "(x, y) = (7k + 3 , 5k + 4)",
                "(x, y) = (5k - 3 , 7k - 4)",
                "(x, y) = (3k + 5 , 4k + 7)"
            ),
            correctIndices = listOf(0),
            explanationAr = "بطرح 7(3) - 5(4) = 1 من 7x - 5y = 1 نجد 7(x - 3) = 5(y - 4). وبما أن PGCD(7, 5) = 1 فإنه حسب مبرهنة غوص يقسم 5 العدد (x - 3) ومنه x - 3 = 5k أي x = 5k + 3، وبتعويضه نجد y = 7k + 4 مع k ∈ Z.",
            explanationFr = "Par soustraction, 7(x - 3) = 5(y - 4). Comme PGCD(7, 5) = 1, d'après le théorème de Gauss, 5 divise (x - 3), donc x = 5k + 3 et y = 7k + 4 (k ∈ Z)."
        ),

        // 5. Math - Complex Numbers & Similitudes (Weeks 21-23)
        Question(
            id = "q_math_complex_5",
            subjectId = "math",
            lessonId = "math_complex_space",
            streams = listOf(AcademicStream.SCIENCES_EXP, AcademicStream.MATH, AcademicStream.TECH_MATH),
            type = QuestionType.SINGLE_CHOICE,
            difficulty = DifficultyLevel.BAC_LEVEL,
            provenance = QuestionProvenance.CURRICULUM_VERIFIED,
            sourceCitationAr = "التوزيع السنوي لمادة الرياضيات — الأعداد المركبة والتحويلات النقطية (الأسابيع 21–23)",
            sourceCitationFr = "Progression officielle — Nombres complexes et similitudes (Semaines 21–23)",
            curriculumMappingAr = "المحور 08: التشابهات المستوية المباشرة والكتابة المركبة z' = az + b",
            curriculumMappingFr = "Axe 08 : Similitudes planes directes d'écriture complexe z' = az + b",
            stemAr = "في المستوي المركب، ما هي الطبيعة والعناصر المميزة للتحويل النقطي S الذي يرفق بكل نقطة M(z) النقطة M'(z') حيث: z' = (1 + i√3)z؟",
            stemFr = "Dans le plan complexe, quelle est la nature et quels sont les éléments caractéristiques de la transformation S d'écriture z' = (1 + i√3)z ?",
            optionsAr = listOf(
                "تشابه مباشر مركزه المبدأ O، نسبته k = 2، وزاويته θ = π/3",
                "دوران مركزه المبدأ O وزاويته θ = π/6",
                "تحاكٍ مركزه المبدأ O ونسبته k = √3",
                "تشابه مباشر مركزه المبدأ O، نسبته k = 4، وزاويته θ = 2π/3"
            ),
            optionsFr = listOf(
                "Similitude directe de centre O, de rapport k = 2 et d'angle θ = π/3",
                "Rotation de centre O et d'angle θ = π/6",
                "Homothétie de centre O et de rapport k = √3",
                "Similitude directe de centre O, de rapport k = 4 et d'angle θ = 2π/3"
            ),
            correctIndices = listOf(0),
            explanationAr = "نكتب العدد المركب a = 1 + i√3 على الشكل الأسي: الطويلة |a| = √(1² + (√3)²) = 2، والعمدة θ تحقق cos θ = 1/2 و sin θ = √3/2 أي θ = π/3. إذن a = 2·e^(iπ/3) والتحويل تشابه مباشر مركزه O(0) ونسبته 2 وزاويته π/3.",
            explanationFr = "Le nombre complexe a = 1 + i√3 a pour module |a| = 2 et pour argument π/3. S est donc une similitude directe de centre O, de rapport 2 et d'angle π/3."
        ),

        // 6. Physics - Single Choice (Kinetics - Unit 01)
        Question(
            id = "q_phys_kinetics_1",
            subjectId = "physics",
            lessonId = "phys_kinetics",
            streams = listOf(AcademicStream.SCIENCES_EXP, AcademicStream.MATH, AcademicStream.TECH_MATH),
            type = QuestionType.SINGLE_CHOICE,
            difficulty = DifficultyLevel.BAC_LEVEL,
            provenance = QuestionProvenance.CURRICULUM_VERIFIED,
            sourceCitationAr = "التوزيع السنوي للعلوم الفيزيائية — الوحدة 01: المتابعة الزمنية (الأسابيع 02–04)",
            sourceCitationFr = "Progression officielle de Physique — Unité 01 : Suivi temporel",
            curriculumMappingAr = "الوحدة 01: زمن نصف التفاعل والعوامل الحركية (12%)",
            curriculumMappingFr = "Unité 01 : Temps de demi-réaction et facteurs cinétiques",
            stemAr = "عند رفع درجة حرارة جملة كيميائية لتفاعل تام دون تغيير كميات المادة الابتدائية للمتفاعلات، كيف يتغير كل من زمن نصف التفاعل t½ والتقدم النهائي x_f؟",
            stemFr = "Lorsqu'on augmente la température d'un système chimique pour une réaction totale sans modifier les quantités initiales, comment évoluent t½ et x_f ?",
            optionsAr = listOf(
                "يتناقص زمن نصف التفاعل t½ بينما يبقى التقدم النهائي x_f ثابتاً",
                "يزداد زمن نصف التفاعل t½ ويزداد التقدم النهائي x_f",
                "يبقى زمن نصف التفاعل t½ ثابتاً ويتناقص التقدم النهائي x_f",
                "يتناقص كل من t½ و x_f معاً"
            ),
            optionsFr = listOf(
                "Le temps de demi-réaction t½ diminue tandis que l'avancement final x_f reste inchangé",
                "t½ augmente et x_f augmente",
                "t½ reste constant et x_f diminue",
                "t½ et x_f diminuent tous les deux"
            ),
            correctIndices = listOf(0),
            explanationAr = "درجة الحرارة عامل حركي: رفعها يزيد من التواتر الفعال للاصطدامات الحرارية فتزداد السرعة الحجمية للتفاعل ويقل زمن نصف التفاعل t½، لكنها لا تغير حصيلة المادة النهائية x_f لأن التفاعل تام وكميات المادة الابتدائية لم تتغير.",
            explanationFr = "La température est un facteur cinétique : son élévation accélère la réaction (donc t½ diminue), mais ne modifie pas l'état final x_f qui dépend uniquement des quantités initiales."
        ),

        // 7. Physics - Mechanics (Unit 02 - Weeks 05-10)
        Question(
            id = "q_phys_mech_3",
            subjectId = "physics",
            lessonId = "phys_mechanics",
            streams = listOf(AcademicStream.SCIENCES_EXP, AcademicStream.MATH, AcademicStream.TECH_MATH),
            type = QuestionType.SINGLE_CHOICE,
            difficulty = DifficultyLevel.BAC_LEVEL,
            provenance = QuestionProvenance.CURRICULUM_VERIFIED,
            sourceCitationAr = "التوزيع السنوي للعلوم الفيزيائية — الوحدة 02: تطور جملة ميكانيكية (الأسابيع 05–10)",
            sourceCitationFr = "Progression officielle de Physique — Unité 02 : Systèmes mécaniques",
            curriculumMappingAr = "الوحدة 02: حركة الأقمار الاصطناعية وقانون كبلر الثالث (34%)",
            curriculumMappingFr = "Unité 02 : Mouvement des satellites et 3e loi de Kepler",
            stemAr = "قمر اصطناعي (S) كتلته m يدور حول الأرض (كتلتها M_T) في مسار دائري نصف قطره r بسرعة ثابتة. كيف تتغير سرعته المدارية v ودوره المداري T إذا انتقل إلى مدار دائري أعلى نصف قطره r' > r؟",
            stemFr = "Un satellite (S) décrit une orbite circulaire de rayon r autour de la Terre. Comment évoluent sa vitesse v et sa période T s'il passe sur une orbite plus haute r' > r ?",
            optionsAr = listOf(
                "تتناقص سرعته المدارية v ويزداد دوره المداري T",
                "تزداد سرعته المدارية v ويتناقص دوره المداري T",
                "تبقى سرعته المدارية v ثابتة ويزداد دوره المداري T",
                "تعتمد سرعته المدارية v على كتلة القمر الاصطناعي m فقط"
            ),
            optionsFr = listOf(
                "Sa vitesse orbitale v diminue et sa période T augmente",
                "Sa vitesse v augmente et sa période T diminue",
                "Sa vitesse v reste constante et T augmente",
                "Sa vitesse v dépend uniquement de la masse m du satellite"
            ),
            correctIndices = listOf(0),
            explanationAr = "بتطبيق القانون الثاني لنيوتن نجد v = √(G·M_T / r) و T = 2π·√(r³ / (G·M_T)). كلما زاد نصف قطر المدار r تناقصت السرعة المدارية v وزاد الدور المداري T، وكلاهما مستقل عن كتلة القمر m.",
            explanationFr = "D'après la 2e loi de Newton, v = √(G·M_T / r) et T = 2π·√(r³ / (G·M_T)). Quand r augmente, v diminue et T augmente."
        ),

        // 8. Physics - Structured RC Circuit (Unit 03 - Weeks 11-17)
        Question(
            id = "q_phys_rc_2",
            subjectId = "physics",
            lessonId = "phys_rc",
            streams = listOf(AcademicStream.SCIENCES_EXP, AcademicStream.MATH, AcademicStream.TECH_MATH),
            type = QuestionType.STRUCTURED,
            difficulty = DifficultyLevel.BAC_LEVEL,
            provenance = QuestionProvenance.CURRICULUM_VERIFIED,
            sourceCitationAr = "التوزيع السنوي للعلوم الفيزيائية — الوحدة 03: دراسة ظواهر كهربائية (الأسابيع 11–17)",
            sourceCitationFr = "Programme officiel de Physique — Unité 03 : Dipôle RC",
            curriculumMappingAr = "الوحدة 03: شحن مكثفة، ثابت الزمن τ، والطاقة المخزنة (50%)",
            curriculumMappingFr = "Unité 03 : Charge d'un condensateur, constante τ et énergie",
            stemAr = "نحقق دارة شحن مكثفة سعتها C = 100 μF على التسلسل مع ناقل أومي مقاومته R = 1 kΩ ومولد توتر ثابت E = 6 V. ما هي قيمة ثابت الزمن τ والطاقة العظمى E_c(max) المخزنة في المكثفة؟",
            stemFr = "Un condensateur C = 100 μF est chargé à travers R = 1 kΩ sous E = 6 V. Quelles sont les valeurs de τ et de l'énergie maximale E_c(max) ?",
            optionsAr = listOf(
                "τ = 0.1 s و E_c(max) = 1.8 × 10⁻³ J",
                "τ = 1.0 s و E_c(max) = 3.6 × 10⁻³ J",
                "τ = 0.01 s و E_c(max) = 6.0 × 10⁻⁴ J",
                "τ = 10 s و E_c(max) = 1.8 J"
            ),
            optionsFr = listOf(
                "τ = 0,1 s et E_c(max) = 1,8 × 10⁻³ J",
                "τ = 1,0 s et E_c(max) = 3,6 × 10⁻³ J",
                "τ = 0,01 s et E_c(max) = 6,0 × 10⁻⁴ J",
                "τ = 10 s et E_c(max) = 1,8 J"
            ),
            correctIndices = listOf(0),
            structuredRubricStepsAr = listOf(
                "الخطوة 1 (تحويل الوحدات): R = 10³ Ω و C = 100 × 10⁻⁶ F = 10⁻⁴ F.",
                "الخطوة 2 (حساب ثابت الزمن): τ = R · C = 10³ × 10⁻⁴ = 0.1 s.",
                "الخطوة 3 (عبارة الطاقة العظمى): E_c(max) = ½ · C · E².",
                "الخطوة 4 (التطبيق العددي): E_c(max) = 0.5 × 10⁻⁴ × (6)² = 18 × 10⁻⁴ J = 1.8 × 10⁻³ J."
            ),
            structuredRubricStepsFr = listOf(
                "Étape 1 (Conversions SI) : R = 10³ Ω et C = 10⁻⁴ F.",
                "Étape 2 (Constante de temps) : τ = R · C = 0,1 s.",
                "Étape 3 (Expression de l'énergie) : E_c(max) = ½ · C · E².",
                "Étape 4 (Application numérique) : E_c(max) = 0,5 × 10⁻⁴ × 36 = 1,8 × 10⁻³ J."
            ),
            explanationAr = "نحول السعة إلى الفاراد C = 10⁻⁴ F والمقاومة إلى الأوم R = 10³ Ω، فنجد τ = R·C = 0.1 s. والطاقة العظمى E_c(max) = 0.5 × 10⁻⁴ × 36 = 1.8 × 10⁻³ J.",
            explanationFr = "Avec R = 10³ Ω et C = 10⁻⁴ F, on obtient τ = R·C = 0,1 s et E_c(max) = ½·C·E² = 1,8 × 10⁻³ J."
        ),

        // 9. Physics - Nuclear Transformations (Unit 05 - Weeks 22-24)
        Question(
            id = "q_phys_nuclear_4",
            subjectId = "physics",
            lessonId = "phys_nuclear",
            streams = listOf(AcademicStream.SCIENCES_EXP, AcademicStream.MATH, AcademicStream.TECH_MATH),
            type = QuestionType.SINGLE_CHOICE,
            difficulty = DifficultyLevel.BAC_LEVEL,
            provenance = QuestionProvenance.CURRICULUM_VERIFIED,
            sourceCitationAr = "التوزيع السنوي للعلوم الفيزيائية — الوحدة 05: التحولات النووية (الأسابيع 22–24)",
            sourceCitationFr = "Progression officielle de Physique — Unité 05 : Transformations nucléaires",
            curriculumMappingAr = "الوحدة 05: قانون التناقص الإشعاعي وزمن نصف العمر t½ (76%)",
            curriculumMappingFr = "Unité 05 : Loi de décroissance radioactive et demi-vie t½",
            stemAr = "عينة مشعة تحتوي في اللحظة t = 0 على N₀ من الأنوية المشعة التي زمن نصف عمرها t½. ما هو عدد الأنوية المشعة المتبقية N(t) وعدد الأنوية المتفككة N_d(t) عند اللحظة t = 3 · t½؟",
            stemFr = "Un échantillon radioactif contient N₀ noyaux de demi-vie t½ à t = 0. Quels sont le nombre de noyaux restants N et le nombre de noyaux désintégrés N_d à t = 3 · t½ ?",
            optionsAr = listOf(
                "المتبقية N = N₀ / 8 والمتفككة N_d = (7 / 8) N₀",
                "المتبقية N = N₀ / 3 والمتفككة N_d = (2 / 3) N₀",
                "المتبقية N = N₀ / 6 والمتفككة N_d = (5 / 6) N₀",
                "المتبقية N = N₀ / 4 والمتفككة N_d = (3 / 4) N₀"
            ),
            optionsFr = listOf(
                "Restants N = N₀ / 8 et désintégrés N_d = (7 / 8) N₀",
                "Restants N = N₀ / 3 et désintégrés N_d = (2 / 3) N₀",
                "Restants N = N₀ / 6 et désintégrés N_d = (5 / 6) N₀",
                "Restants N = N₀ / 4 et désintégrés N_d = (3 / 4) N₀"
            ),
            correctIndices = listOf(0),
            explanationAr = "عند اللحظة t = n · t½ يكون عدد الأنوية المتبقية N(n·t½) = N₀ / 2^n. من أجل n = 3 نجد N = N₀ / 2³ = N₀ / 8، وبالتالي عدد الأنوية المتفككة N_d = N₀ - N₀/8 = (7/8) N₀.",
            explanationFr = "À t = n · t½, le nombre de noyaux restants vaut N = N₀ / 2^n. Pour n = 3, N = N₀ / 8 et le nombre de noyaux désintégrés est N_d = N₀ - N = (7/8) N₀."
        ),

        // 10. SVT - True/False (Protein Synthesis)
        Question(
            id = "q_svt_protein_1",
            subjectId = "svt",
            lessonId = "svt_protein",
            streams = listOf(AcademicStream.SCIENCES_EXP, AcademicStream.MATH),
            type = QuestionType.TRUE_FALSE,
            difficulty = DifficultyLevel.MEDIUM,
            provenance = QuestionProvenance.CURRICULUM_VERIFIED,
            sourceCitationAr = "التوزيع السنوي لعلوم الطبيعة والحياة — الوحدة 01: تركيب البروتين (الأسبوع 02)",
            sourceCitationFr = "Programme officiel SVT — Unité 01 : Synthèse des protéines",
            curriculumMappingAr = "المجال 01: التخصص الوظيفي للبروتينات • آلية الاستنساخ",
            curriculumMappingFr = "Domaine 01 : Spécialisation fonctionnelle des protéines • Transcription",
            stemAr = "حدد صحة أو خطأ العبارة العلمية التالية: «أثناء عملية الاستنساخ، يقرأ إنزيم ARN بوليميراز السلسلة المستنسخة للـ ADN في الاتجاه من 3' إلى 5' ويركب جزيئة ARNm في الاتجاه من 5' إلى 3'.»",
            stemFr = "Vrai ou Faux : « Lors de la transcription, l'ARN polymérase parcourt le brin transcrit d'ADN de 3' vers 5' et synthétise l'ARNm de 5' vers 3'. »",
            optionsAr = listOf(
                "صحيح — قراءة السلسلة المستنسخة تتم من 3' نحو 5' واستطالة ARNm تتم من 5' نحو 3'",
                "خطأ — الاستنساخ يتم بقراءة السلسلة غير المستنسخة بإنزيم الريبوزوم"
            ),
            optionsFr = listOf(
                "Vrai — Lecture du brin transcrit 3'→5' et synthèse de l'ARNm 5'→3'",
                "Faux — La transcription est réalisée par le ribosome sur le brin codant"
            ),
            correctIndices = listOf(0),
            explanationAr = "العبارة صحيحة تماماً: إنزيم ARN بوليميراز يرتبط بمنطقة البداية على المورثة ويقرأ السلسلة المستنسخة في الاتجاه 3' → 5' ليقوم بربط النيكليوتيدات الريبية الحرة لتشكيل ARNm في اتجاه الاستطالة الحيوي 5' → 3'.",
            explanationFr = "Exact : l'ARN polymérase lit le brin matrice (transcrit) dans le sens 3' → 5' et polymérise l'ARNm dans le sens 5' → 3'."
        ),

        // 11. SVT - Single Choice (Enzymes - Week 05)
        Question(
            id = "q_svt_enzymes_2",
            subjectId = "svt",
            lessonId = "svt_enzymes",
            streams = listOf(AcademicStream.SCIENCES_EXP),
            type = QuestionType.SINGLE_CHOICE,
            difficulty = DifficultyLevel.BAC_LEVEL,
            provenance = QuestionProvenance.CURRICULUM_VERIFIED,
            sourceCitationAr = "التوزيع السنوي لعلوم الطبيعة والحياة — الوحدة 03: التحفيز الإنزيمي (الأسبوع 05)",
            sourceCitationFr = "Progression officielle SVT — Unité 03 : Catalyse enzymatique",
            curriculumMappingAr = "الوحدة 03: تأثير درجة الحموضة pH ودرجة الحرارة على الموقع الفعال",
            curriculumMappingFr = "Unité 03 : Effet du pH et de la température sur le site actif",
            stemAr = "ما هو التفسير الجزيئي الدقيق لفقدان الإنزيم لنشاطه التحفيزي في وسط ذي درجة حموضة pH بعيدة جداً عن pH الأمثل؟",
            stemFr = "Quelle est l'explication moléculaire exacte de la perte d'activité d'une enzyme à un pH très éloigné du pH optimal ?",
            optionsAr = listOf(
                "تغير الحالة الكهربائية (تأين) المجموعات الكيميائية الحرة في جذور الأحماض الأمينية المشكلة للموقع الفعال مما يعيق تثبيت الركيزة",
                "تكسر الروابط الببتيدية الأولية وتفكك الإنزيم إلى أحماض أمينية حرة",
                "تحول الركيزة تلقائياً إلى ناتج دون الحاجة إلى إنزيم",
                "تضاعف عدد المواقع الفعالة في جزيئة الإنزيم الواحدة"
            ),
            optionsFr = listOf(
                "Modification de l'état ionique des radicaux des acides aminés du site actif, empêchant la fixation du substrat",
                "Hydrolyse complète des liaisons peptidiques de la structure primaire",
                "Transformation spontanée du substrat sans enzyme",
                "Doublement du nombre de sites actifs"
            ),
            correctIndices = listOf(0),
            explanationAr = "تغير pH الوسط عن القيمة المثلى يغير الشحنة الكهربائية الإجمالية للإنزيم وخصوصاً الجذور الحرة للأحماض الأمينية في الموقع الفعال، فيفقد الموقع الفعال شكله المميز ولا يحدث التكامل البنيوي مع الركيزة S.",
            explanationFr = "Un pH éloigné du pH optimal modifie l'état d'ionisation des chaînes latérales des acides aminés du site actif, déformant sa géométrie et empêchant la formation du complexe ES."
        ),

        // 12. SVT - Immunology & VIH (Weeks 06-15)
        Question(
            id = "q_svt_immunity_3",
            subjectId = "svt",
            lessonId = "svt_immunity",
            streams = listOf(AcademicStream.SCIENCES_EXP, AcademicStream.MATH),
            type = QuestionType.SINGLE_CHOICE,
            difficulty = DifficultyLevel.BAC_LEVEL,
            provenance = QuestionProvenance.CURRICULUM_VERIFIED,
            sourceCitationAr = "التوزيع السنوي لعلوم الطبيعة والحياة — الوحدة 04: الدفاع عن الذات (الأسابيع 06–15)",
            sourceCitationFr = "Progression officielle SVT — Unité 04 : Défense du soi et VIH",
            curriculumMappingAr = "الوحدة 04: الرد المناعي الخلوي والتعاون المناعي وفيروس VIH",
            curriculumMappingFr = "Unité 04 : Coopération cellulaire et immunodéficience liée au VIH",
            stemAr = "لماذا يؤدي استهداف وتخريب الخلايا اللمفاوية LT4 من طرف فيروس VIH إلى عجز مناعي شامل يعطل كلاً من الاستجابة المناعية الخلطية والاستجابة المناعية الخلوية؟",
            stemFr = "Pourquoi la destruction des lymphocytes LT4 par le virus VIH entraîne-t-elle un effondrement à la fois de la réponse humorale et de la réponse cellulaire ?",
            optionsAr = listOf(
                "لأن الخلايا LT4 (والمتمايزة إلى LTh) تفرز المبلغ الكيميائي الإنترلوكين 2 (IL-2) الضروري لتحفيز تكاثر وتمايز كل من LB (خلطياً) وLT8 إلى LTc (خلوياً)",
                "لأن الخلايا LT4 هي التي تركب الأجسام المضادة وجزيئات البيرفورين مباشرة",
                "لأن فيروس VIH يخرب الكريات الحمراء الحاملة لمؤشرات الزمر الدموية ABO",
                "لأن الخلايا LT4 تتحول في النخاع العظمي إلى بلعميات كبيرة"
            ),
            optionsFr = listOf(
                "Car les LT4 (différenciés en LTh) sécrètent l'interleukine-2 (IL-2) indispensable à la prolifération et à la différenciation des LB et des LT8",
                "Car les LT4 produisent directement les anticorps et la perforine",
                "Car le VIH détruit les hématies du système ABO",
                "Car les LT4 se transforment en macrophages dans la moelle osseuse"
            ),
            correctIndices = listOf(0),
            explanationAr = "الخلايا اللمفاوية LT4 هي محور التعاون المناعي؛ فبعد تحسيسها تتمايز إلى خلايا مساعدة LTh تفرز الإنترلوكين 2 (IL-2) الذي يحفز تكاثر وتمايز LB المحسسة إلى بلازميات منتجة للأجسام المضادة، ويحفز تكاثر وتمايز LT8 المحسسة إلى خلايا سامة LTc.",
            explanationFr = "Les LT4 (via les LTh) sont le pivot de la réponse immunitaire spécifique grâce à la sécrétion d'IL-2 qui stimule la prolifération et la différenciation des LB et des LT8."
        ),

        // 13. Philosophy - Single Choice
        Question(
            id = "q_philo_method_1",
            subjectId = "philosophy",
            lessonId = "philo_method",
            streams = AcademicStream.entries,
            type = QuestionType.SINGLE_CHOICE,
            difficulty = DifficultyLevel.MEDIUM,
            provenance = QuestionProvenance.CURRICULUM_VERIFIED,
            sourceCitationAr = "دليل بناء المقال الفلسفي وفق شبكة التقويم الرسمية للبكالوريا",
            sourceCitationFr = "Guide méthodologique de la dissertation philosophique au Baccalauréat",
            curriculumMappingAr = "منهجية الاستقصاء بالوضع والطريقة الجدلية",
            curriculumMappingFr = "Méthodologie de l'investigation par affirmation et dialectique",
            stemAr = "إذا طُلب منك في امتحان البكالوريا: «دافع عن صحة الأطروحة القائلة بأن الفرضية خطوة ضرورية في المنهج التجريبي»، فما هي المنهجية الواجب اتباعها؟",
            stemFr = "Si le sujet du Bac demande : « Défendez la thèse selon laquelle l'hypothèse est indispensable dans la démarche expérimentale », quelle méthode faut-il adopter ?",
            optionsAr = listOf(
                "منهجية الاستقصاء بالوضع (عرض منطق الأطروحة، الدفاع عنها بحجج شخصية، ونقد موقف خصومها)",
                "منهجية المقارنة بين الفرضية والملاحظة",
                "المنهجية الجدلية المحايدة فقط",
                "منهجية تحليل نص فلسفي"
            ),
            optionsFr = listOf(
                "L'investigation par affirmation (exposer la thèse, la défendre avec de nouveaux arguments et réfuter ses adversaires)",
                "La méthode comparative",
                "La méthode dialectique neutre",
                "Le commentaire de texte philosophique"
            ),
            correctIndices = listOf(0),
            explanationAr = "صيغة «دافع عن صحة الأطروحة» أو «أثبت صحة القول» تحيل مباشرة وحصرياً إلى منهجية الاستقصاء بالوضع، حيث يلتزم المترشح بالدفاع عن الأطروحة وتدعيمها بحجج شخصية ونقد موقف الخصوم.",
            explanationFr = "La consigne « Défendez la validité de la thèse » appelle impérativement la méthode d'investigation par affirmation (الإستقصاء بالوضع)."
        ),

        // 14. Islamic Sciences - Single Choice
        Question(
            id = "q_islamic_maqasid_1",
            subjectId = "islamic",
            lessonId = "islamic_maqasid",
            streams = AcademicStream.entries,
            type = QuestionType.SINGLE_CHOICE,
            difficulty = DifficultyLevel.MEDIUM,
            provenance = QuestionProvenance.CURRICULUM_VERIFIED,
            sourceCitationAr = "التدرج السنوي للعلوم الإسلامية — وحدة مقاصد الشريعة الإسلامية",
            sourceCitationFr = "Progression officielle de Sciences Islamiques — Maqasid al-Charia",
            curriculumMappingAr = "الوحدة: مقاصد الشريعة الإسلامية • الكليات الضرورية الخمس",
            curriculumMappingFr = "Unité : Finalités de la Charia • Les cinq nécessités",
            stemAr = "ما هو الترتيب الصحيح للمقاصد الضرورية الخمس (الكليات الخمس) عند تعارضها وفق ما قرره علماء المقاصد في المنهاج الرسمي؟",
            stemFr = "Quel est l'ordre hiérarchique exact des cinq nécessités (Al-Daruriyyat Al-Khams) en cas de conflit ?",
            optionsAr = listOf(
                "حفظ الدين ← حفظ النفس ← حفظ العقل ← حفظ النسل (العِرض) ← حفظ المال",
                "حفظ المال ← حفظ النفس ← حفظ الدين ← حفظ العقل ← حفظ النسل",
                "حفظ العقل ← حفظ المال ← حفظ النسل ← حفظ النفس ← حفظ الدين",
                "حفظ النفس ← حفظ المال ← حفظ العقل ← حفظ الدين ← حفظ النسل"
            ),
            optionsFr = listOf(
                "Religion → Vie → Raison → Descendance (Honneur) → Biens",
                "Biens → Vie → Religion → Raison → Descendance",
                "Raison → Biens → Descendance → Vie → Religion",
                "Vie → Biens → Raison → Religion → Descendance"
            ),
            correctIndices = listOf(0),
            explanationAr = "الترتيب المعتمد في المنهاج الرسمي لمادة العلوم الإسلامية للكليات الضرورية الخمس هو: (1) حفظ الدين، (2) حفظ النفس، (3) حفظ العقل، (4) حفظ النسل/العرض، (5) حفظ المال.",
            explanationFr = "L'ordre canonique retenu au programme officiel est : 1. Religion (Din), 2. Vie (Nafs), 3. Raison (Aql), 4. Descendance (Nasl), 5. Biens (Mal)."
        ),

        // 15. History & Geography - Single Choice
        Question(
            id = "q_hist_rev_1",
            subjectId = "hist_geo",
            lessonId = "hist_revolution",
            streams = AcademicStream.entries,
            type = QuestionType.SINGLE_CHOICE,
            difficulty = DifficultyLevel.BAC_LEVEL,
            provenance = QuestionProvenance.CURRICULUM_VERIFIED,
            sourceCitationAr = "المنهاج الرسمي لمادة التاريخ — الوحدة التعلمية الثانية: الثورة التحريرية",
            sourceCitationFr = "Programme officiel d'Histoire — Unité 02 : La Révolution Algérienne",
            curriculumMappingAr = "الوحدة 02: مؤتمر الصومام (20 أوت 1956) والتنظيم المؤسساتي للثورة",
            curriculumMappingFr = "Unité 02 : Congrès de la Soummam (20 août 1956) et institutions de la Révolution",
            stemAr = "من أبرز القرارات التنظيمية والمؤسساتية التي انبثقت عن مؤتمر الصومام في 20 أوت 1956:",
            stemFr = "Parmi les principales décisions institutionnelles issues du Congrès de la Soummam du 20 août 1956 :",
            optionsAr = listOf(
                "تأسيس المجلس الوطني للثورة الجزائرية (CNRA) ولجنة التنسيق والتنفيذ (CCE) وتقسيم الجزائر إلى 6 ولايات تاريخية",
                "توقيع اتفاقيات إيفيان الثانية وإعلان وقف إطلاق النار الرسمي",
                "إصدار مشروع قسنطينة الاقتصادي وسلم الشجعان",
                "تأسيس المنظمة الخاصة (OS) والتحضير لهجومات الشمال القسنطيني"
            ),
            optionsFr = listOf(
                "Création du CNRA et du CCE, et découpage du territoire en 6 Wilayas historiques",
                "Signature des Accords d'Évian et proclamation du cessez-le-feu",
                "Lancement du Plan de Constantine et de la Paix des Braves",
                "Création de l'Organisation Spéciale (OS)"
            ),
            correctIndices = listOf(0),
            explanationAr = "انعقد مؤتمر الصومام في 20 أوت 1956 بإفري أوزلاقن (الولاية الثالثة)، وأقر ميثاق الصومام وهياكل قيادة الثورة: المجلس الوطني للثورة الجزائرية (هيئة تشريعية)، لجنة التنسيق والتنفيذ (هيئة تنفيذية)، وإضافة الولاية السادسة (الصحراء).",
            explanationFr = "Le Congrès de la Soummam (20 août 1956) a doté la Révolution d'institutions centrales (CNRA, CCE) et organisé l'ALN en 6 Wilayas historiques (ajout de la Wilaya VI - Sahara)."
        )
    )

    val verifiedQuestions: List<Question> by lazy {
        BacQuestionBankGenerator.generateOrderedBank(subjects, flagshipQuestions)
    }

    private val lessonOrderMap: Map<String, Int> by lazy {
        subjects.flatMap { it.lessons }.associate { it.id to it.unitNumber }
    }

    fun unitNumberForLesson(lessonId: String): Int = lessonOrderMap[lessonId] ?: 1

    fun subjectsForStream(stream: AcademicStream): List<Subject> {
        return subjects.sortedByDescending { it.coefficientFor(stream) }
    }

    fun questionsForSubject(
        subjectId: String,
        extraCommunityQuestions: List<Question> = emptyList(),
        lessonId: String? = null
    ): List<Question> {
        val base = verifiedQuestions.filter {
            it.subjectId == subjectId && (lessonId == null || it.lessonId == lessonId)
        }
        val extra = extraCommunityQuestions.filter {
            it.subjectId == subjectId && (lessonId == null || it.lessonId == lessonId)
        }
        return (base + extra).sortedBy { unitNumberForLesson(it.lessonId) }
    }

    fun questionsForLesson(lessonId: String, extraCommunityQuestions: List<Question> = emptyList()): List<Question> {
        val base = verifiedQuestions.filter { it.lessonId == lessonId }
        val extra = extraCommunityQuestions.filter { it.lessonId == lessonId }
        return base + extra
    }

    fun allQuestions(extraCommunityQuestions: List<Question> = emptyList()): List<Question> {
        return verifiedQuestions + extraCommunityQuestions
    }
}
