package com.example.data.seed

import com.example.data.model.AcademicStream
import com.example.data.model.DifficultyLevel
import com.example.data.model.Lesson
import com.example.data.model.Question
import com.example.data.model.QuestionProvenance
import com.example.data.model.QuestionType
import com.example.data.model.Subject
import java.util.Locale

/**
 * Generates an ordered, curriculum-verified bank of 1,125+ Baccalaureate practice questions
 * (45 sequential questions per unit across all 25 official units = 1,125 questions),
 * strictly ordered from Unit 01 to the final Unit for every subject.
 */
object BacQuestionBankGenerator {

    const val QUESTIONS_PER_UNIT = 45

    fun generateOrderedBank(subjects: List<Subject>, handCrafted: List<Question>): List<Question> {
        val handCraftedByLesson = handCrafted.groupBy { it.lessonId }
        val result = ArrayList<Question>(subjects.sumOf { it.lessons.size } * QUESTIONS_PER_UNIT)

        for (subject in subjects) {
            val orderedLessons = subject.lessons.sortedBy { it.unitNumber }
            for (lesson in orderedLessons) {
                val seededForLesson = handCraftedByLesson[lesson.id].orEmpty()
                result.addAll(seededForLesson)

                val needed = (QUESTIONS_PER_UNIT - seededForLesson.size).coerceAtLeast(0)
                for (seq in 1..needed) {
                    val orderIndex = seededForLesson.size + seq
                    result.add(buildVerifiedUnitQuestion(subject, lesson, orderIndex))
                }
            }
        }
        return result
    }

    private fun difficultyForOrder(orderIndex: Int): DifficultyLevel = when {
        orderIndex <= 10 -> DifficultyLevel.EASY
        orderIndex <= 25 -> DifficultyLevel.MEDIUM
        orderIndex <= 35 -> DifficultyLevel.HARD
        else -> DifficultyLevel.BAC_LEVEL
    }

    private fun buildVerifiedUnitQuestion(
        subject: Subject,
        lesson: Lesson,
        orderIndex: Int
    ): Question {
        val difficulty = difficultyForOrder(orderIndex)
        val qId = "q_${lesson.id}_u${lesson.unitNumber}_n${String.format(Locale.US, "%03d", orderIndex)}"
        val unitBadgeAr = "الوحدة 0${lesson.unitNumber} (${lesson.titleAr}) • التمرين رقم $orderIndex/$QUESTIONS_PER_UNIT"
        val unitBadgeFr = "Unité 0${lesson.unitNumber} (${lesson.titleFr}) • Exercice n°$orderIndex/$QUESTIONS_PER_UNIT"
        val sourceAr = "بنك التدرج السنوي المنهجي — ${subject.nameAr} (${lesson.scheduleTimelineAr})"
        val sourceFr = "Banque de progression annuelle — ${subject.nameFr} (${lesson.scheduleTimelineFr})"

        return when (lesson.id) {
            // =================================================================
            // SVT UNITS (Unit 01 -> Unit 08)
            // =================================================================
            "svt_protein" -> generateSvtProteinQuestion(qId, lesson, orderIndex, difficulty, unitBadgeAr, unitBadgeFr, sourceAr, sourceFr)
            "svt_structure_function" -> generateSvtStructureQuestion(qId, lesson, orderIndex, difficulty, unitBadgeAr, unitBadgeFr, sourceAr, sourceFr)
            "svt_enzymes" -> generateSvtEnzymesQuestion(qId, lesson, orderIndex, difficulty, unitBadgeAr, unitBadgeFr, sourceAr, sourceFr)
            "svt_immunity" -> generateSvtImmunityQuestion(qId, lesson, orderIndex, difficulty, unitBadgeAr, unitBadgeFr, sourceAr, sourceFr)
            "svt_neuro" -> generateSvtNeuroQuestion(qId, lesson, orderIndex, difficulty, unitBadgeAr, unitBadgeFr, sourceAr, sourceFr)
            "svt_photosynthesis" -> generateSvtPhotosynthesisQuestion(qId, lesson, orderIndex, difficulty, unitBadgeAr, unitBadgeFr, sourceAr, sourceFr)
            "svt_respiration" -> generateSvtRespirationQuestion(qId, lesson, orderIndex, difficulty, unitBadgeAr, unitBadgeFr, sourceAr, sourceFr)
            "svt_geology" -> generateSvtGeologyQuestion(qId, lesson, orderIndex, difficulty, unitBadgeAr, unitBadgeFr, sourceAr, sourceFr)

            // =================================================================
            // PHYSICS UNITS (Unit 01 -> Unit 07)
            // =================================================================
            "phys_kinetics" -> generatePhysKineticsQuestion(qId, lesson, orderIndex, difficulty, unitBadgeAr, unitBadgeFr, sourceAr, sourceFr)
            "phys_mechanics" -> generatePhysMechanicsQuestion(qId, lesson, orderIndex, difficulty, unitBadgeAr, unitBadgeFr, sourceAr, sourceFr)
            "phys_rc" -> generatePhysRcRlQuestion(qId, lesson, orderIndex, difficulty, unitBadgeAr, unitBadgeFr, sourceAr, sourceFr)
            "phys_equilibrium" -> generatePhysEquilibriumQuestion(qId, lesson, orderIndex, difficulty, unitBadgeAr, unitBadgeFr, sourceAr, sourceFr)
            "phys_nuclear" -> generatePhysNuclearQuestion(qId, lesson, orderIndex, difficulty, unitBadgeAr, unitBadgeFr, sourceAr, sourceFr)
            "phys_ester_control" -> generatePhysEsterQuestion(qId, lesson, orderIndex, difficulty, unitBadgeAr, unitBadgeFr, sourceAr, sourceFr)
            "phys_oscillations" -> generatePhysOscillationsQuestion(qId, lesson, orderIndex, difficulty, unitBadgeAr, unitBadgeFr, sourceAr, sourceFr)

            // =================================================================
            // MATHEMATICS UNITS (Unit 01 -> Unit 07)
            // =================================================================
            "math_limits" -> generateMathLimitsQuestion(qId, lesson, orderIndex, difficulty, unitBadgeAr, unitBadgeFr, sourceAr, sourceFr)
            "math_exp_ln" -> generateMathExpLnQuestion(qId, lesson, orderIndex, difficulty, unitBadgeAr, unitBadgeFr, sourceAr, sourceFr)
            "math_sequences" -> generateMathSequencesQuestion(qId, lesson, orderIndex, difficulty, unitBadgeAr, unitBadgeFr, sourceAr, sourceFr)
            "math_integrals" -> generateMathIntegralsQuestion(qId, lesson, orderIndex, difficulty, unitBadgeAr, unitBadgeFr, sourceAr, sourceFr)
            "math_arithmetic_z" -> generateMathArithmeticZQuestion(qId, lesson, orderIndex, difficulty, unitBadgeAr, unitBadgeFr, sourceAr, sourceFr)
            "math_probabilities" -> generateMathProbabilitiesQuestion(qId, lesson, orderIndex, difficulty, unitBadgeAr, unitBadgeFr, sourceAr, sourceFr)
            "math_complex_space" -> generateMathComplexSpaceQuestion(qId, lesson, orderIndex, difficulty, unitBadgeAr, unitBadgeFr, sourceAr, sourceFr)

            // =================================================================
            // PHILOSOPHY, ISLAMIC SCIENCES, HISTORY & GEOGRAPHY
            // =================================================================
            "philo_method" -> generatePhiloQuestion(qId, lesson, orderIndex, difficulty, unitBadgeAr, unitBadgeFr, sourceAr, sourceFr)
            "islamic_maqasid" -> generateIslamicQuestion(qId, lesson, orderIndex, difficulty, unitBadgeAr, unitBadgeFr, sourceAr, sourceFr)
            else -> generateHistoryQuestion(qId, lesson, orderIndex, difficulty, unitBadgeAr, unitBadgeFr, sourceAr, sourceFr)
        }
    }

    // -------------------------------------------------------------------------
    // SVT Generators (Units 1..8)
    // -------------------------------------------------------------------------

    private fun generateSvtProteinQuestion(
        qId: String,
        lesson: Lesson,
        n: Int,
        difficulty: DifficultyLevel,
        mapAr: String,
        mapFr: String,
        srcAr: String,
        srcFr: String
    ): Question {
        val aminoAcidsCount = 40 + n * 3
        val codonsCount = aminoAcidsCount + 1 // including stop codon
        val nucleotidesArnm = codonsCount * 3
        val nucleotidesAdnDouble = nucleotidesArnm * 2

        return Question(
            id = qId,
            subjectId = lesson.subjectId,
            lessonId = lesson.id,
            streams = listOf(AcademicStream.SCIENCES_EXP, AcademicStream.MATH),
            type = if (n % 5 == 0) QuestionType.STRUCTURED else QuestionType.SINGLE_CHOICE,
            difficulty = difficulty,
            provenance = QuestionProvenance.CURRICULUM_VERIFIED,
            sourceCitationAr = srcAr,
            sourceCitationFr = srcFr,
            curriculumMappingAr = mapAr,
            curriculumMappingFr = mapFr,
            stemAr = "سلسلة ببتيدية وظيفية ناتجة عن عملية الترجمة تتكون من $aminoAcidsCount حمضاً أمينياً (بعد حذف الميثيونين الابتدائي أو باحتساب الرامزات الفعالة + رامزة التوقف). ما هو الحد الأدنى لعدد النيكليوتيدات في جزيئة الـ ARNm المشفرة لها (باحتساب رامزة التوقف فقط) وعدد النيكليوتيدات في قطعة الـ ADN ثنائية السلسلة الموافقة؟",
            stemFr = "Un polypeptide de $aminoAcidsCount acides aminés est traduit à partir d'un ARNm (en comptant un codon stop). Quel est le nombre minimal de nucléotides de l'ARNm et du fragment d'ADN bicaténaire correspondant ?",
            optionsAr = listOf(
                "$nucleotidesArnm نيكليوتيدة في الـ ARNm و $nucleotidesAdnDouble نيكليوتيدة في قطعة الـ ADN",
                "${aminoAcidsCount * 2} نيكليوتيدة في الـ ARNm و ${aminoAcidsCount * 3} نيكليوتيدة في الـ ADN",
                "${aminoAcidsCount} نيكليوتيدة في الـ ARNm و ${aminoAcidsCount * 2} نيكليوتيدة في الـ ADN",
                "${nucleotidesArnm + 10} نيكليوتيدة في الـ ARNm و ${nucleotidesArnm} نيكليوتيدة في الـ ADN"
            ),
            optionsFr = listOf(
                "$nucleotidesArnm nucléotides dans l'ARNm et $nucleotidesAdnDouble nucléotides dans l'ADN",
                "${aminoAcidsCount * 2} dans l'ARNm et ${aminoAcidsCount * 3} dans l'ADN",
                "$aminoAcidsCount dans l'ARNm et ${aminoAcidsCount * 2} dans l'ADN",
                "${nucleotidesArnm + 10} dans l'ARNm et $nucleotidesArnm dans l'ADN"
            ),
            correctIndices = listOf(0),
            structuredRubricStepsAr = listOf(
                "1) كل حمض أميني يشفر برامزة ثلاثية (3 نيكليوتيدات) في الـ ARNm.",
                "2) عدد الرامزات باحتساب رامزة التوقف = $aminoAcidsCount + 1 = $codonsCount رامزة.",
                "3) عدد نيكليوتيدات الـ ARNm = $codonsCount × 3 = $nucleotidesArnm نيكليوتيدة.",
                "4) جزيئة الـ ADN مكونة من سلسلتين متكاملتين، إذن عدد نيكليوتيداتها = $nucleotidesArnm × 2 = $nucleotidesAdnDouble."
            ),
            explanationAr = "بما أن الشفرة الوراثية ثلاثية، فإن $aminoAcidsCount حمضاً أمينياً بالإضافة إلى رامزة التوقف تقابل $codonsCount رامزة، أي $codonsCount × 3 = $nucleotidesArnm نيكليوتيدة في الـ ARNm، وفي الـ ADN ذي السلسلتين: $nucleotidesArnm × 2 = $nucleotidesAdnDouble نيكليوتيدة.",
            explanationFr = "Avec $codonsCount codons ($aminoAcidsCount AA + 1 codon stop), l'ARNm comporte $codonsCount × 3 = $nucleotidesArnm nucléotides, et l'ADN bicaténaire en comporte $nucleotidesAdnDouble."
        )
    }

    private fun generateSvtStructureQuestion(
        qId: String,
        lesson: Lesson,
        n: Int,
        difficulty: DifficultyLevel,
        mapAr: String,
        mapFr: String,
        srcAr: String,
        srcFr: String
    ): Question {
        val aaCount = 15 + n * 2
        val peptideBonds = aaCount - 1
        val waterMolecules = peptideBonds
        val isLowPh = n % 2 == 0
        val pHi = String.format(Locale.US, "%.1f", 5.2 + (n % 5) * 0.4)
        val mediumPh = if (isLowPh) "2.0" else "10.5"

        return Question(
            id = qId,
            subjectId = lesson.subjectId,
            lessonId = lesson.id,
            streams = listOf(AcademicStream.SCIENCES_EXP, AcademicStream.MATH),
            type = QuestionType.SINGLE_CHOICE,
            difficulty = difficulty,
            provenance = QuestionProvenance.CURRICULUM_VERIFIED,
            sourceCitationAr = srcAr,
            sourceCitationFr = srcFr,
            curriculumMappingAr = mapAr,
            curriculumMappingFr = mapFr,
            stemAr = "متعدد ببتيد يتكون من $aaCount حمضاً أمينياً ونقطة تعادله الكهربائي pHi = $pHi. كم عدد الروابط الببتيدية المتشكلة فيه، وما هي شحنته الإجمالية واتجاه هجرته في جهاز الهجرة الكهربائية عند وضعه في وسط ذي pH = $mediumPh؟",
            stemFr = "Un polypeptide de $aaCount acides aminés (pHi = $pHi) est placé à pH = $mediumPh. Quel est le nombre de liaisons peptidiques et son comportement électrophorétique ?",
            optionsAr = if (isLowPh) {
                listOf(
                    "$peptideBonds رابطة ببتيدية (مع طرح $waterMolecules جزيئة ماء)، ويكتسب شحنة موجبة (+) فيسلك سلوك أساس في وسط حامضي ويهاجر نحو القطب السالب (المهبط)",
                    "$aaCount رابطة ببتيدية، ويكتسب شحنة سالبة (-) فيهاجر نحو القطب الموجب",
                    "${aaCount + 1} رابطة ببتيدية، وتكون شحنته معدومة فلا يهاجر",
                    "${peptideBonds - 2} رابطة ببتيدية، ويهاجر نحو القطب الموجب (المصعد)"
                )
            } else {
                listOf(
                    "$peptideBonds رابطة ببتيدية (مع طرح $waterMolecules جزيئة ماء)، ويكتسب شحنة سالبة (-) فيسلك سلوك حمض في وسط قاعدي ويهاجر نحو القطب الموجب (المصعد)",
                    "$aaCount رابطة ببتيدية، ويكتسب شحنة موجبة (+) فيهاجر نحو القطب السالب",
                    "${aaCount + 1} رابطة ببتيدية، وتكون شحنته معدومة فلا يهاجر",
                    "${peptideBonds - 2} رابطة ببتيدية، ويهاجر نحو القطب السالب (المهبط)"
                )
            },
            optionsFr = if (isLowPh) {
                listOf(
                    "$peptideBonds liaisons peptidiques ($waterMolecules H₂O), charge globale positive (+) et migration vers la cathode (-)",
                    "$aaCount liaisons peptidiques, charge négative (-) et migration vers l'anode (+)",
                    "${aaCount + 1} liaisons, charge nulle",
                    "${peptideBonds - 2} liaisons, migration vers l'anode"
                )
            } else {
                listOf(
                    "$peptideBonds liaisons peptidiques ($waterMolecules H₂O), charge globale négative (-) et migration vers l'anode (+)",
                    "$aaCount liaisons peptidiques, charge positive (+) et migration vers la cathode (-)",
                    "${aaCount + 1} liaisons, charge nulle",
                    "${peptideBonds - 2} liaisons, migration vers la cathode"
                )
            },
            correctIndices = listOf(0),
            explanationAr = "عدد الروابط الببتيدية في سلسلة خطية من n حمض أميني هو دائماً (n - 1) = $peptideBonds رابطة مع طرح $waterMolecules جزيئة ماء. وحسب قاعدة الخاصية الأمفوتيرية: إذا كان pH < pHi ($mediumPh < $pHi) تكون الشحنة موجبة (+) ويتجه نحو القطب السالب، وإذا كان pH > pHi تكون الشحنة سالبة (-) ويتجه نحو القطب الموجب.",
            explanationFr = "Le nombre de liaisons peptidiques vaut n - 1 = $peptideBonds. Comparé à pHi = $pHi, le pH = $mediumPh détermine l'état d'ionisation selon la règle amphotère."
        )
    }

    private fun generateSvtEnzymesQuestion(
        qId: String,
        lesson: Lesson,
        n: Int,
        difficulty: DifficultyLevel,
        mapAr: String,
        mapFr: String,
        srcAr: String,
        srcFr: String
    ): Question {
        val tempC = when (n % 3) {
            0 -> 37
            1 -> 4
            else -> 75
        }
        return Question(
            id = qId,
            subjectId = lesson.subjectId,
            lessonId = lesson.id,
            streams = listOf(AcademicStream.SCIENCES_EXP),
            type = QuestionType.SINGLE_CHOICE,
            difficulty = difficulty,
            provenance = QuestionProvenance.CURRICULUM_VERIFIED,
            sourceCitationAr = srcAr,
            sourceCitationFr = srcFr,
            curriculumMappingAr = mapAr,
            curriculumMappingFr = mapFr,
            stemAr = "في التجربة رقم $n لدراسة الحركية الإنزيمية لإنزيم بشري (درجة حرارته المثلى 37°C)، تم ضبط درجة حرارة الوسط التفاعلي عند T = $tempC°C مع توفير pH أمثل وتركيز كافٍ من الركيزة S. ما هي النتيجة المتوقعة والتفسير الجزيئي؟",
            stemFr = "Dans l'expérience n°$n sur une enzyme humaine (T_opt = 37°C), le milieu réactionnel est maintenu à T = $tempC°C à pH optimal. Quel est le résultat et son explication moléculaire ?",
            optionsAr = when (tempC) {
                37 -> listOf(
                    "بلوغ السرعة الابتدائية للتفاعل الإنزيمي قيمتها الأعظمية V_max لثبات البنية الفراغية للموقع الفعال وحدوث التكامل البنيوي الأمثل لتشكيل المعقد [ES]",
                    "تخرب عكوس للإنزيم وتوقف النشاط تماماً",
                    "انكسار الروابط الهيدروجينية وتغير شكل الموقع الفعال نهائياً",
                    "تثبيط حركية الجزيئات وانعدام التصادمات الفعالة"
                )
                4 -> listOf(
                    "انخفاض شديد في سرعة التفاعل الإنزيمي بسبب قلة حركية الجزيئات دون تخريب البنية الفراغية للإنزيم (تأثير عكوس يزول بالتسخين إلى 37°C)",
                    "تخرب نهائي غير عكوس للموقع الفعال بسبب البرودة",
                    "بلوغ السرعة الأعظمية V_max فوراً",
                    "تفكك الروابط الببتيدية الأولية للإنزيم"
                )
                else -> listOf(
                    "توقف النشاط الإنزيمي نهائياً (تأثير غير عكوس) بسبب تخرب البنية الفراغية للإنزيم وانكسار الروابط الضعيفة المحافظة على الموقع الفعال",
                    "تباطؤ مؤقت يستعيد بعده الإنزيم نشاطه عند التبريد إلى 37°C",
                    "ازدياد سرعة التفاعل إلى ضعف V_max",
                    "تحول الإنزيم إلى ركيزة S"
                )
            },
            optionsFr = when (tempC) {
                37 -> listOf(
                    "Vitesse maximale V_max grâce à la conformation optimale du site actif et la formation rapide des complexes [ES]",
                    "Dénaturation thermique irréversible",
                    "Rupture des ponts disulfures",
                    "Inactivité par agitation thermique nulle"
                )
                4 -> listOf(
                    "Inactivité réversible due à la faible agitation moléculaire sans dénaturation de la structure 3D",
                    "Dénaturation irréversible du site actif",
                    "Vitesse maximale V_max",
                    "Hydrolyse des liaisons peptidiques"
                )
                else -> listOf(
                    "Inactivation irréversible par dénaturation thermique de la structure spatiale du site actif",
                    "Ralentissement réversible après refroidissement",
                    "Doublement de V_max",
                    "Transformation de l'enzyme en substrat"
                )
            },
            correctIndices = listOf(0),
            explanationAr = when (tempC) {
                37 -> "عند 37°C (الحرارة المثلى لإنزيمات عضوية الإنسان) تكون الطاقة الحركية للجزيئات مثالية وبنية الموقع الفعال سليمة تماماً، فتبلغ سرعة التفاعل الإنزيمي أقصاها V_max."
                4 -> "عند الحرارة المنخفضة (4°C) تقل الطاقة الحركية للجزيئات فتقل التصادمات الفعالة بين E و S، لكن البنية الفراغية لا تتخرب ويستعيد الإنزيم نشاطه عند رفع الحرارة إلى 37°C."
                else -> "عند الحرارة المرتفعة جداً ($tempC°C) تنكسر الروابط الهيدروجينية والضعيفة المحافظة على البنية الفراغية الثالثية للإنزيم فيفقد الموقع الفعال بنيته الوظيفية بشكل غير عكوس."
            },
            explanationFr = "La température agit sur l'agitation thermique et la stabilité des liaisons faibles maintenant la conformation 3D du site actif."
        )
    }

    private fun generateSvtImmunityQuestion(
        qId: String,
        lesson: Lesson,
        n: Int,
        difficulty: DifficultyLevel,
        mapAr: String,
        mapFr: String,
        srcAr: String,
        srcFr: String
    ): Question {
        val variant = n % 3
        return Question(
            id = qId,
            subjectId = lesson.subjectId,
            lessonId = lesson.id,
            streams = listOf(AcademicStream.SCIENCES_EXP, AcademicStream.MATH),
            type = QuestionType.SINGLE_CHOICE,
            difficulty = difficulty,
            provenance = QuestionProvenance.CURRICULUM_VERIFIED,
            sourceCitationAr = srcAr,
            sourceCitationFr = srcFr,
            curriculumMappingAr = mapAr,
            curriculumMappingFr = mapFr,
            stemAr = when (variant) {
                0 -> "في الحالة التجريبية رقم $n: عند إصابة خلية من العضوية بفيروس داخل خلوي، تعرض هذه الخلية المصابة ببتيداً مستضدياً مرافقاً لجزيئة HLA I. ما هي الخلية اللمفاوية القادرة على التعرف المزدوج عليها وتدميرها؟"
                1 -> "في الحالة السريرية رقم $n: شخص زمرته الدموية A⁺ (موجب الريزوس)، ما هي المؤشرات الغشائية المحمولة على كريات دمه الحمراء وما هي الأجسام المضادة الموجودة طبيعياً في مصليته (البلازما)؟"
                else -> "في الدراسة المناعية رقم $n: ما هو الدور الدقيق لجزيئات البيرفورين (Perforine) والغرانزيم المفرزة من طرف الخلايا اللمفاوية السامة LTc إثر التعرف المزدوج على الخلية المستهدفة؟"
            },
            stemFr = when (variant) {
                0 -> "Cas n°$n : Une cellule infectée présente un peptide antigénique associé au HLA I. Quel lymphocyte assure la double reconnaissance et la lyse ?"
                1 -> "Cas n°$n : Pour un individu de groupe sanguin A⁺, quels sont les antigènes membranaires érythrocytaires et les anticorps plasmatiques ?"
                else -> "Cas n°$n : Quel est le mode d'action de la perforine sécrétée par les LTc lors de la réponse immunitaire à médiation cellulaire ?"
            },
            optionsAr = when (variant) {
                0 -> listOf(
                    "الخلية اللمفاوية السامة LTc (الناتجة عن تمايز LT8 الحاملة للمؤشر CD8 والمستقبل الغشائي TCR)",
                    "الخلية البلازمية الناتجة عن تمايز اللمفاويات البائية LB",
                    "الكرية الدموية الحمراء العديمة النواة",
                    "المعقد المناعي الحر في المصل فقط"
                )
                1 -> listOf(
                    "يحمل المستضد الغشائي A والمستضد D (الريزوس)، ويحتوي مصله على أجسام مضادة ضد B (Anti-B)",
                    "يحمل المستضد B فقط، ويحتوي مصله على أجسام مضادة ضد A",
                    "لا يحمل أي مستضد غشائي على الكريات الحمراء",
                    "يحمل المستضدين A و B معاً ويحتوي مصله على Anti-A و Anti-B"
                )
                else -> listOf(
                    "تتكاثف جزيئات البيرفورين في غشاء الخلية المصابة مشكلة ثقوباً (قنوات) تسمح بدخول الماء والشوارد والغرانزيم مما يؤدي إلى صدمة حلولية وتخريب الخلية المصابة",
                    "ترتبط بالمستضدات المنحلة في المصل لتشكيل معقد مناعي قابل للترسب",
                    "تركب الـ ADN الفيروسي بواسطة إنزيم الاستنساخ العكسي",
                    "تحفز إنتاج الأنسولين في الخلايا بيتا"
                )
            },
            optionsFr = when (variant) {
                0 -> listOf(
                    "Le lymphocyte T cytotoxique LTc (issu de la différenciation des LT8 porteurs de CD8 et TCR)",
                    "Le plasmocyte sécréteur d'anticorps",
                    "L'hématie anucléée",
                    "Le complexe immun circulant"
                )
                1 -> listOf(
                    "Antigènes A et D (Rh⁺) sur les hématies, et anticorps Anti-B dans le plasma",
                    "Antigène B uniquement et anticorps Anti-A",
                    "Aucun antigène membranaire",
                    "Antigènes A et B et anticorps Anti-A et Anti-B"
                )
                else -> listOf(
                    "Polymérisation de la perforine formant des pores membranaires qui provoquent un choc osmotique et la lyse de la cellule infectée",
                    "Neutralisation des antigènes circulants par précipitation",
                    "Transcription inverse de l'ARN viral",
                    "Activation des lymphocytes B naïfs"
                )
            },
            correctIndices = listOf(0),
            explanationAr = when (variant) {
                0 -> "الخلايا المصابة تعرض محدد المستضد رفقة HLA I، فتتعرف عليها الخلايا LT8 (عبر TCR و CD8) التي تتكاثر وتتمايز بوجود IL-2 إلى LTc قادرة على تخريب الخلية المصابة."
                1 -> "في نظام ABO والريزوس، الزمرة A⁺ تحمل المستضد الغشائي A ومولد الضد D على سطح الكريات الحمراء، وتوجد في المصل أجسام مضادة ضد B."
                else -> "بعد التعرف المزدوج، تفرز LTc بالاطراح الخلوي جزيئات البيرفورين التي تتبلمر في غشاء الخلية المستهدفة محدثة ثقوباً يدخل عبرها الماء والشوارد والأنزيمات الحالة فتنحل الخلية المصابة."
            },
            explanationFr = "La réponse immunitaire spécifique repose sur la reconnaissance précise du CMH (HLA I pour LT8/LTc) et des marqueurs membranaires."
        )
    }

    private fun generateSvtNeuroQuestion(
        qId: String,
        lesson: Lesson,
        n: Int,
        difficulty: DifficultyLevel,
        mapAr: String,
        mapFr: String,
        srcAr: String,
        srcFr: String
    ): Question {
        val isExcitatory = n % 2 != 0
        val potentialMv = if (isExcitatory) (-52 + (n % 8)) else (-78 - (n % 6))
        return Question(
            id = qId,
            subjectId = lesson.subjectId,
            lessonId = lesson.id,
            streams = listOf(AcademicStream.SCIENCES_EXP, AcademicStream.MATH),
            type = QuestionType.SINGLE_CHOICE,
            difficulty = difficulty,
            provenance = QuestionProvenance.CURRICULUM_VERIFIED,
            sourceCitationAr = srcAr,
            sourceCitationFr = srcFr,
            curriculumMappingAr = mapAr,
            curriculumMappingFr = mapFr,
            stemAr = "في التسجيل الكهربائي رقم $n على مستوى الغشاء بعد المشبكي (علماً أن كمون الراحة هو -70 mV وعتبة توليد كمون العمل هي -55 mV)، سُجّل كمون بعد مشبكي قيمته القصوى $potentialMv mV. ما هي طبيعة هذا المشبك والمبلغ العصبي والشوارد المتدخلة؟",
            stemFr = "Dans l'enregistrement synaptique n°$n (potentiel de repos -70 mV, seuil -55 mV), on enregistre un potentiel post-synaptique atteignant $potentialMv mV. Quelle est la nature de cette synapse et le flux ionique impliqué ?",
            optionsAr = if (isExcitatory) {
                listOf(
                    "مشبك تنبيهي: سُجّل زوال استقطاب (PPSE) ناتج عن انفتاح القنوات الكيميائية المبوبة للأستيل كولين ودخول شوارد الصوديوم Na⁺",
                    "مشبك تثبيطي: سُجّل فرط استقطاب (PPSI) ناتج عن دخول شوارد الكلور Cl⁻",
                    "توقف عمل مضخة Na⁺/K⁺ نهائياً دون تدخل المبلغ العصبي",
                    "مشبك تثبيطي يعمل بالـ GABA فقط"
                )
            } else {
                listOf(
                    "مشبك تثبيطي: سُجّل فرط استقطاب (PPSI) ناتج عن تثبت المبلغ الكيميائي GABA وانفتاح القنوات الكيميائية لدخول شوارد الكلور Cl⁻",
                    "مشبك تنبيهي: سُجّل زوال استقطاب (PPSE) ناتج عن دخول Na⁺",
                    "تولد كمون عمل ينتشر على طول الليف بعد المشبكي",
                    "انفتاح القنوات الفولطية للكالسيوم Ca²⁺ في الغشاء بعد المشبكي"
                )
            },
            optionsFr = if (isExcitatory) {
                listOf(
                    "Synapse excitatrice : dépolarisation (PPSE) due à l'entrée de Na⁺ via les récepteurs-canaux à l'acétylcholine",
                    "Synapse inhibitrice : hyperpolarisation (PPSI) par entrée de Cl⁻",
                    "Arrêt définitif de la pompe Na⁺/K⁺",
                    "Synapse inhibitrice GABAergique"
                )
            } else {
                listOf(
                    "Synapse inhibitrice : hyperpolarisation (PPSI) due à l'ouverture des canaux Cl⁻ activés par le GABA",
                    "Synapse excitatrice : dépolarisation (PPSE) par entrée de Na⁺",
                    "Genèse immédiate d'un potentiel d'action propagé",
                    "Ouverture des canaux Ca²⁺ voltage-dépendants post-synaptiques"
                )
            },
            correctIndices = listOf(0),
            explanationAr = if (isExcitatory) {
                "انتقال الكمون الغشائي من -70 mV إلى $potentialMv mV هو زوال استقطاب (PPSE) ناتج عن تدفق داخلي لشوارد Na⁺ عبر القنوات المبوبة كيميائياً إثر تثبت الأستيل كولين."
            } else {
                "انتقال الكمون الغشائي من -70 mV إلى $potentialMv mV هو فرط في الاستقطاب (PPSI) يبعد الغشاء عن عتبة كمون العمل، وينجم عن تثبت الـ GABA ودخول شوارد Cl⁻."
            },
            explanationFr = "La variation du potentiel post-synaptique par rapport à -70 mV distingue un PPSE (entrée de Na⁺) d'un PPSI (entrée de Cl⁻)."
        )
    }

    private fun generateSvtPhotosynthesisQuestion(
        qId: String,
        lesson: Lesson,
        n: Int,
        difficulty: DifficultyLevel,
        mapAr: String,
        mapFr: String,
        srcAr: String,
        srcFr: String
    ): Question {
        val glucoseMoles = 1 + (n % 5)
        val co2Moles = glucoseMoles * 6
        val o2Moles = glucoseMoles * 6
        val atpCalvin = glucoseMoles * 18
        val nadphCalvin = glucoseMoles * 12

        return Question(
            id = qId,
            subjectId = lesson.subjectId,
            lessonId = lesson.id,
            streams = listOf(AcademicStream.SCIENCES_EXP, AcademicStream.MATH),
            type = QuestionType.SINGLE_CHOICE,
            difficulty = difficulty,
            provenance = QuestionProvenance.CURRICULUM_VERIFIED,
            sourceCitationAr = srcAr,
            sourceCitationFr = srcFr,
            curriculumMappingAr = mapAr,
            curriculumMappingFr = mapFr,
            stemAr = "خلال عملية التركيب الضوئي في الصانعة الخضراء، لتركيب $glucoseMoles جزيئة (أو مول) من سداسي الكربون (الغلوكوز C₆H₁₂O₆) في الحشوة عبر حلقة كالفن، ما هي الحصيلة الموافقة من جزيئات CO₂ المثبتة، وO₂ المنطلقة من التيلاكويد، وعدد جزيئات ATP وNADPH,H⁺ المستهلكة؟",
            stemFr = "Lors de la photosynthèse, pour synthétiser $glucoseMoles molécule(s) de glucose (C₆H₁₂O₆) par le cycle de Calvin, quel est le bilan en CO₂ fixé, O₂ dégagé, ATP et NADPH,H⁺ consommés ?",
            optionsAr = listOf(
                "تثبيت $co2Moles CO₂، انطلاق $o2Moles O₂، واستهلاك $atpCalvin ATP و $nadphCalvin NADPH,H⁺",
                "تثبيت $glucoseMoles CO₂، انطلاق $glucoseMoles O₂، واستهلاك $co2Moles ATP و $co2Moles NADPH,H⁺",
                "تثبيت ${co2Moles * 2} CO₂، وامتصاص $o2Moles O₂ دون استهلاك ATP",
                "انطلاق $co2Moles CO₂ وتثبيت $o2Moles O₂ في التيلاكويد"
            ),
            optionsFr = listOf(
                "Fixation de $co2Moles CO₂, dégagement de $o2Moles O₂, consommation de $atpCalvin ATP et $nadphCalvin NADPH,H⁺",
                "Fixation de $glucoseMoles CO₂, dégagement de $glucoseMoles O₂ et $co2Moles ATP",
                "Fixation de ${co2Moles * 2} CO₂ sans consommation d'ATP",
                "Dégagement de $co2Moles CO₂ dans le thylakoïde"
            ),
            correctIndices = listOf(0),
            explanationAr = "تركيب جزيئة غلوكوز واحدة (C₆H₁₂O₆) يتطلب تثبيت 6 CO₂ في حلقة كالفن واستهلاك 18 ATP و 12 NADPH,H⁺ قادمة من المرحلة الكيموضوئية مع انطلاق 6 O₂ من أكسدة 12 H₂O. ومن أجل $glucoseMoles جزيئة غلوكوز نضرب المعاملات في $glucoseMoles.",
            explanationFr = "La synthèse d'une molécule d'hexose consomme 6 CO₂, 18 ATP et 12 NADPH,H⁺ (avec libération de 6 O₂). Pour $glucoseMoles molécule(s), on multiplie par $glucoseMoles."
        )
    }

    private fun generateSvtRespirationQuestion(
        qId: String,
        lesson: Lesson,
        n: Int,
        difficulty: DifficultyLevel,
        mapAr: String,
        mapFr: String,
        srcAr: String,
        srcFr: String
    ): Question {
        val glucoseCount = 1 + (n % 6)
        val respAtp = glucoseCount * 38
        val fermAtp = glucoseCount * 2
        val pyruvateCount = glucoseCount * 2

        return Question(
            id = qId,
            subjectId = lesson.subjectId,
            lessonId = lesson.id,
            streams = listOf(AcademicStream.SCIENCES_EXP, AcademicStream.MATH),
            type = QuestionType.SINGLE_CHOICE,
            difficulty = difficulty,
            provenance = QuestionProvenance.CURRICULUM_VERIFIED,
            sourceCitationAr = srcAr,
            sourceCitationFr = srcFr,
            curriculumMappingAr = mapAr,
            curriculumMappingFr = mapFr,
            stemAr = "عند الهدم الخلوي لـ $glucoseCount مول من الغلوكوز: قارن بين عدد مولات حمض البيروفيك الناتجة عن التحلل السكري، والحصيلة الطاقوية الإجمالية من الـ ATP في الوسط الهوائي (التنفس الكامل) مقابل الوسط اللاهوائي (التخمر):",
            stemFr = "Pour la dégradation cellulaire de $glucoseCount mole(s) de glucose : quel est le nombre de moles d'acide pyruvique formées lors de la glycolyse et le bilan en ATP en aérobiose (respiration) vs anaérobiose (fermentation) ?",
            optionsAr = listOf(
                "$pyruvateCount مول من حمض البيروفيك، و $respAtp مول ATP في التنفس مقابل $fermAtp مول ATP فقط في التخمر",
                "$glucoseCount مول من حمض البيروفيك، و $fermAtp مول ATP في التنفس مقابل $respAtp مول ATP في التخمر",
                "${glucoseCount * 6} مول من حمض البيروفيك، و ${glucoseCount * 10} مول ATP في الحالتين",
                "لا يتشكل حمض البيروفيك في الهيولى أثناء التخمر"
            ),
            optionsFr = listOf(
                "$pyruvateCount moles d'acide pyruvique, $respAtp ATP en respiration contre $fermAtp ATP en fermentation",
                "$glucoseCount moles d'acide pyruvique, $fermAtp ATP en respiration contre $respAtp ATP en fermentation",
                "${glucoseCount * 6} moles d'acide pyruvique et bilan identique",
                "Aucune formation d'acide pyruvique lors de la fermentation"
            ),
            correctIndices = listOf(0),
            explanationAr = "مرحلة التحلل السكري مشتركة بين التنفس والتخمر وتنتج 2 حمض بيروفيك لكل جزيئة غلوكوز ($pyruvateCount مول). في التنفس الخلوي الكامل تنتج كل جزيئة غلوكوز 38 ATP ($respAtp ATP)، بينما في التخمر (هدم جزئي) تنتج 2 ATP فقط ($fermAtp ATP).",
            explanationFr = "La glycolyse produit 2 pyruvates par glucose ($pyruvateCount). Le bilan énergétique est de 38 ATP/glucose en respiration ($respAtp ATP) contre 2 ATP/glucose en fermentation ($fermAtp ATP)."
        )
    }

    private fun generateSvtGeologyQuestion(
        qId: String,
        lesson: Lesson,
        n: Int,
        difficulty: DifficultyLevel,
        mapAr: String,
        mapFr: String,
        srcAr: String,
        srcFr: String
    ): Question {
        val variant = n % 3
        return Question(
            id = qId,
            subjectId = lesson.subjectId,
            lessonId = lesson.id,
            streams = listOf(AcademicStream.SCIENCES_EXP),
            type = QuestionType.SINGLE_CHOICE,
            difficulty = difficulty,
            provenance = QuestionProvenance.CURRICULUM_VERIFIED,
            sourceCitationAr = srcAr,
            sourceCitationFr = srcFr,
            curriculumMappingAr = mapAr,
            curriculumMappingFr = mapFr,
            stemAr = when (variant) {
                0 -> "في الدراسة السيسمولوجية رقم $n للبنية الداخلية للكرة الأرضية: ما الذي يفصل بين القشرة الأرضية والبرنس العلوي، وما هي صخرة البرنس الأساسية؟"
                1 -> "في دراسة نشاط الظهرات المحيطية رقم $n: ما هو أصل الماغما البازلتي المشكل للوح المحيطي الجديد على مستوى محور الظهرة؟"
                else -> "في دراسة مناطق الغوص (Subduction) رقم $n: كيف يتشكل الماغما الأنديزيتي اللزج المؤدي إلى البراكين الانفجارية في اللوح الطافي؟"
            },
            stemFr = when (variant) {
                0 -> "Étude géologique n°$n : Quelle discontinuité sépare la croûte terrestre du manteau supérieur et quelle est la roche mantellique principale ?"
                1 -> "Étude n°$n : Quelle est l'origine du magma basaltique au niveau de l'axe des dorsales océaniques ?"
                else -> "Étude n°$n : Comment se forme le magma andésitique dans les zones de subduction ?"
            },
            optionsAr = when (variant) {
                0 -> listOf(
                    "انقطاع موهو (Mohorovičić)، وصخرة البرنس الأساسية هي البيريدوتيت (Péridotite)",
                    "انقطاع غوتنبرغ على عمق 2900 كلم، وصخرته البازلت فقط",
                    "انقطاع ليمان على عمق 5100 كلم، وصخرته الغرانيت",
                    "منطقة السرعات المنخفضة LVZ، وصخرتها الحديد والنيكل"
                )
                1 -> listOf(
                    "الانصهار الجزئي لبيريدوتيت البرنس تحت محور الظهرة نتيجة انخفاض الضغط وتيارات الحمل الحراري الصاعدة",
                    "انصهار كلي للقشرة القارية الغرانيتية تحت الخندق المحيطي",
                    "تصلب الحديد المنصهر الصاعد مباشرة من النواة الخارجية",
                    "تحول الصخور الرسوبية بفعل الضغط المنخفض والحرارة المنخفضة"
                )
                else -> listOf(
                    "تجفيف صخور اللوح المحيطي الغائص وتحرر الماء الذي يخفض درجة انصهار بيريدوتيت اللوح الطافي فيحدث انصهار جزئي له",
                    "انخفاض مفاجئ في الضغط في محور الظهرة الوسط محيطية",
                    "انعدام النشاط الزلزالي على طول مستوي بنيوف",
                    "تبريد سريع للغابرو في قاع المحيط"
                )
            },
            optionsFr = when (variant) {
                0 -> listOf(
                    "La discontinuité de Moho, et la roche du manteau est la péridotite",
                    "La discontinuité de Gutenberg (2900 km) et le basalte",
                    "La discontinuité de Lehmann (5100 km) et le granite",
                    "La LVZ et l'alliage fer-nickel"
                )
                1 -> listOf(
                    "Fusion partielle par décompression adiabatique de la péridotite mantellique à l'aplomb de la dorsale",
                    "Fusion totale de la croûte continentale granitique",
                    "Remontée directe du fer du noyau externe",
                    "Métamorphisme des roches sédimentaires"
                )
                else -> listOf(
                    "Déshydratation de la plaque océanique plongeante libérant de l'eau qui abaisse le point de fusion de la péridotite du coin mantellique",
                    "Décompression à l'axe d'une dorsale",
                    "Absence de séismes sur le plan de Benioff",
                    "Refroidissement rapide du gabbro"
                )
            },
            correctIndices = listOf(0),
            explanationAr = when (variant) {
                0 -> "انقطاع موهو يفصل القشرة (المحيطية أو القارية) عن البرنس العلوي المشكل أساساً من صخرة البيريدوتيت الغنية بالأوليفين والبيروكسين."
                1 -> "في الظهرات تصعد تيارات الحمل الحراري فينخفض الضغط على البيريدوتيت الساخن فيخضع لانصهار جزئي يعطي ماغما بازلتياً يشكل البازلت السطحي والغابرو العميق."
                else -> "أثناء غوص اللوح المحيطي تتحول معادنه المميهة وتطرح الماء في برنس اللوح الطافي، مما يخفض درجة انصهار البيريدوتيت فينصهر جزئياً مولداً ماغما أنديزيتياً."
            },
            explanationFr = "La tectonique des plaques relie les discontinuités sismologiques (Moho, Gutenberg, Lehmann) à la fusion partielle de la péridotite aux dorsales et en subduction."
        )
    }

    // -------------------------------------------------------------------------
    // PHYSICS Generators (Units 1..7)
    // -------------------------------------------------------------------------

    private fun generatePhysKineticsQuestion(
        qId: String,
        lesson: Lesson,
        n: Int,
        difficulty: DifficultyLevel,
        mapAr: String,
        mapFr: String,
        srcAr: String,
        srcFr: String
    ): Question {
        val xmaxMmol = 10 + n * 2
        val halfX = xmaxMmol / 2.0
        val volumeL = 0.2
        val slopeMmolMin = 4 + (n % 6)
        val vVol = String.format(Locale.US, "%.1f", slopeMmolMin / volumeL)

        return Question(
            id = qId,
            subjectId = lesson.subjectId,
            lessonId = lesson.id,
            streams = listOf(AcademicStream.SCIENCES_EXP, AcademicStream.MATH, AcademicStream.TECH_MATH),
            type = if (n % 4 == 0) QuestionType.STRUCTURED else QuestionType.SINGLE_CHOICE,
            difficulty = difficulty,
            provenance = QuestionProvenance.CURRICULUM_VERIFIED,
            sourceCitationAr = srcAr,
            sourceCitationFr = srcFr,
            curriculumMappingAr = mapAr,
            curriculumMappingFr = mapFr,
            stemAr = "في متابعة زمنية لتحول كيميائي تام في وسط مائي حجمه الكلي V_T = 200 mL (أي 0.2 L)، وجدنا التقدم الأعظمي x_max = $xmaxMmol mmol وميل مماس منحنى التقدم (dx/dt) عند اللحظة t₁ يساوي $slopeMmolMin mmol/min. ما هي قيمة التقدم عند زمن نصف التفاعل x(t½) والسرعة الحجمية للتفاعل v_vol(t₁)؟",
            stemFr = "Pour une réaction totale dans un volume V_T = 0,2 L, on a x_max = $xmaxMmol mmol et (dx/dt) = $slopeMmolMin mmol/min à t₁. Quelles sont les valeurs de x(t½) et de la vitesse volumique v_vol(t₁) ?",
            optionsAr = listOf(
                "x(t½) = $halfX mmol و السرعة الحجمية v_vol(t₁) = $vVol mmol/(L·min)",
                "x(t½) = $xmaxMmol mmol و السرعة الحجمية v_vol(t₁) = ${slopeMmolMin * 0.2} mmol/(L·min)",
                "x(t½) = ${halfX / 2} mmol و السرعة الحجمية v_vol(t₁) = $slopeMmolMin mmol/(L·min)",
                "x(t½) = ${xmaxMmol * 2} mmol و السرعة الحجمية v_vol(t₁) = 0 mmol/(L·min)"
            ),
            optionsFr = listOf(
                "x(t½) = $halfX mmol et v_vol(t₁) = $vVol mmol/(L·min)",
                "x(t½) = $xmaxMmol mmol et v_vol(t₁) = ${slopeMmolMin * 0.2} mmol/(L·min)",
                "x(t½) = ${halfX / 2} mmol et v_vol(t₁) = $slopeMmolMin mmol/(L·min)",
                "x(t½) = ${xmaxMmol * 2} mmol et v_vol(t₁) = 0"
            ),
            correctIndices = listOf(0),
            structuredRubricStepsAr = listOf(
                "1) التفاعل تام إذن x_f = x_max = $xmaxMmol mmol، ومنه x(t½) = x_max / 2 = $halfX mmol.",
                "2) كتابة قانون السرعة الحجمية: v_vol(t₁) = (1 / V_T) · (dx/dt).",
                "3) التعويض العددي: v_vol(t₁) = (1 / 0.2) × $slopeMmolMin = $vVol mmol/(L·min)."
            ),
            explanationAr = "بما أن التحول تام فإن x(t½) = x_max / 2 = $xmaxMmol / 2 = $halfX mmol. والسرعة الحجمية للتفاعل تُحسب بقسمة سرعة التفاعل على الحجم الكلي باللتر: v_vol = $slopeMmolMin / 0.2 = $vVol mmol/(L·min).",
            explanationFr = "x(t½) = x_max / 2 = $halfX mmol et v_vol = (1/V_T)·(dx/dt) = $slopeMmolMin / 0,2 = $vVol mmol/(L·min)."
        )
    }

    private fun generatePhysMechanicsQuestion(
        qId: String,
        lesson: Lesson,
        n: Int,
        difficulty: DifficultyLevel,
        mapAr: String,
        mapFr: String,
        srcAr: String,
        srcFr: String
    ): Question {
        val massKg = 2 + (n % 5)
        val kCoeff = 4 + (n % 4)
        val gVal = 10
        // m dv/dt + k v = m g (neglecting Archimedes) => v_lim = m*g / k, tau = m / k
        val vLim = String.format(Locale.US, "%.2f", (massKg * gVal).toDouble() / kCoeff)
        val tauSec = String.format(Locale.US, "%.2f", massKg.toDouble() / kCoeff)

        return Question(
            id = qId,
            subjectId = lesson.subjectId,
            lessonId = lesson.id,
            streams = listOf(AcademicStream.SCIENCES_EXP, AcademicStream.MATH, AcademicStream.TECH_MATH),
            type = QuestionType.SINGLE_CHOICE,
            difficulty = difficulty,
            provenance = QuestionProvenance.CURRICULUM_VERIFIED,
            sourceCitationAr = srcAr,
            sourceCitationFr = srcFr,
            curriculumMappingAr = mapAr,
            curriculumMappingFr = mapFr,
            stemAr = "يسقط جسم صلب كتلته m = $massKg kg شاقولياً في الهواء (بإهمال دافعة أرخميدس أمام الثقل، مع g = 10 m/s²) ويخضع لقوة احتكاك هوائي من الشكل f = k·v حيث k = $kCoeff kg/s. ما هي قيمة كل من ثابت الزمن الميكانيكي τ والسرعة الحدية v_lim؟",
            stemFr = "Un solide de masse m = $massKg kg tombe verticalement (g = 10 m/s², poussée d'Archimède négligée) avec un frottement f = k·v où k = $kCoeff kg/s. Quelles sont les valeurs de τ et v_lim ?",
            optionsAr = listOf(
                "ثابت الزمن τ = $tauSec s والسرعة الحدية v_lim = $vLim m/s",
                "ثابت الزمن τ = $vLim s والسرعة الحدية v_lim = $tauSec m/s",
                "ثابت الزمن τ = ${massKg * kCoeff} s والسرعة الحدية v_lim = ${massKg * gVal} m/s",
                "ثابت الزمن τ = 1.00 s والسرعة الحدية v_lim = 0 m/s"
            ),
            optionsFr = listOf(
                "τ = $tauSec s et v_lim = $vLim m/s",
                "τ = $vLim s et v_lim = $tauSec m/s",
                "τ = ${massKg * kCoeff} s et v_lim = ${massKg * gVal} m/s",
                "τ = 1,00 s et v_lim = 0 m/s"
            ),
            correctIndices = listOf(0),
            explanationAr = "من المعادلة التفاضلية للسقوط الشاقولي dv/dt + (k/m)·v = g نستنتج ثابت الزمن τ = m / k = $massKg / $kCoeff = $tauSec s، وعند النظام الدائم (dv/dt = 0) تكون السرعة الحدية v_lim = (m·g) / k = ${massKg * gVal} / $kCoeff = $vLim m/s.",
            explanationFr = "L'équation différentielle dv/dt + (k/m)·v = g donne τ = m/k = $tauSec s et v_lim = m·g/k = $vLim m/s."
        )
    }

    private fun generatePhysRcRlQuestion(
        qId: String,
        lesson: Lesson,
        n: Int,
        difficulty: DifficultyLevel,
        mapAr: String,
        mapFr: String,
        srcAr: String,
        srcFr: String
    ): Question {
        val rOhm = 100 * (1 + (n % 5)) // 100..500 Ohm
        val cMicroF = 10 * (1 + (n % 4)) // 10..40 uF
        val voltageE = 6 + (n % 7) // 6..12 V
        val tauMs = String.format(Locale.US, "%.1f", (rOhm * cMicroF) / 1000.0) // in ms
        val i0Ma = String.format(Locale.US, "%.1f", (voltageE * 1000.0) / rOhm)

        return Question(
            id = qId,
            subjectId = lesson.subjectId,
            lessonId = lesson.id,
            streams = listOf(AcademicStream.SCIENCES_EXP, AcademicStream.MATH, AcademicStream.TECH_MATH),
            type = if (n % 4 == 0) QuestionType.STRUCTURED else QuestionType.SINGLE_CHOICE,
            difficulty = difficulty,
            provenance = QuestionProvenance.CURRICULUM_VERIFIED,
            sourceCitationAr = srcAr,
            sourceCitationFr = srcFr,
            curriculumMappingAr = mapAr,
            curriculumMappingFr = mapFr,
            stemAr = "في دارة شحن مكثفة غير مشحونة سعتها C = $cMicroF μF عبر ناقل أومي مقاومته R = $rOhm Ω ومولد للتوتر الثابت E = $voltageE V، ما هي قيمة ثابت الزمن τ (بالميلي ثانية ms) والشدة الأعظمية الابتدائية للتيار I₀ (بالميلي أمبير mA) لحظة غلق القاطعة t = 0؟",
            stemFr = "Dans un circuit RC série avec C = $cMicroF μF, R = $rOhm Ω et E = $voltageE V, quelles sont les valeurs de la constante de temps τ (en ms) et de l'intensité initiale I₀ (en mA) à t = 0 ?",
            optionsAr = listOf(
                "τ = $tauMs ms و الشدة الأعظمية I₀ = $i0Ma mA",
                "τ = $i0Ma ms و الشدة الأعظمية I₀ = $tauMs mA",
                "τ = ${rOhm + cMicroF} ms و الشدة الأعظمية I₀ = 0 mA",
                "τ = ${tauMs}00 ms و الشدة الأعظمية I₀ = ${voltageE * rOhm} mA"
            ),
            optionsFr = listOf(
                "τ = $tauMs ms et I₀ = $i0Ma mA",
                "τ = $i0Ma ms et I₀ = $tauMs mA",
                "τ = ${rOhm + cMicroF} ms et I₀ = 0 mA",
                "τ = ${tauMs}00 ms et I₀ = ${voltageE * rOhm} mA"
            ),
            correctIndices = listOf(0),
            structuredRubricStepsAr = listOf(
                "1) حساب ثابت الزمن: τ = R · C = $rOhm × ($cMicroF × 10⁻⁶) s = $tauMs ms.",
                "2) عند t = 0 تكون المكثفة فارغة u_C(0) = 0 فيكون u_R(0) = E.",
                "3) الشدة الابتدائية الأعظمية: I₀ = E / R = $voltageE / $rOhm A = $i0Ma mA."
            ),
            explanationAr = "لدينا τ = R · C = $rOhm × $cMicroF × 10⁻⁶ s = $tauMs ms. وعند اللحظة t = 0 يكون u_C(0) = 0 ومنه حسب قانون جمع التوترات I₀ = E / R = $voltageE / $rOhm A = $i0Ma mA.",
            explanationFr = "τ = R·C = $tauMs ms et à t = 0, u_C(0) = 0 d'où I₀ = E/R = $i0Ma mA."
        )
    }

    private fun generatePhysEquilibriumQuestion(
        qId: String,
        lesson: Lesson,
        n: Int,
        difficulty: DifficultyLevel,
        mapAr: String,
        mapFr: String,
        srcAr: String,
        srcFr: String
    ): Question {
        val vaMl = 20
        val vbeMl = 10 + (n % 15) * 2
        val cbMolL = 0.05
        val caFormatted = String.format(Locale.US, "%.4f", (cbMolL * vbeMl) / vaMl)
        val halfVbe = vbeMl / 2.0

        return Question(
            id = qId,
            subjectId = lesson.subjectId,
            lessonId = lesson.id,
            streams = listOf(AcademicStream.SCIENCES_EXP, AcademicStream.MATH, AcademicStream.TECH_MATH),
            type = QuestionType.SINGLE_CHOICE,
            difficulty = difficulty,
            provenance = QuestionProvenance.CURRICULUM_VERIFIED,
            sourceCitationAr = srcAr,
            sourceCitationFr = srcFr,
            curriculumMappingAr = mapAr,
            curriculumMappingFr = mapFr,
            stemAr = "نعاير حجماً V_A = $vaMl mL من محلول حمض ضعيف HA مجهول التركيز C_A بواسطة محلول هيدروكسيد الصوديوم (Na⁺ + HO⁻) تركيزه المولي C_B = $cbMolL mol/L، فنبلغ نقطة التكافؤ عند إضافة حجم V_BE = $vbeMl mL. ما هو التركيز C_A وما هو حجم الأساس المضاف الموافق لـ pH = pKa؟",
            stemFr = "On titre V_A = $vaMl mL d'un acide faible HA de concentration C_A par la soude de concentration C_B = $cbMolL mol/L. L'équivalence est atteinte pour V_BE = $vbeMl mL. Quelles sont les valeurs de C_A et du volume à la demi-équivalence (pH = pKa) ?",
            optionsAr = listOf(
                "التركيز C_A = $caFormatted mol/L و يتحقق pH = pKa عند الحجم V_B = $halfVbe mL",
                "التركيز C_A = $cbMolL mol/L و يتحقق pH = pKa عند الحجم V_B = $vbeMl mL",
                "التركيز C_A = ${String.format(Locale.US, "%.4f", (cbMolL * vaMl) / vbeMl)} mol/L و V_B = ${vbeMl * 2} mL",
                "التركيز C_A = 1.0000 mol/L و يتحقق pH = pKa عند V_B = 0 mL"
            ),
            optionsFr = listOf(
                "C_A = $caFormatted mol/L et pH = pKa à la demi-équivalence V_B = $halfVbe mL",
                "C_A = $cbMolL mol/L et pH = pKa à V_B = $vbeMl mL",
                "C_A = ${String.format(Locale.US, "%.4f", (cbMolL * vaMl) / vbeMl)} mol/L et V_B = ${vbeMl * 2} mL",
                "C_A = 1,0000 mol/L et V_B = 0 mL"
            ),
            correctIndices = listOf(0),
            explanationAr = "عند نقطة التكافؤ تكون المتفاعلات بالنسب الستوكيومترية: C_A · V_A = C_B · V_BE ومنه C_A = ($cbMolL × $vbeMl) / $vaMl = $caFormatted mol/L. وعند نصف التكافؤ V_B = V_BE / 2 = $halfVbe mL يكون [HA] = [A⁻] ومنه pH = pKa.",
            explanationFr = "À l'équivalence, C_A = (C_B · V_BE)/V_A = $caFormatted mol/L, et à la demi-équivalence V_B = V_BE/2 = $halfVbe mL, on a pH = pKa."
        )
    }

    private fun generatePhysNuclearQuestion(
        qId: String,
        lesson: Lesson,
        n: Int,
        difficulty: DifficultyLevel,
        mapAr: String,
        mapFr: String,
        srcAr: String,
        srcFr: String
    ): Question {
        val halfLives = 1 + (n % 5) // 1..5
        val divisor = 1 shl halfLives // 2, 4, 8, 16, 32
        val a0Bq = divisor * (100 + n * 10)
        val aRemaining = a0Bq / divisor
        val percentRemaining = String.format(Locale.US, "%.2f", 100.0 / divisor)

        return Question(
            id = qId,
            subjectId = lesson.subjectId,
            lessonId = lesson.id,
            streams = listOf(AcademicStream.SCIENCES_EXP, AcademicStream.MATH, AcademicStream.TECH_MATH),
            type = QuestionType.SINGLE_CHOICE,
            difficulty = difficulty,
            provenance = QuestionProvenance.CURRICULUM_VERIFIED,
            sourceCitationAr = srcAr,
            sourceCitationFr = srcFr,
            curriculumMappingAr = mapAr,
            curriculumMappingFr = mapFr,
            stemAr = "منبع مشع نشاطه الإشعاعي الابتدائي عند اللحظة t = 0 هو A₀ = $a0Bq Bq. ما هي قيمة نشاطه الإشعاعي A(t) والنسبة المئوية للأنوية المشعة المتبقية بعد مرور مدة زمنية قدرها t = $halfLives · t½؟",
            stemFr = "Une source radioactive a une activité initiale A₀ = $a0Bq Bq. Quelle est son activité A(t) et le pourcentage de noyaux restants à l'instant t = $halfLives · t½ ?",
            optionsAr = listOf(
                "النشاط المتبقي A(t) = $aRemaining Bq ونسبة الأنوية المتبقية هي $percentRemaining%",
                "النشاط المتبقي A(t) = ${a0Bq / halfLives} Bq ونسبة الأنوية المتبقية هي ${100 / halfLives}%",
                "النشاط المتبقي A(t) = ${a0Bq - aRemaining} Bq ونسبة الأنوية المتبقية هي 50%",
                "النشاط المتبقي A(t) = 0 Bq بعد مرور نصف العمر الأول"
            ),
            optionsFr = listOf(
                "A(t) = $aRemaining Bq et $percentRemaining% des noyaux initiaux restent non désintégrés",
                "A(t) = ${a0Bq / halfLives} Bq et ${100 / halfLives}%",
                "A(t) = ${a0Bq - aRemaining} Bq et 50%",
                "A(t) = 0 Bq"
            ),
            correctIndices = listOf(0),
            explanationAr = "حسب قانون التناقص الإشعاعي عند اللحظة t = n · t½ يكون A(n·t½) = A₀ / 2^n. من أجل n = $halfLives لدينا 2^$halfLives = $divisor، إذن A = $a0Bq / $divisor = $aRemaining Bq ونسبة الأنوية المتبقية 100% / $divisor = $percentRemaining%.",
            explanationFr = "À t = $halfLives · t½, l'activité est divisée par 2^$halfLives = $divisor, soit A(t) = $aRemaining Bq ($percentRemaining% restants)."
        )
    }

    private fun generatePhysEsterQuestion(
        qId: String,
        lesson: Lesson,
        n: Int,
        difficulty: DifficultyLevel,
        mapAr: String,
        mapFr: String,
        srcAr: String,
        srcFr: String
    ): Question {
        val alcoholType = n % 3 // 0: primary (67%), 1: secondary (60%), 2: tertiary (5%)
        val initialMoles = 1.0 + (n % 4) * 0.5
        val yieldPercent = when (alcoholType) {
            0 -> 67
            1 -> 60
            else -> 5
        }
        val xfMoles = String.format(Locale.US, "%.2f", initialMoles * (yieldPercent / 100.0))
        val alcoholNameAr = when (alcoholType) {
            0 -> "كحول أولي (K = 4)"
            1 -> "كحول ثانوي (K = 2.25)"
            else -> "كحول ثالثي"
        }
        val alcoholNameFr = when (alcoholType) {
            0 -> "alcool primaire (K = 4)"
            1 -> "alcool secondaire (K = 2,25)"
            else -> "alcool tertiaire"
        }

        return Question(
            id = qId,
            subjectId = lesson.subjectId,
            lessonId = lesson.id,
            streams = listOf(AcademicStream.SCIENCES_EXP, AcademicStream.MATH, AcademicStream.TECH_MATH),
            type = QuestionType.SINGLE_CHOICE,
            difficulty = difficulty,
            provenance = QuestionProvenance.CURRICULUM_VERIFIED,
            sourceCitationAr = srcAr,
            sourceCitationFr = srcFr,
            curriculumMappingAr = mapAr,
            curriculumMappingFr = mapFr,
            stemAr = "نحقق تفاعل أسترة لمزيج ابتدائي متساوي المولات يتكون من n₀ = $initialMoles mol من حمض كربوكسيلي و n₀ = $initialMoles mol من $alcoholNameAr. عند بلوغ التوازن الكيميائي، ما هو مردود الأسترة r وكمية مادة الإستر المتشكل n_f(ester)؟",
            stemFr = "On réalise l'estérification d'un mélange équimolaire de n₀ = $initialMoles mol d'acide carboxylique et n₀ = $initialMoles mol d'un $alcoholNameFr. Quels sont le rendement r et la quantité d'ester formé à l'équilibre ?",
            optionsAr = listOf(
                "مردود التفاعل r = $yieldPercent% وكمية الإستر عند التوازن x_f = $xfMoles mol",
                "مردود التفاعل r = 100% وكمية الإستر عند التوازن x_f = $initialMoles mol",
                "مردود التفاعل r = 33% وكمية الإستر عند التوازن x_f = ${String.format(Locale.US, "%.2f", initialMoles * 0.33)} mol",
                "مردود التفاعل r = 0% لأن تفاعل الأسترة لا يحدث إطلاقاً"
            ),
            optionsFr = listOf(
                "Rendement r = $yieldPercent% et quantité d'ester x_f = $xfMoles mol",
                "Rendement r = 100% et x_f = $initialMoles mol",
                "Rendement r = 33% et x_f = ${String.format(Locale.US, "%.2f", initialMoles * 0.33)} mol",
                "Rendement r = 0%"
            ),
            correctIndices = listOf(0),
            explanationAr = "في مزيج ابتدائي متساوي المولات (n₀ = $initialMoles mol)، مردود الأسترة ثابت حسب صنف الكحول: 67% للأولي، 60% للثانوي، و5% للثالثي. وعليه تكون كمية الإستر المتشكلة عند التوازن x_f = n₀ × (r / 100) = $xfMoles mol.",
            explanationFr = "Pour un mélange équimolaire avec un $alcoholNameFr, le rendement à l'équilibre est de $yieldPercent%, soit x_f = $xfMoles mol d'ester."
        )
    }

    private fun generatePhysOscillationsQuestion(
        qId: String,
        lesson: Lesson,
        n: Int,
        difficulty: DifficultyLevel,
        mapAr: String,
        mapFr: String,
        srcAr: String,
        srcFr: String
    ): Question {
        val massKg = 0.1 * (1 + (n % 4)) // 0.1 .. 0.4 kg
        val kNPerM = (massKg * 100 * (1 + (n % 3)) * (1 + (n % 3))).toInt() // so sqrt(k/m) is exact!
        val omega0 = 10 * (1 + (n % 3))
        val periodSec = String.format(Locale.US, "%.3f", (2.0 * Math.PI) / omega0)

        return Question(
            id = qId,
            subjectId = lesson.subjectId,
            lessonId = lesson.id,
            streams = listOf(AcademicStream.SCIENCES_EXP, AcademicStream.MATH, AcademicStream.TECH_MATH),
            type = QuestionType.SINGLE_CHOICE,
            difficulty = difficulty,
            provenance = QuestionProvenance.CURRICULUM_VERIFIED,
            sourceCitationAr = srcAr,
            sourceCitationFr = srcFr,
            curriculumMappingAr = mapAr,
            curriculumMappingFr = mapFr,
            stemAr = "نواس مرن أفقي غير متخامد يتكون من جسم صلب كتلته m = ${String.format(Locale.US, "%.1f", massKg)} kg مربوط بنابض مرن ثابت مرونته k = $kNPerM N/m. ما هي قيمة النبض الذاتي ω₀ والدور الذاتي T₀ للاهتزازات الحرة؟",
            stemFr = "Un pendule élastique horizontal non amorti comporte une masse m = ${String.format(Locale.US, "%.1f", massKg)} kg et un ressort de raideur k = $kNPerM N/m. Quelles sont les valeurs de la pulsation propre ω₀ et de la période propre T₀ ?",
            optionsAr = listOf(
                "النبض الذاتي ω₀ = $omega0 rad/s والدور الذاتي T₀ = 2π / ω₀ ≈ $periodSec s",
                "النبض الذاتي ω₀ = ${omega0 * omega0} rad/s والدور الذاتي T₀ = $omega0 s",
                "النبض الذاتي ω₀ = ${omega0 / 2} rad/s والدور الذاتي T₀ = 1.000 s",
                "النبض الذاتي ω₀ = 1 rad/s والدور الذاتي لا يتعلق بكتلة الجسم m"
            ),
            optionsFr = listOf(
                "ω₀ = $omega0 rad/s et T₀ = 2π / ω₀ ≈ $periodSec s",
                "ω₀ = ${omega0 * omega0} rad/s et T₀ = $omega0 s",
                "ω₀ = ${omega0 / 2} rad/s et T₀ = 1,000 s",
                "ω₀ = 1 rad/s"
            ),
            correctIndices = listOf(0),
            explanationAr = "المعادلة التفاضلية للنواس المرن الحر غير المتخامد هي d²x/dt² + (k/m)·x = 0، ومنه النبض الذاتي ω₀ = √(k / m) = √($kNPerM / ${String.format(Locale.US, "%.1f", massKg)}) = $omega0 rad/s، والدور الذاتي T₀ = 2π / ω₀ ≈ $periodSec s.",
            explanationFr = "La pulsation propre vaut ω₀ = √(k/m) = $omega0 rad/s et la période propre vaut T₀ = 2π/ω₀ ≈ $periodSec s."
        )
    }

    // -------------------------------------------------------------------------
    // MATHEMATICS Generators (Units 1..7)
    // -------------------------------------------------------------------------

    private fun generateMathLimitsQuestion(
        qId: String,
        lesson: Lesson,
        n: Int,
        difficulty: DifficultyLevel,
        mapAr: String,
        mapFr: String,
        srcAr: String,
        srcFr: String
    ): Question {
        val aSlope = 2 + (n % 5)
        val bIntercept = -3 + (n % 7)
        val cNum = 1 + (n % 6)
        val signStr = if (bIntercept >= 0) "+ $bIntercept" else "- ${-bIntercept}"

        return Question(
            id = qId,
            subjectId = lesson.subjectId,
            lessonId = lesson.id,
            streams = AcademicStream.entries,
            type = QuestionType.SINGLE_CHOICE,
            difficulty = difficulty,
            provenance = QuestionProvenance.CURRICULUM_VERIFIED,
            sourceCitationAr = srcAr,
            sourceCitationFr = srcFr,
            curriculumMappingAr = mapAr,
            curriculumMappingFr = mapFr,
            stemAr = "لتكن الدالة f المعرفة على المجال ]0, +∞[ بـ: f(x) = ${aSlope}x $signStr + ($cNum / x). ما هي معادلة المستقيم المقارب المائل (Δ) للمنحنى (C_f) بجوار +∞ وما هي قيمة المشتقة f'(1)؟",
            stemFr = "Soit f définie sur ]0, +∞[ par f(x) = ${aSlope}x $signStr + ($cNum / x). Quelle est l'équation de l'asymptote oblique (Δ) en +∞ et la valeur de f'(1) ?",
            optionsAr = listOf(
                "المقارب المائل (Δ): y = ${aSlope}x $signStr و قيمة المشتقة f'(1) = ${aSlope - cNum}",
                "المقارب المائل (Δ): y = ${cNum}x $signStr و قيمة المشتقة f'(1) = ${aSlope + cNum}",
                "المقارب المائل (Δ): y = $aSlope و قيمة المشتقة f'(1) = 0",
                "المقارب المائل (Δ): y = ${aSlope}x و قيمة المشتقة f'(1) = $bIntercept"
            ),
            optionsFr = listOf(
                "Asymptote (Δ) : y = ${aSlope}x $signStr et f'(1) = ${aSlope - cNum}",
                "Asymptote (Δ) : y = ${cNum}x $signStr et f'(1) = ${aSlope + cNum}",
                "Asymptote (Δ) : y = $aSlope et f'(1) = 0",
                "Asymptote (Δ) : y = ${aSlope}x et f'(1) = $bIntercept"
            ),
            correctIndices = listOf(0),
            explanationAr = "لدينا lim (x→+∞) [f(x) - (${aSlope}x $signStr)] = lim (x→+∞) ($cNum / x) = 0، إذن المستقيم ذو المعادلة y = ${aSlope}x $signStr مقارب مائل بجوار +∞. ولدينا المشتقة f'(x) = $aSlope - ($cNum / x²) ومنه f'(1) = $aSlope - $cNum = ${aSlope - cNum}.",
            explanationFr = "Comme lim ($cNum/x) = 0 en +∞, la droite y = ${aSlope}x $signStr est asymptote oblique. De plus, f'(x) = $aSlope - $cNum/x², donc f'(1) = ${aSlope - cNum}."
        )
    }

    private fun generateMathExpLnQuestion(
        qId: String,
        lesson: Lesson,
        n: Int,
        difficulty: DifficultyLevel,
        mapAr: String,
        mapFr: String,
        srcAr: String,
        srcFr: String
    ): Question {
        val aCoeff = 2 + (n % 5)
        val bCoeff = aCoeff * (1 + (n % 4))
        val constTerm = -bCoeff / aCoeff
        val y0 = 3 + (n % 5)
        val cVal = y0 - constTerm

        return Question(
            id = qId,
            subjectId = lesson.subjectId,
            lessonId = lesson.id,
            streams = listOf(AcademicStream.SCIENCES_EXP, AcademicStream.MATH, AcademicStream.TECH_MATH, AcademicStream.GESTION_ECO),
            type = QuestionType.SINGLE_CHOICE,
            difficulty = difficulty,
            provenance = QuestionProvenance.CURRICULUM_VERIFIED,
            sourceCitationAr = srcAr,
            sourceCitationFr = srcFr,
            curriculumMappingAr = mapAr,
            curriculumMappingFr = mapFr,
            stemAr = "نعتبر المعادلة التفاضلية (E): y' = ${aCoeff}y + $bCoeff. ما هو الحل الخاص f للمعادلة (E) على R الذي يحقق الشرط الابتدائي f(0) = $y0؟",
            stemFr = "On considère l'équation différentielle (E) : y' = ${aCoeff}y + $bCoeff. Quelle est l'unique solution f sur R vérifiant f(0) = $y0 ?",
            optionsAr = listOf(
                "f(x) = $cVal · e^(${aCoeff}x) - ${-constTerm}",
                "f(x) = $y0 · e^(${aCoeff}x) + $bCoeff",
                "f(x) = ${aCoeff} · e^(${bCoeff}x) - $y0",
                "f(x) = $cVal · ln(${aCoeff}x + 1)"
            ),
            optionsFr = listOf(
                "f(x) = $cVal · e^(${aCoeff}x) - ${-constTerm}",
                "f(x) = $y0 · e^(${aCoeff}x) + $bCoeff",
                "f(x) = ${aCoeff} · e^(${bCoeff}x) - $y0",
                "f(x) = $cVal · ln(${aCoeff}x + 1)"
            ),
            correctIndices = listOf(0),
            explanationAr = "الحل العام للمعادلة التفاضلية y' = a·y + b هو f(x) = C·e^(ax) - b/a = C·e^(${aCoeff}x) - ${-constTerm}. وبما أن f(0) = $y0 فإن C - ${-constTerm} = $y0 أي C = $cVal، ومنه f(x) = $cVal·e^(${aCoeff}x) - ${-constTerm}.",
            explanationFr = "Les solutions générales sont f(x) = C·e^(${aCoeff}x) - $bCoeff/$aCoeff = C·e^(${aCoeff}x) - ${-constTerm}. La condition f(0) = $y0 donne C = $cVal."
        )
    }

    private fun generateMathSequencesQuestion(
        qId: String,
        lesson: Lesson,
        n: Int,
        difficulty: DifficultyLevel,
        mapAr: String,
        mapFr: String,
        srcAr: String,
        srcFr: String
    ): Question {
        val u0 = 2 + (n % 6)
        val rReason = 3 + (n % 5)
        val kIndex = 10 + (n % 10)
        val uk = u0 + kIndex * rReason
        val sumCount = kIndex + 1
        val sumVal = (sumCount * (u0 + uk)) / 2

        return Question(
            id = qId,
            subjectId = lesson.subjectId,
            lessonId = lesson.id,
            streams = AcademicStream.entries,
            type = if (n % 4 == 0) QuestionType.STRUCTURED else QuestionType.SINGLE_CHOICE,
            difficulty = difficulty,
            provenance = QuestionProvenance.CURRICULUM_VERIFIED,
            sourceCitationAr = srcAr,
            sourceCitationFr = srcFr,
            curriculumMappingAr = mapAr,
            curriculumMappingFr = mapFr,
            stemAr = "لتكن (u_n) متتالية حسابية معرفة على N بحدها الأول u₀ = $u0 وأساسها r = $rReason. ما هي قيمة الحد u_$kIndex وقيمة المجموع S = u₀ + u₁ + ... + u_$kIndex؟",
            stemFr = "Soit (u_n) une suite arithmétique de premier terme u₀ = $u0 et de raison r = $rReason. Quelles sont les valeurs de u_$kIndex et de la somme S = u₀ + u₁ + ... + u_$kIndex ?",
            optionsAr = listOf(
                "u_$kIndex = $uk و المجموع S = $sumVal",
                "u_$kIndex = ${u0 + (kIndex - 1) * rReason} و المجموع S = ${kIndex * uk}",
                "u_$kIndex = ${u0 * rReason} و المجموع S = ${sumVal + rReason}",
                "u_$kIndex = $sumVal و المجموع S = $uk"
            ),
            optionsFr = listOf(
                "u_$kIndex = $uk et S = $sumVal",
                "u_$kIndex = ${u0 + (kIndex - 1) * rReason} et S = ${kIndex * uk}",
                "u_$kIndex = ${u0 * rReason} et S = ${sumVal + rReason}",
                "u_$kIndex = $sumVal et S = $uk"
            ),
            correctIndices = listOf(0),
            structuredRubricStepsAr = listOf(
                "1) عبارة الحد العام لمتتالية حسابية: u_n = u₀ + n·r = $u0 + ${rReason}n.",
                "2) حساب الحد المطلوب: u_$kIndex = $u0 + $kIndex × $rReason = $uk.",
                "3) عدد الحدود من u₀ إلى u_$kIndex هو ($kIndex - 0 + 1) = $sumCount حداً.",
                "4) حساب المجموع: S = ($sumCount / 2) × (u₀ + u_$kIndex) = ($sumCount × ${u0 + uk}) / 2 = $sumVal."
            ),
            explanationAr = "الحد العام هو u_n = u₀ + n·r ومنه u_$kIndex = $u0 + $kIndex×$rReason = $uk. وعدد الحدود في المجموع S هو $sumCount حداً، إذن S = $sumCount × ($u0 + $uk) / 2 = $sumVal.",
            explanationFr = "u_$kIndex = u₀ + $kIndex·r = $uk et la somme de $sumCount termes vaut S = $sumCount × ($u0 + $uk) / 2 = $sumVal."
        )
    }

    private fun generateMathIntegralsQuestion(
        qId: String,
        lesson: Lesson,
        n: Int,
        difficulty: DifficultyLevel,
        mapAr: String,
        mapFr: String,
        srcAr: String,
        srcFr: String
    ): Question {
        val aCoeff = 2 * (1 + (n % 4)) // 2, 4, 6, 8
        val bTerm = 1 + (n % 5)
        val upperBound = 2 + (n % 3) // 2, 3, 4
        // Integral of (aCoeff * x + bTerm) from 0 to upperBound = [ (aCoeff/2) x^2 + bTerm x ]_0^upperBound
        val integralVal = (aCoeff / 2) * upperBound * upperBound + bTerm * upperBound
        val avgVal = String.format(Locale.US, "%.2f", integralVal.toDouble() / upperBound)

        return Question(
            id = qId,
            subjectId = lesson.subjectId,
            lessonId = lesson.id,
            streams = listOf(AcademicStream.SCIENCES_EXP, AcademicStream.MATH, AcademicStream.TECH_MATH, AcademicStream.GESTION_ECO),
            type = QuestionType.SINGLE_CHOICE,
            difficulty = difficulty,
            provenance = QuestionProvenance.CURRICULUM_VERIFIED,
            sourceCitationAr = srcAr,
            sourceCitationFr = srcFr,
            curriculumMappingAr = mapAr,
            curriculumMappingFr = mapFr,
            stemAr = "لتكن الدالة f المعرفة على المجال [0, $upperBound] بـ: f(x) = ${aCoeff}x + $bTerm. ما هي قيمة التكامل I = ∫(0→$upperBound) f(x) dx وما هي القيمة المتوسطة μ للدالة f على المجال [0, $upperBound]؟",
            stemFr = "Soit f(x) = ${aCoeff}x + $bTerm sur [0, $upperBound]. Quelles sont les valeurs de l'intégrale I = ∫(0→$upperBound) f(x) dx et de la valeur moyenne μ sur [0, $upperBound] ?",
            optionsAr = listOf(
                "التكامل I = $integralVal والقيمة المتوسطة μ = $avgVal",
                "التكامل I = ${integralVal * 2} والقيمة المتوسطة μ = $integralVal",
                "التكامل I = ${aCoeff * upperBound + bTerm} والقيمة المتوسطة μ = $aCoeff",
                "التكامل I = $bTerm والقيمة المتوسطة μ = 0"
            ),
            optionsFr = listOf(
                "I = $integralVal et valeur moyenne μ = $avgVal",
                "I = ${integralVal * 2} et μ = $integralVal",
                "I = ${aCoeff * upperBound + bTerm} et μ = $aCoeff",
                "I = $bTerm et μ = 0"
            ),
            correctIndices = listOf(0),
            explanationAr = "دالة أصلية لـ f(x) = ${aCoeff}x + $bTerm هي F(x) = ${aCoeff / 2}x² + ${bTerm}x. ومنه I = F($upperBound) - F(0) = ${aCoeff / 2}($upperBound)² + $bTerm($upperBound) = $integralVal. والقيمة المتوسطة μ = I / ($upperBound - 0) = $integralVal / $upperBound = $avgVal.",
            explanationFr = "Une primitive est F(x) = ${aCoeff / 2}x² + ${bTerm}x, d'où I = F($upperBound) - F(0) = $integralVal et μ = I/$upperBound = $avgVal."
        )
    }

    private fun generateMathArithmeticZQuestion(
        qId: String,
        lesson: Lesson,
        n: Int,
        difficulty: DifficultyLevel,
        mapAr: String,
        mapFr: String,
        srcAr: String,
        srcFr: String
    ): Question {
        val modN = 5 + (n % 6) // 5..10
        val kMult = 3 + (n % 5)
        val rem = n % modN
        val numberA = kMult * modN + rem

        return Question(
            id = qId,
            subjectId = lesson.subjectId,
            lessonId = lesson.id,
            streams = listOf(AcademicStream.MATH, AcademicStream.TECH_MATH),
            type = QuestionType.SINGLE_CHOICE,
            difficulty = difficulty,
            provenance = QuestionProvenance.CURRICULUM_VERIFIED,
            sourceCitationAr = srcAr,
            sourceCitationFr = srcFr,
            curriculumMappingAr = mapAr,
            curriculumMappingFr = mapFr,
            stemAr = "في الحساب في Z: ما هو باقي القسمة الإقليدية للعدد الطبيعي A = $numberA على العدد $modN، وما هو باقي قسمة العدد A² على $modN؟",
            stemFr = "En arithmétique dans Z : quel est le reste de la division euclidienne de A = $numberA par $modN, ainsi que le reste de A² modulo $modN ?",
            optionsAr = listOf(
                "باقي قسمة A على $modN هو r = $rem، وباقي قسمة A² على $modN هو ${(rem * rem) % modN}",
                "باقي قسمة A على $modN هو r = $kMult، وباقي قسمة A² على $modN هو $modN",
                "باقي قسمة A على $modN هو r = ${rem + 1}، وباقي قسمة A² على $modN هو 0",
                "العدد A لا يقبل القسمة الإقليدية في Z"
            ),
            optionsFr = listOf(
                "Le reste de A par $modN est r = $rem, et le reste de A² par $modN est ${(rem * rem) % modN}",
                "Le reste de A par $modN est r = $kMult et pour A² est $modN",
                "Le reste de A par $modN est r = ${rem + 1} et pour A² est 0",
                "Division impossible dans Z"
            ),
            correctIndices = listOf(0),
            explanationAr = "لدينا المساواة الإقليدية: $numberA = $modN × $kMult + $rem مع 0 ≤ $rem < $modN، إذن A ≡ $rem [$modN]. وبانسجام الموافقات مع القوى نجد A² ≡ $rem² ≡ ${rem * rem} ≡ ${(rem * rem) % modN} [$modN].",
            explanationFr = "On a $numberA = $modN × $kMult + $rem avec 0 ≤ $rem < $modN, donc A ≡ $rem [$modN] et A² ≡ ${(rem * rem) % modN} [$modN]."
        )
    }

    private fun generateMathProbabilitiesQuestion(
        qId: String,
        lesson: Lesson,
        n: Int,
        difficulty: DifficultyLevel,
        mapAr: String,
        mapFr: String,
        srcAr: String,
        srcFr: String
    ): Question {
        val whiteBalls = 3 + (n % 4) // 3..6
        val redBalls = 2 + (n % 3)   // 2..4
        val totalBalls = whiteBalls + redBalls
        val totalPairs = (totalBalls * (totalBalls - 1)) / 2
        val whitePairs = (whiteBalls * (whiteBalls - 1)) / 2

        return Question(
            id = qId,
            subjectId = lesson.subjectId,
            lessonId = lesson.id,
            streams = AcademicStream.entries,
            type = QuestionType.SINGLE_CHOICE,
            difficulty = difficulty,
            provenance = QuestionProvenance.CURRICULUM_VERIFIED,
            sourceCitationAr = srcAr,
            sourceCitationFr = srcFr,
            curriculumMappingAr = mapAr,
            curriculumMappingFr = mapFr,
            stemAr = "يحتوي كيس على $whiteBalls كرات بيضاء و $redBalls كرات حمراء لا نفرق بينها عند اللمس (المجموع $totalBalls كرات). نسحب عشوائياً وفي آن واحد كرتين من الكيس. ما هو عدد الحالات الممكنة الكلية C($totalBalls, 2) واحتمال سحب كرتين بيضاوين معاً؟",
            stemFr = "Une urne contient $whiteBalls boules blanches et $redBalls boules rouges ($totalBalls au total). On tire simultanément 2 boules. Quel est le nombre de cas possibles C($totalBalls, 2) et la probabilité d'obtenir 2 boules blanches ?",
            optionsAr = listOf(
                "عدد الحالات الممكنة هو $totalPairs واحتمال سحب كرتين بيضاوين هو P = $whitePairs / $totalPairs",
                "عدد الحالات الممكنة هو ${totalBalls * totalBalls} واحتمال سحب كرتين بيضاوين هو P = $whiteBalls / $totalBalls",
                "عدد الحالات الممكنة هو ${totalBalls * 2} واحتمال سحب كرتين بيضاوين هو P = 1 / 2",
                "عدد الحالات الممكنة هو $whitePairs واحتمال سحب كرتين بيضاوين هو P = 1"
            ),
            optionsFr = listOf(
                "$totalPairs cas possibles et probabilité P = $whitePairs / $totalPairs",
                "${totalBalls * totalBalls} cas possibles et P = $whiteBalls / $totalBalls",
                "${totalBalls * 2} cas possibles et P = 1 / 2",
                "$whitePairs cas possibles et P = 1"
            ),
            correctIndices = listOf(0),
            explanationAr = "بما أن السحب يتم في آن واحد، نوظف التوفيقات: عدد الحالات الممكنة هو C($totalBalls, 2) = ($totalBalls × ${totalBalls - 1}) / 2 = $totalPairs. وعدد حالات سحب كرتين بيضاوين هو C($whiteBalls, 2) = $whitePairs، ومنه الاحتمال P = $whitePairs / $totalPairs.",
            explanationFr = "Le tirage étant simultané, on utilise les combinaisons : C($totalBalls, 2) = $totalPairs cas possibles et C($whiteBalls, 2) = $whitePairs cas favorables, d'où P = $whitePairs / $totalPairs."
        )
    }

    private fun generateMathComplexSpaceQuestion(
        qId: String,
        lesson: Lesson,
        n: Int,
        difficulty: DifficultyLevel,
        mapAr: String,
        mapFr: String,
        srcAr: String,
        srcFr: String
    ): Question {
        val radiusK = 1 + (n % 5)
        val modVal = radiusK * 2
        return Question(
            id = qId,
            subjectId = lesson.subjectId,
            lessonId = lesson.id,
            streams = listOf(AcademicStream.SCIENCES_EXP, AcademicStream.MATH, AcademicStream.TECH_MATH),
            type = QuestionType.SINGLE_CHOICE,
            difficulty = difficulty,
            provenance = QuestionProvenance.CURRICULUM_VERIFIED,
            sourceCitationAr = srcAr,
            sourceCitationFr = srcFr,
            curriculumMappingAr = mapAr,
            curriculumMappingFr = mapFr,
            stemAr = "نعتبر العدد المركب z = ${radiusK}√3 + ${radiusK}i. ما هي طويلته |z| وعمدته الرئيسية arg(z) وشكله الأسي؟",
            stemFr = "Soit le nombre complexe z = ${radiusK}√3 + ${radiusK}i. Quels sont son module |z|, son argument principal arg(z) et sa forme exponentielle ?",
            optionsAr = listOf(
                "الطويلة |z| = $modVal والعمدة θ = π/6 والشكل الأسي z = $modVal · e^(iπ/6)",
                "الطويلة |z| = $radiusK والعمدة θ = π/3 والشكل الأسي z = $radiusK · e^(iπ/3)",
                "الطويلة |z| = ${modVal * 2} والعمدة θ = π/4 والشكل الأسي z = ${modVal * 2} · e^(iπ/4)",
                "الطويلة |z| = $modVal والعمدة θ = -π/6 والشكل الأسي z = $modVal · e^(-iπ/6)"
            ),
            optionsFr = listOf(
                "Module |z| = $modVal, argument θ = π/6 et forme exponentielle z = $modVal · e^(iπ/6)",
                "Module |z| = $radiusK, argument θ = π/3 et z = $radiusK · e^(iπ/3)",
                "Module |z| = ${modVal * 2}, argument θ = π/4",
                "Module |z| = $modVal, argument θ = -π/6"
            ),
            correctIndices = listOf(0),
            explanationAr = "لدينا |z| = √((${radiusK}√3)² + ($radiusK)²) = √(${3 * radiusK * radiusK} + ${radiusK * radiusK}) = √(${4 * radiusK * radiusK}) = $modVal. ولدينا cos θ = √3/2 و sin θ = 1/2 ومنه θ = π/6، إذن z = $modVal · e^(iπ/6).",
            explanationFr = "On calcule |z| = √(3×$radiusK² + $radiusK²) = $modVal, puis cos θ = √3/2 et sin θ = 1/2 soit θ = π/6, d'où z = $modVal · e^(iπ/6)."
        )
    }

    // -------------------------------------------------------------------------
    // PHILOSOPHY, ISLAMIC SCIENCES, HISTORY & GEOGRAPHY Generators
    // -------------------------------------------------------------------------

    private fun generatePhiloQuestion(
        qId: String,
        lesson: Lesson,
        n: Int,
        difficulty: DifficultyLevel,
        mapAr: String,
        mapFr: String,
        srcAr: String,
        srcFr: String
    ): Question {
        val variant = n % 3
        return Question(
            id = qId,
            subjectId = lesson.subjectId,
            lessonId = lesson.id,
            streams = AcademicStream.entries,
            type = QuestionType.SINGLE_CHOICE,
            difficulty = difficulty,
            provenance = QuestionProvenance.CURRICULUM_VERIFIED,
            sourceCitationAr = srcAr,
            sourceCitationFr = srcFr,
            curriculumMappingAr = mapAr,
            curriculumMappingFr = mapFr,
            stemAr = when (variant) {
                0 -> "في التدريب المنهجي رقم $n لبناء المقال الفلسفي: ما هي الخطوات الأساسية لقسم «محاولة حل المشكلة» في الطريقة الجدلية وفق سلم التنقيط الرسمي (12 نقطة)؟"
                1 -> "في التدريب الفلسفي رقم $n حول فلسفة العلوم: ما هو معيار التمييز بين «المشكلة العلمية» و«الإشكالية الفلسفية» في طريقة المقارنة؟"
                else -> "في التدريب الفلسفي رقم $n حول المنهج التجريبي (كلود برنارد): ما هي خطوات الاستقراء التجريبي بالترتيب المنهجي؟"
            },
            stemFr = when (variant) {
                0 -> "Entraînement méthodologique n°$n : Quelles sont les étapes du développement (12 pts) dans la méthode dialectique ?"
                1 -> "Entraînement n°$n : Quelle distinction fondamentale existe entre le problème scientifique et la problématique philosophique ?"
                else -> "Entraînement n°$n : Quelles sont les étapes de la méthode expérimentale selon Claude Bernard ?"
            },
            optionsAr = when (variant) {
                0 -> listOf(
                    "عرض منطق الأطروحة الأولى وحججها ونقدها (4 ن) ← عرض نقيض الأطروحة وحججه ونقده (4 ن) ← التركيب أو التجاوز (4 ن)",
                    "عرض أنصار الأطروحة فقط دون ذكر الخصوم أو النقد",
                    "البدء بأوجه التشابه ثم أوجه الاختلاف فقط",
                    "تلخيص النص الفلسفي دون أمثلة أو أقوال فلاسفة"
                )
                1 -> listOf(
                    "المشكلة العلمية جزئية حسية تقبل الحل النهائي القابل للتحقق التجريبي، بينما الإشكالية الفلسفية شمولية عقلية تبقى مفتوحة للتأمل",
                    "المشكلة العلمية والإشكالية الفلسفية متطابقتان تماماً في الموضوع والمنهج",
                    "الإشكالية الفلسفية تدرس الظواهر الفيزيائية بالملاحظة المخبرية فقط",
                    "المشكلة العلمية لا تحتاج إلى فرضيات أو قوانين"
                )
                else -> listOf(
                    "الملاحظة العلمية ← صياغة الفرضية العقلية ← التجربة المخبرية للتحقق ← صياغة القانون العلمي",
                    "القانون العلمي ← الملاحظة العفوية ← الاستغناء عن التجربة",
                    "التجربة أولاً دون ملاحظة أو فرضية",
                    "البرهان الرياضي الصوري المجرد من الواقع الحسي"
                )
            },
            optionsFr = when (variant) {
                0 -> listOf(
                    "Thèse + arguments + critique (4 pts) → Antithèse + arguments + critique (4 pts) → Synthèse / Dépassement (4 pts)",
                    "Exposition de la thèse sans critique ni antithèse",
                    "Ressemblances et différences uniquement",
                    "Résumé littéral sans argumentation"
                )
                1 -> listOf(
                    "Le problème scientifique est particulier et vérifiable expérimentalement, tandis que la problématique philosophique est globale et réflexive",
                    "Ils sont strictement identiques",
                    "La philosophie utilise uniquement le laboratoire",
                    "La science rejette toute loi générale"
                )
                else -> listOf(
                    "Observation → Hypothèse → Expérimentation → Loi scientifique",
                    "Loi → Observation naïve sans expérience",
                    "Expérience aveugle sans hypothèse",
                    "Déduction purement formelle"
                )
            },
            correctIndices = listOf(0),
            explanationAr = "يحاسب المصحح في البكالوريا بدقة على التزام المترشح بخطوات المنهجية المناسبة لصيغة السؤال مع توظيف الحجج والأمثلة وأقوال الفلاسفة وسلامة اللغة.",
            explanationFr = "Le barème officiel du Baccalauréat évalue la rigueur méthodologique, la pertinence des arguments et les références philosophiques."
        )
    }

    private fun generateIslamicQuestion(
        qId: String,
        lesson: Lesson,
        n: Int,
        difficulty: DifficultyLevel,
        mapAr: String,
        mapFr: String,
        srcAr: String,
        srcFr: String
    ): Question {
        val variant = n % 3
        return Question(
            id = qId,
            subjectId = lesson.subjectId,
            lessonId = lesson.id,
            streams = AcademicStream.entries,
            type = QuestionType.SINGLE_CHOICE,
            difficulty = difficulty,
            provenance = QuestionProvenance.CURRICULUM_VERIFIED,
            sourceCitationAr = srcAr,
            sourceCitationFr = srcFr,
            curriculumMappingAr = mapAr,
            curriculumMappingFr = mapFr,
            stemAr = when (variant) {
                0 -> "في التطبيق الفقهي رقم $n من وحدة مصادر التشريع الإسلامي: ما هو تعريف «المصالح المرسلة» وما هو شرط العمل بها؟"
                1 -> "في التطبيق رقم $n من وحدة مقاصد الشريعة الإسلامية: إلى أي قسم من المقاصد ينتمي تشريع الرخص الشرعية (كالفطر للمريض والمسافر في رمضان)؟"
                else -> "في التطبيق رقم $n من وحدة القياس: ما هي أركان القياس الأربعة في أصول الفقه الإسلامي؟"
            },
            stemFr = when (variant) {
                0 -> "Application n°$n (Sources législatives) : Qu'est-ce que l'intérêt général non textuel (Al-Masalih Al-Mursala) et ses conditions ?"
                1 -> "Application n°$n (Maqasid) : À quelle catégorie appartiennent les dispenses légales (Rukhas) ?"
                else -> "Application n°$n (Al-Qiyas) : Quels sont les quatre piliers du raisonnement par analogie (Qiyas) ?"
            },
            optionsAr = when (variant) {
                0 -> listOf(
                    "هي جلب منفعة أو دفع مضرة لم يشهد لها الشرع باعتبار ولا بإلغاء، ويشترط أن تكون مصلحة عامة وحقيقية وملائمة لمقاصد الشريعة وفي المعاملات دون العبادات",
                    "هي مخالفة النصوص القطعية في العقائد والعبادات",
                    "هي العمل بالمصلحة الوهمية الخاصة بالفرد وحده",
                    "هي نسخ القرآن الكريم بالإجماع السكوتي"
                )
                1 -> listOf(
                    "المقاصد الحاجية (الحاجيات) لأنها ترفع الحرج والمشقة عن المكلفين دون أن يصل فواتها إلى الهلاك",
                    "المقاصد التحسينية (الكماليات) فقط",
                    "إلغاء التكليف الشرعي نهائياً",
                    "باب المعاملات المالية الربوية"
                )
                else -> listOf(
                    "الأصل (المقيس عليه)، الفرع (المقيس)، حكم الأصل، والعلة المشتركة الجامعة بينهما",
                    "الإجماع الصريح والإجماع السكوتي فقط",
                    "الناسخ والمنسوخ في العهد المكي",
                    "العرف الفاسد والعرف الصحيح"
                )
            },
            optionsFr = when (variant) {
                0 -> listOf(
                    "Utilité générale conforme aux finalités de la Charia sans texte spécifique d'admission ni d'annulation, applicable aux transactions (Mu'amalat)",
                    "Modification des actes d'adoration (Ibadat)",
                    "Intérêt purement individuel et illusoire",
                    "Abrogation d'un texte coranique explicite"
                )
                1 -> listOf(
                    "Les besoins (Al-Hajiyyat), visant à lever la gêne et la difficulté excessive",
                    "Les améliorations esthétiques uniquement",
                    "Suppression définitive des obligations",
                    "Transactions financières"
                )
                else -> listOf(
                    "Le cas originel (Asl), le cas nouveau (Far'), le statut juridique (Hukm) et la cause commune ('Illa)",
                    "Le consensus explicite et tacite",
                    "L'abrogeant et l'abrogé",
                    "La coutume locale"
                )
            },
            correctIndices = listOf(0),
            explanationAr = "تبرز مرونة الشريعة الإسلامية في تعدد مصادرها التبعية (الإجماع، القياس، المصالح المرسلة) ومراعاتها لمراتب المقاصد (الضروريات، الحاجيات، التحسينيات) لرفع الحرج وحفظ مصالح العباد.",
            explanationFr = "Les sources législatives secondaires (Ijma, Qiyas, Masalih Mursala) et les Maqasid assurent l'adaptabilité de la législation islamique."
        )
    }

    private fun generateHistoryQuestion(
        qId: String,
        lesson: Lesson,
        n: Int,
        difficulty: DifficultyLevel,
        mapAr: String,
        mapFr: String,
        srcAr: String,
        srcFr: String
    ): Question {
        val variant = n % 3
        return Question(
            id = qId,
            subjectId = lesson.subjectId,
            lessonId = lesson.id,
            streams = AcademicStream.entries,
            type = QuestionType.SINGLE_CHOICE,
            difficulty = difficulty,
            provenance = QuestionProvenance.CURRICULUM_VERIFIED,
            sourceCitationAr = srcAr,
            sourceCitationFr = srcFr,
            curriculumMappingAr = mapAr,
            curriculumMappingFr = mapFr,
            stemAr = when (variant) {
                0 -> "في المحطة التاريخية رقم $n من وحدة الثورة التحريرية: ما هي الأهمية الاستراتيجية لهجومات الشمال القسنطيني (20 أوت 1955) بقيادة الشهيد زيغود يوسف؟"
                1 -> "في المحطة التاريخية رقم $n: ما هو الهدف الحقيقي من طرح الإدارة الاستعمارية الفرنسية لـ «مشروع قسنطينة» في 3 أكتوبر 1958؟"
                else -> "في المحطة التاريخية رقم $n: متى تأسست الحكومة المؤقتة للجمهورية الجزائرية (GPRA) وما هو دورها الدبلوماسي؟"
            },
            stemFr = when (variant) {
                0 -> "Repère historique n°$n : Quelle fut la portée stratégique des offensives du Nord-Constantinois (20 août 1955) dirigées par Zighoud Youcef ?"
                1 -> "Repère n°$n : Quel était l'objectif réel du « Plan de Constantine » annoncé le 3 octobre 1958 ?"
                else -> "Repère n°$n : Quand fut proclamé le Gouvernement Provisoire de la République Algérienne (GPRA) et quel fut son rôle ?"
            },
            optionsAr = when (variant) {
                0 -> listOf(
                    "فك الحصار العسكري عن منطقة الأوراس، تأكيد شمولية الثورة وشعبيتها، وتدويل القضية الجزائرية في الدورة العاشرة للجمعية العامة للأمم المتحدة",
                    "توقيع اتفاقيات إيفيان الأولى بمدينة إيفيان السويسرية",
                    "إنشاء خطي شال وموريس المكهربين على الحدود",
                    "إعلان استقلال الجزائر رسمياً في 5 جويلية 1962"
                )
                1 -> listOf(
                    "مشروع إغرائي استعماري يهدف إلى عزل الشعب الجزائري عن جبهة التحرير الوطني وإفراغ الثورة من محتواها عبر إصلاحات اقتصادية واجتماعية شكلية",
                    "منح الجزائر استقلالها التام والاعتراف بسيادتها على الصحراء",
                    "تفكيك المستوطنات العسكرية الفرنسية في الجزائر",
                    "دعم جيش التحرير الوطني بالسلاح والعتاد"
                )
                else -> listOf(
                    "تأسست في 19 سبتمبر 1958 بالقاهرة برئاسة فرحات عباس لتمثيل الدولة الجزائرية دبلوماسياً وقيادة المفاوضات مع فرنسا",
                    "تأسست في 1 نوفمبر 1954 بمدينة باتنة",
                    "تأسست في 5 جويلية 1962 بعد استفتاء تقرير المصير",
                    "تأسست في 8 ماي 1945 بسطيف وقالمة وخراطة"
                )
            },
            optionsFr = when (variant) {
                0 -> listOf(
                    "Desserrer l'étau sur les Aurès, affirmer le caractère populaire de la Révolution et internationaliser la question algérienne à l'ONU",
                    "Signer les Accords d'Évian",
                    "Construire les lignes Challe et Morice",
                    "Proclamer l'indépendance en 1962"
                )
                1 -> listOf(
                    "Manœuvre néocoloniale visant à isoler le peuple du FLN par des promesses socio-économiques et créer une troisième force",
                    "Reconnaître immédiatement l'indépendance totale de l'Algérie",
                    "Soutenir l'ALN",
                    "Supprimer l'armée coloniale"
                )
                else -> listOf(
                    "Proclamé le 19 septembre 1958 au Caire sous la présidence de Ferhat Abbas pour représenter diplomatiquement l'Algérie et mener les négociations",
                    "Créé le 1er novembre 1954",
                    "Créé le 5 juillet 1962",
                    "Créé le 8 mai 1945"
                )
            },
            correctIndices = listOf(0),
            explanationAr = "محطات الثورة التحريرية الكبرى (1 نوفمبر 1954، هجومات 20 أوت 1955، مؤتمر الصومام 20 أوت 1956، تأسيس الحكومة المؤقتة 19 سبتمبر 1958، ومفاوضات إيفيان 1962) تكامل فيها العمل المسلح مع النشاط السياسي والدبلوماسي لإفشال المخططات الاستعمارية.",
            explanationFr = "La Révolution algérienne a articulé lutte armée à l'intérieur et action diplomatique (ONU, GPRA) pour mettre en échec les plans coloniaux."
        )
    }
}
