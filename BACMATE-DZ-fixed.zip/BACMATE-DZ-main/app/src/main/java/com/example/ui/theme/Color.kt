package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Neo-Maghreb Academic Editorial Palette
val EmeraldPrimaryLight = Color(0xFF064E3B)
val EmeraldOnPrimaryLight = Color(0xFFFFFFFF)
val EmeraldPrimaryContainerLight = Color(0xFFD1FAE5)
val EmeraldOnPrimaryContainerLight = Color(0xFF022C22)

val GoldSecondaryLight = Color(0xFFB45309)
val GoldOnSecondaryLight = Color(0xFFFFFFFF)
val GoldSecondaryContainerLight = Color(0xFFFEF3C7)
val GoldOnSecondaryContainerLight = Color(0xFF451A03)

val IndigoTertiaryLight = Color(0xFF1E3A8A)
val IndigoOnTertiaryLight = Color(0xFFFFFFFF)
val IndigoTertiaryContainerLight = Color(0xFFDBEAFE)
val IndigoOnTertiaryContainerLight = Color(0xFF172554)

val BackgroundLight = Color(0xFFFAF8F5)
val OnBackgroundLight = Color(0xFF0F172A)
val SurfaceLight = Color(0xFFFFFFFF)
val OnSurfaceLight = Color(0xFF0F172A)
val SurfaceVariantLight = Color(0xFFF1ECE1)
val OnSurfaceVariantLight = Color(0xFF475569)
val OutlineLight = Color(0xFFCBD5E1)

// Dark Theme Palette (Obsidian Emerald Slate)
val EmeraldPrimaryDark = Color(0xFF10B981)
val EmeraldOnPrimaryDark = Color(0xFF022C22)
val EmeraldPrimaryContainerDark = Color(0xFF064E3B)
val EmeraldOnPrimaryContainerDark = Color(0xFFD1FAE5)

val GoldSecondaryDark = Color(0xFFF59E0B)
val GoldOnSecondaryDark = Color(0xFF451A03)
val GoldSecondaryContainerDark = Color(0xFF78350F)
val GoldOnSecondaryContainerDark = Color(0xFFFEF3C7)

val IndigoTertiaryDark = Color(0xFF60A5FA)
val IndigoOnTertiaryDark = Color(0xFF172554)
val IndigoTertiaryContainerDark = Color(0xFF1E3A8A)
val IndigoOnTertiaryContainerDark = Color(0xFFDBEAFE)

val BackgroundDark = Color(0xFF091411)
val OnBackgroundDark = Color(0xFFF8FAFC)
val SurfaceDark = Color(0xFF11221D)
val OnSurfaceDark = Color(0xFFF8FAFC)
val SurfaceVariantDark = Color(0xFF1A332B)
val OnSurfaceVariantDark = Color(0xFF94A3B8)
val OutlineDark = Color(0xFF2D4F44)

// Semantic Accents
val BacGoldAccent = Color(0xFFD4AF37)
val BacCoralError = Color(0xFFE11D48)
val BacMintSuccess = Color(0xFF059669)
val BacAmberWarning = Color(0xFFD97706)
