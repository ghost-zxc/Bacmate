package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.firebase.OperationType
import com.example.data.firebase.handleFirestoreError
import com.example.data.model.AcademicStream
import com.example.data.model.AppLanguage
import com.example.data.model.CommunityQuestion
import com.example.data.model.QuizAttempt
import com.example.data.model.ReviewItem
import com.example.data.model.StudyTask
import com.example.data.model.SubscriptionTier
import com.example.data.model.UserProfile
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import java.time.LocalDate
import java.util.UUID
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class BacMateRepository(
    private val db: FirebaseFirestore? = null,
    private val auth: FirebaseAuth? = runCatching { Firebase.auth }.getOrNull()
) {
    constructor(context: Context) : this(
        runCatching {
            FirebaseFirestore.getInstance(
                context.applicationContext.getString(R.string.firestore_database_id)
            )
        }.getOrNull(),
        runCatching { Firebase.auth }.getOrNull()
    )

    private val localProfiles = mutableMapOf<String, UserProfile>()
    private val localAttempts = mutableListOf<QuizAttempt>()
    private val localReviews = mutableListOf<ReviewItem>()
    private val localStudyTasks = mutableListOf<StudyTask>()
    private val localCommunity = mutableListOf<CommunityQuestion>()

    private fun requireUserId(): String {
        return auth?.currentUser?.uid ?: "guest_student_dz"
    }

    // -----------------------------------------------------------------------
    // 1. UserProfile Operations (/users/{userId})
    // -----------------------------------------------------------------------

    fun observeUserProfile(userId: String): Flow<UserProfile?> {
        val docRef = db.collection("users").document(userId)
        return docRef.snapshots()
            .map { snapshot ->
                if (snapshot.exists()) {
                    snapshot.toObject(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                } else {
                    null
                }
            }
            .catch { error ->
                if (error is Exception) handleFirestoreError(error, OperationType.GET, docRef.path)
                throw error
            }
    }

    suspend fun getUserProfileById(userId: String): Result<UserProfile?> {
        val docRef = db.collection("users").document(userId)
        return try {
            val snap = docRef.get().await()
            Result.success(
                if (snap.exists()) {
                    snap.toObject(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                } else {
                    null
                }
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun createInitialProfile(
        displayName: String,
        examYear: Int = 2026,
        stream: AcademicStream = AcademicStream.SCIENCES_EXP,
        language: AppLanguage = AppLanguage.AR,
        dailyGoalMinutes: Int = 60
    ): Result<String> {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid)
        val todayStr = LocalDate.now().toString()
        val payload = mapOf(
            "userId" to uid,
            "displayName" to displayName.trim().ifBlank { "طالب البكالوريا" }.take(80),
            "examYear" to examYear.coerceIn(2025, 2035),
            "academicStream" to stream.id,
            "language" to language.code,
            "dailyGoalMinutes" to dailyGoalMinutes.coerceIn(10, 360),
            "studyMinutesToday" to 0,
            "streakDays" to 1,
            "totalQuizzesCompleted" to 0,
            "totalQuestionsAnswered" to 0,
            "totalCorrectAnswers" to 0,
            "dailyQuizzesUsedToday" to 0,
            "dailyAiRequestsUsedToday" to 0,
            "lastActiveDate" to todayStr,
            "subscriptionTier" to SubscriptionTier.FREE.id,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        return try {
            val existingSnap = docRef.get().await()
            val finalPayload = if (existingSnap.exists()) {
                val existingCreatedAt = existingSnap.getTimestamp("createdAt") ?: FieldValue.serverTimestamp()
                payload + ("createdAt" to existingCreatedAt)
            } else {
                payload
            }
            docRef.set(finalPayload).await()
            Result.success(uid)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun updateProfilePreferences(
        existingProfile: UserProfile,
        displayName: String = existingProfile.displayName,
        examYear: Int = existingProfile.examYear,
        stream: AcademicStream = AcademicStream.fromId(existingProfile.academicStream),
        language: AppLanguage = AppLanguage.fromCode(existingProfile.language),
        dailyGoalMinutes: Int = existingProfile.dailyGoalMinutes,
        subscriptionTier: SubscriptionTier = SubscriptionTier.fromId(existingProfile.subscriptionTier)
    ): Result<Unit> {
        val uid = requireUserId()
        requireNotNull(existingProfile.createdAt) { "Profile createdAt must not be null for update" }
        val docRef = db.collection("users").document(uid)
        val updated = existingProfile.copy(
            userId = uid,
            displayName = displayName.trim().ifBlank { "طالب البكالوريا" }.take(80),
            examYear = examYear.coerceIn(2025, 2035),
            academicStream = stream.id,
            language = language.code,
            dailyGoalMinutes = dailyGoalMinutes.coerceIn(10, 360),
            subscriptionTier = subscriptionTier.id,
            updatedAt = null
        )
        return try {
            docRef.set(updated).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun incrementAiRequestUsage(existingProfile: UserProfile): Result<Unit> {
        val uid = requireUserId()
        requireNotNull(existingProfile.createdAt) { "Profile createdAt must not be null for update" }
        val docRef = db.collection("users").document(uid)
        val todayStr = LocalDate.now().toString()
        val aiCount = if (existingProfile.lastActiveDate == todayStr) {
            existingProfile.dailyAiRequestsUsedToday + 1
        } else {
            1
        }
        val updated = existingProfile.copy(
            userId = uid,
            dailyAiRequestsUsedToday = aiCount.coerceAtMost(1000),
            lastActiveDate = todayStr,
            updatedAt = null
        )
        return try {
            docRef.set(updated).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    // -----------------------------------------------------------------------
    // 2. QuizAttempt Operations (/users/{userId}/attempts/{attemptId})
    // -----------------------------------------------------------------------

    fun observeQuizAttempts(userId: String): Flow<List<QuizAttempt>> {
        val colRef = db.collection("users").document(userId).collection("attempts")
        return colRef.snapshots()
            .map { snapshot ->
                snapshot.toObjects(QuizAttempt::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
            .catch { error ->
                if (error is Exception) handleFirestoreError(error, OperationType.LIST, colRef.path)
                throw error
            }
    }

    suspend fun recordQuizAttempt(
        subjectId: String,
        lessonId: String,
        mode: String,
        totalQuestions: Int,
        correctCount: Int,
        durationSeconds: Int,
        existingProfile: UserProfile? = null
    ): Result<String> {
        val uid = requireUserId()
        val attemptId = "att_${UUID.randomUUID().toString().replace("-", "").take(20)}"
        val docRef = db.collection("users").document(uid).collection("attempts").document(attemptId)

        val safeTotal = totalQuestions.coerceIn(1, 100)
        val safeCorrect = correctCount.coerceIn(0, safeTotal)
        val scorePercent = ((safeCorrect * 100.0) / safeTotal).toInt().coerceIn(0, 100)
        val bacScoreTimes10 = ((safeCorrect * 200.0) / safeTotal).toInt().coerceIn(0, 200)

        val payload = mapOf(
            "userId" to uid,
            "subjectId" to subjectId.take(64),
            "lessonId" to lessonId.take(64),
            "mode" to mode,
            "scorePercent" to scorePercent,
            "bacScoreTimes10" to bacScoreTimes10,
            "totalQuestions" to safeTotal,
            "correctCount" to safeCorrect,
            "durationSeconds" to durationSeconds.coerceIn(0, 86400),
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )

        return try {
            docRef.set(payload).await()

            if (existingProfile != null && existingProfile.createdAt != null) {
                val todayStr = LocalDate.now().toString()
                val addedMinutes = (durationSeconds / 60).coerceAtLeast(3)
                val isSameDay = existingProfile.lastActiveDate == todayStr
                val newStreak = if (isSameDay) existingProfile.streakDays else existingProfile.streakDays + 1
                val newDailyQuizzes = if (isSameDay) existingProfile.dailyQuizzesUsedToday + 1 else 1
                val newMinutesToday = if (isSameDay) {
                    (existingProfile.studyMinutesToday + addedMinutes).coerceAtMost(1440)
                } else {
                    addedMinutes.coerceAtMost(1440)
                }

                val updatedProfile = existingProfile.copy(
                    userId = uid,
                    studyMinutesToday = newMinutesToday,
                    streakDays = newStreak.coerceAtMost(3650),
                    totalQuizzesCompleted = (existingProfile.totalQuizzesCompleted + 1).coerceAtMost(100000),
                    totalQuestionsAnswered = (existingProfile.totalQuestionsAnswered + safeTotal).coerceAtMost(1000000),
                    totalCorrectAnswers = (existingProfile.totalCorrectAnswers + safeCorrect).coerceAtMost(1000000),
                    dailyQuizzesUsedToday = newDailyQuizzes.coerceAtMost(1000),
                    lastActiveDate = todayStr,
                    updatedAt = null
                )
                db.collection("users").document(uid).set(updatedProfile).await()
            }
            Result.success(attemptId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    // -----------------------------------------------------------------------
    // 3. ReviewItem Operations (/users/{userId}/reviews/{reviewId})
    // -----------------------------------------------------------------------

    fun observeReviewItems(userId: String): Flow<List<ReviewItem>> {
        val colRef = db.collection("users").document(userId).collection("reviews")
        return colRef.snapshots()
            .map { snapshot ->
                snapshot.toObjects(ReviewItem::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedBy { it.nextReviewEpochDay }
            }
            .catch { error ->
                if (error is Exception) handleFirestoreError(error, OperationType.LIST, colRef.path)
                throw error
            }
    }

    suspend fun saveReviewItem(reviewItem: ReviewItem): Result<String> {
        val uid = requireUserId()
        val reviewId = reviewItem.questionId.ifBlank { reviewItem.id }
        require(reviewId.isNotBlank()) { "Review questionId must not be blank" }
        val docRef = db.collection("users").document(uid).collection("reviews").document(reviewId)

        return try {
            if (reviewItem.createdAt != null) {
                val updated = reviewItem.copy(
                    userId = uid,
                    questionId = reviewId,
                    personalNote = reviewItem.personalNote.take(500),
                    updatedAt = null
                )
                docRef.set(updated).await()
            } else {
                val payload = mapOf(
                    "userId" to uid,
                    "questionId" to reviewId.take(64),
                    "subjectId" to reviewItem.subjectId.take(64),
                    "lessonId" to reviewItem.lessonId.take(64),
                    "mistakeCount" to reviewItem.mistakeCount.coerceIn(0, 10000),
                    "repetitionCount" to reviewItem.repetitionCount.coerceIn(0, 10000),
                    "intervalDays" to reviewItem.intervalDays.coerceIn(0, 3650),
                    "easeFactorPermille" to reviewItem.easeFactorPermille.coerceIn(1300, 3500),
                    "nextReviewEpochDay" to reviewItem.nextReviewEpochDay.coerceIn(0, 100000),
                    "personalNote" to reviewItem.personalNote.take(500),
                    "mastered" to reviewItem.mastered,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.set(payload).await()
            }
            Result.success(reviewId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            Result.failure(e)
        }
    }

    // -----------------------------------------------------------------------
    // 4. StudyTask Operations (/users/{userId}/studyTasks/{taskId})
    // -----------------------------------------------------------------------

    fun observeStudyTasks(userId: String): Flow<List<StudyTask>> {
        val colRef = db.collection("users").document(userId).collection("studyTasks")
        return colRef.snapshots()
            .map { snapshot ->
                snapshot.toObjects(StudyTask::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
            .catch { error ->
                if (error is Exception) handleFirestoreError(error, OperationType.LIST, colRef.path)
                throw error
            }
    }

    suspend fun createStudyTask(
        title: String,
        subjectId: String,
        dayOfWeek: String,
        durationMinutes: Int,
        priority: String
    ): Result<String> {
        val uid = requireUserId()
        val taskId = "task_${UUID.randomUUID().toString().replace("-", "").take(20)}"
        val docRef = db.collection("users").document(uid).collection("studyTasks").document(taskId)
        val payload = mapOf(
            "userId" to uid,
            "title" to title.trim().ifBlank { "مراجعة وحدة دراسية" }.take(150),
            "subjectId" to subjectId.take(64),
            "dayOfWeek" to dayOfWeek,
            "durationMinutes" to durationMinutes.coerceIn(15, 240),
            "completed" to false,
            "priority" to priority,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        return try {
            docRef.set(payload).await()
            Result.success(taskId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun toggleStudyTask(task: StudyTask): Result<Unit> {
        val uid = requireUserId()
        require(task.id.isNotBlank()) { "Task ID must not be blank" }
        requireNotNull(task.createdAt) { "Task createdAt must not be null" }
        val docRef = db.collection("users").document(uid).collection("studyTasks").document(task.id)
        return try {
            docRef.set(task.copy(userId = uid, completed = !task.completed, updatedAt = null)).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun deleteStudyTask(taskId: String): Result<Unit> {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid).collection("studyTasks").document(taskId)
        return try {
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            Result.failure(e)
        }
    }

    // -----------------------------------------------------------------------
    // 5. CommunityQuestion & Admin Content-Management (/communityQuestions)
    // -----------------------------------------------------------------------

    fun observeApprovedCommunityQuestions(): Flow<List<CommunityQuestion>> {
        val colRef = db.collection("communityQuestions")
        return colRef.whereEqualTo("reviewStatus", "APPROVED")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(CommunityQuestion::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            }
            .catch { error ->
                if (error is Exception) handleFirestoreError(error, OperationType.LIST, colRef.path)
                throw error
            }
    }

    fun observeMySubmittedQuestions(userId: String): Flow<List<CommunityQuestion>> {
        val colRef = db.collection("communityQuestions")
        return colRef.whereEqualTo("authorId", userId)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(CommunityQuestion::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
            .catch { error ->
                if (error is Exception) handleFirestoreError(error, OperationType.LIST, colRef.path)
                throw error
            }
    }

    fun observeAdminReviewQueue(): Flow<List<CommunityQuestion>> {
        val colRef = db.collection("communityQuestions")
        return colRef.snapshots()
            .map { snapshot ->
                snapshot.toObjects(CommunityQuestion::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
            .catch { error ->
                if (error is Exception) handleFirestoreError(error, OperationType.LIST, colRef.path)
                throw error
            }
    }

    suspend fun submitCommunityQuestion(
        subjectId: String,
        lessonId: String,
        stream: String,
        questionType: String,
        difficulty: String,
        provenance: String,
        sourceCitation: String,
        curriculumMapping: String,
        stemAr: String,
        stemFr: String,
        optionsAr: List<String>,
        optionsFr: List<String>,
        correctIndices: List<Int>,
        explanationAr: String,
        explanationFr: String
    ): Result<String> {
        val uid = requireUserId()
        val qId = "cq_${UUID.randomUUID().toString().replace("-", "").take(20)}"
        val docRef = db.collection("communityQuestions").document(qId)
        val payload = mapOf(
            "authorId" to uid,
            "subjectId" to subjectId.take(64),
            "lessonId" to lessonId.take(64),
            "stream" to stream.take(40),
            "questionType" to questionType,
            "difficulty" to difficulty,
            "provenance" to provenance,
            "sourceCitation" to sourceCitation.trim().ifBlank { "مساهمة تعليمية قيد المراجعة" }.take(200),
            "curriculumMapping" to curriculumMapping.trim().ifBlank { "التدرج السنوي للبكالوريا" }.take(200),
            "stemAr" to stemAr.trim().take(1500),
            "stemFr" to stemFr.trim().ifBlank { stemAr.trim() }.take(1500),
            "optionsAr" to optionsAr.take(6),
            "optionsFr" to optionsFr.ifEmpty { optionsAr }.take(6),
            "correctIndices" to correctIndices.ifEmpty { listOf(0) }.take(6),
            "explanationAr" to explanationAr.trim().take(2000),
            "explanationFr" to explanationFr.trim().ifBlank { explanationAr.trim() }.take(2000),
            "reviewStatus" to "PENDING_REVIEW",
            "reviewerNote" to "",
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        return try {
            docRef.set(payload).await()
            Result.success(qId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun reviewCommunityQuestion(
        question: CommunityQuestion,
        newStatus: String,
        reviewerNote: String
    ): Result<Unit> {
        require(question.id.isNotBlank()) { "Question ID must not be blank" }
        requireNotNull(question.createdAt) { "Question createdAt must not be null" }
        val docRef = db.collection("communityQuestions").document(question.id)
        val updated = question.copy(
            reviewStatus = newStatus,
            reviewerNote = reviewerNote.trim().take(500),
            updatedAt = null
        )
        return try {
            docRef.set(updated).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    // -----------------------------------------------------------------------
    // 6. Account & Personal Data Deletion (/users/{userId} + Subcollections)
    // -----------------------------------------------------------------------

    suspend fun deleteAccountData(): Result<Unit> {
        val uid = requireUserId()
        val userDoc = db.collection("users").document(uid)
        return try {
            // Delete subcollections owned by user
            for (sub in listOf("attempts", "reviews", "studyTasks")) {
                val snap = userDoc.collection(sub).get().await()
                for (doc in snap.documents) {
                    doc.reference.delete().await()
                }
            }
            userDoc.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, userDoc.path)
            Result.failure(e)
        }
    }
}
