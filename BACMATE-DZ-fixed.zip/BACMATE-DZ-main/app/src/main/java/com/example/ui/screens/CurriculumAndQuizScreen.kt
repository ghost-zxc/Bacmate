package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.FactCheck
import androidx.compose.material.icons.automirrored.filled.FormatListBulleted
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import com.example.data.model.AcademicStream
import com.example.data.model.AiTutorMode
import com.example.data.model.DifficultyLevel
import com.example.data.model.Lesson
import com.example.data.model.Question
import com.example.data.model.QuestionProvenance
import com.example.data.model.Subject
import com.example.data.model.UserProfile
import com.example.data.seed.AlgerianCurriculumSeed
import com.example.ui.theme.BacCoralError
import com.example.ui.theme.BacGoldAccent
import com.example.ui.theme.BacMintSuccess
import com.example.ui.theme.EmeraldPrimaryDark
import com.example.ui.theme.EmeraldPrimaryLight
import com.example.ui.viewmodel.ActiveQuizSession
import com.example.ui.viewmodel.AiGenerationState

@Composable
fun SubjectsAndCurriculumScreen(
    stream: AcademicStream,
    isArabic: Boolean,
    aiState: AiGenerationState,
    onStartPractice: (Subject, String?) -> Unit,
    onStartTimedExam: (Subject, String?) -> Unit,
    onGenerateAiQuestion: (Subject) -> Unit,
    onSubmitGeneratedToReviewQueue: (Question) -> Unit,
    onDismissAiState: () -> Unit,
    profile: UserProfile = UserProfile(),
    bookmarkedLessonIds: Set<String> = emptySet(),
    onToggleBookmark: (String) -> Unit = {},
    onStartConfiguredPractice: (Subject, String?, DifficultyLevel?, Boolean) -> Unit = { s, l, _, _ -> onStartPractice(s, l) },
    onAskAiTutor: (Subject, Lesson, AiTutorMode, String) -> Unit = { s, _, _, _ -> onGenerateAiQuestion(s) }
) {
    val subjects = remember(stream) { AlgerianCurriculumSeed.subjectsForStream(stream) }
    val totalVerifiedCount = remember { AlgerianCurriculumSeed.verifiedQuestions.size }

    var searchQuery by rememberSaveable { mutableStateOf("") }
    var showBookmarksOnly by rememberSaveable { mutableStateOf(false) }
    var selectedDifficultyFilter by rememberSaveable { mutableStateOf<DifficultyLevel?>(null) }
    var selectedSubjectFilterId by rememberSaveable { mutableStateOf<String?>(null) }
    var selectedTrimesterFilter by rememberSaveable { mutableIntStateOf(0) } // 0 = All, 1 = T1, 2 = T2, 3 = T3
    var quickSelectedSubjectId by rememberSaveable(stream) {
        mutableStateOf(subjects.firstOrNull()?.id ?: "svt")
    }
    val quickSubject = remember(subjects, quickSelectedSubjectId) {
        subjects.find { it.id == quickSelectedSubjectId } ?: subjects.first()
    }
    val sortedQuickLessons = remember(quickSubject) {
        quickSubject.lessons.sortedBy { it.unitNumber }
    }
    var quickSelectedLessonId by rememberSaveable(quickSelectedSubjectId) {
        mutableStateOf<String?>(sortedQuickLessons.firstOrNull()?.id)
    }

    var expandedSubjectId by rememberSaveable { mutableStateOf<String?>(subjects.firstOrNull()?.id) }

    val displayedSubjects = remember(subjects, selectedSubjectFilterId) {
        if (selectedSubjectFilterId == null) subjects
        else subjects.filter { it.id == selectedSubjectFilterId }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(6.dp))
            // Official Ministry Progression Header Banner
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                colors = listOf(EmeraldPrimaryLight, EmeraldPrimaryDark)
                            )
                        )
                        .padding(18.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                color = BacGoldAccent.copy(alpha = 0.24f),
                                shape = RoundedCornerShape(50)
                            ) {
                                Text(
                                    text = if (isArabic) {
                                        "التوزيع السنوي الرسمي لوزارة التربية الوطنية 2026"
                                    } else {
                                        "Progression Annuelle Officielle MEN 2026"
                                    },
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFFFE082),
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                                )
                            }
                            Surface(
                                color = Color.White.copy(alpha = 0.16f),
                                shape = RoundedCornerShape(50)
                            ) {
                                Text(
                                    text = if (isArabic) "$totalVerifiedCount سؤال مرتب" else "$totalVerifiedCount QCM",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = if (isArabic) {
                                "المنهاج الرسمي والتدرج السنوي — شعبة ${stream.titleAr}"
                            } else {
                                "Programme Officiel — Filière ${stream.titleFr}"
                            },
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isArabic) {
                                "مرتب بدقة من الوحدة الأولى (سبتمبر) إلى الوحدة الأخيرة (ماي) مع ميزة اختيار الوحدة وأكثر من 1,125 سؤال وجواب مفصل."
                            } else {
                                "Classé de l'Unité 01 (Septembre) à la dernière unité (Mai) avec sélection par unité et +1 125 questions corrigées."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                    }
                }
            }
        }

        // Dedicated Unit Selection & Sequential Quiz Card inside Curriculum Tab
        item {
            ElevatedCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("curriculum_unit_picker_card"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.elevatedCardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.FormatListBulleted,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isArabic) {
                                    "ميزة اختيار الوحدة والكويز المرتب"
                                } else {
                                    "Sélecteur d'Unité & Quiz Séquentiel"
                                },
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (isArabic) {
                                    "اختر المادة ثم حدد أي وحدة من الوحدة 01 إلى الوحدة الأخيرة لبدء الكويز فوراً"
                                } else {
                                    "Choisissez la matière puis l'unité (Unité 01 → Finale) pour lancer le quiz"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Subject selector row
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(vertical = 2.dp)
                    ) {
                        items(subjects, key = { "quick_subj_${it.id}" }) { subj ->
                            FilterChip(
                                selected = subj.id == quickSubject.id,
                                onClick = {
                                    quickSelectedSubjectId = subj.id
                                    expandedSubjectId = subj.id
                                },
                                label = {
                                    Text(
                                        text = if (isArabic) subj.nameAr else subj.nameFr,
                                        fontWeight = if (subj.id == quickSubject.id) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                modifier = Modifier.testTag("curriculum_quick_subject_${subj.id}")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Sequential Unit chips (All Ordered + Unit 01 .. Last Unit)
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(vertical = 2.dp)
                    ) {
                        item(key = "quick_unit_all") {
                            FilterChip(
                                selected = quickSelectedLessonId == null,
                                onClick = { quickSelectedLessonId = null },
                                label = {
                                    Text(
                                        text = if (isArabic) {
                                            "كل الوحدات بالترتيب (01 ← 0${sortedQuickLessons.size})"
                                        } else {
                                            "Toutes les unités (01 → 0${sortedQuickLessons.size})"
                                        }
                                    )
                                },
                                modifier = Modifier.testTag("curriculum_unit_chip_all")
                            )
                        }
                        items(sortedQuickLessons, key = { "quick_unit_${it.id}" }) { lesson ->
                            val isSelected = quickSelectedLessonId == lesson.id
                            FilterChip(
                                selected = isSelected,
                                onClick = { quickSelectedLessonId = lesson.id },
                                label = {
                                    Text(
                                        text = if (isArabic) {
                                            "الوحدة 0${lesson.unitNumber}: ${lesson.titleAr}"
                                        } else {
                                            "Unité 0${lesson.unitNumber}: ${lesson.titleFr}"
                                        },
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                },
                                modifier = Modifier.testTag("curriculum_unit_chip_${lesson.id}")
                            )
                        }
                    }

                    val activeQuickLesson = sortedQuickLessons.find { it.id == quickSelectedLessonId }
                    val quickQuestionsCount = remember(quickSubject.id, quickSelectedLessonId) {
                        AlgerianCurriculumSeed.questionsForSubject(
                            subjectId = quickSubject.id,
                            lessonId = quickSelectedLessonId
                        ).size
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (activeQuickLesson != null) {
                                        if (isArabic) {
                                            "الوحدة 0${activeQuickLesson.unitNumber}: ${activeQuickLesson.titleAr}"
                                        } else {
                                            "Unité 0${activeQuickLesson.unitNumber} : ${activeQuickLesson.titleFr}"
                                        }
                                    } else {
                                        if (isArabic) {
                                            "التسلسل الكامل للمادة: من الوحدة 01 إلى الوحدة 0${sortedQuickLessons.size}"
                                        } else {
                                            "Parcours complet : Unité 01 à Unité 0${sortedQuickLessons.size}"
                                        }
                                    },
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                if (activeQuickLesson != null) {
                                    Text(
                                        text = if (isArabic) {
                                            "الفصل ${activeQuickLesson.trimester} • ${activeQuickLesson.scheduleTimelineAr} • التقدم في البرنامج: ${activeQuickLesson.progressionPercentage}%"
                                        } else {
                                            "Trimestre ${activeQuickLesson.trimester} • ${activeQuickLesson.scheduleTimelineFr} • Progression : ${activeQuickLesson.progressionPercentage}%"
                                        },
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Surface(
                                color = MaterialTheme.colorScheme.primary,
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text(
                                    text = if (isArabic) "$quickQuestionsCount سؤال" else "$quickQuestionsCount Qst",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimary,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Difficulty Filter Row inside Unit Picker
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        item {
                            FilterChip(
                                selected = selectedDifficultyFilter == null,
                                onClick = { selectedDifficultyFilter = null },
                                label = { Text(if (isArabic) "كل المستويات" else "Tous niveaux") }
                            )
                        }
                        items(DifficultyLevel.entries, key = { "diff_${it.id}" }) { diff ->
                            FilterChip(
                                selected = selectedDifficultyFilter == diff,
                                onClick = { selectedDifficultyFilter = diff },
                                label = { Text(if (isArabic) diff.labelAr else diff.labelFr) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                onStartConfiguredPractice(
                                    quickSubject,
                                    quickSelectedLessonId,
                                    selectedDifficultyFilter,
                                    false
                                )
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("curriculum_launch_unit_practice"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isArabic) "ابدأ كويز الوحدة" else "Quiz de l'Unité",
                                fontWeight = FontWeight.Bold
                            )
                        }
                        OutlinedButton(
                            onClick = { onStartTimedExam(quickSubject, quickSelectedLessonId) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("curriculum_launch_unit_exam"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Timer, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (isArabic) "امتحان الوحدة" else "Examen Unité")
                        }
                    }
                }
            }
        }

        // Interactive AI Tutor Panel grounded in Official Curriculum
        item {
            InteractiveAiTutorPanel(
                stream = stream,
                profile = profile,
                aiState = aiState,
                isArabic = isArabic,
                onAskTutor = onAskAiTutor,
                onDismissResponse = onDismissAiState
            )
        }

        // Search Bar, Bookmarks Filter & Trimester Filter
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Close, contentDescription = null)
                        }
                    }
                },
                label = {
                    Text(
                        if (isArabic) "ابحث في الوحدات، الدروس، الكفاءات أو القوانين..."
                        else "Rechercher une unité, compétence ou formule..."
                    )
                },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("curriculum_search_input")
            )
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.FilterList,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = if (isArabic) "تصفية حسب الفصل والمفضلة:" else "Filtrer par trimestre & favoris :",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                }
                FilterChip(
                    selected = showBookmarksOnly,
                    onClick = { showBookmarksOnly = !showBookmarksOnly },
                    leadingIcon = {
                        Icon(
                            imageVector = if (showBookmarksOnly) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                    },
                    label = {
                        Text(if (isArabic) "المفضلة (${bookmarkedLessonIds.size})" else "Favoris (${bookmarkedLessonIds.size})")
                    },
                    modifier = Modifier.testTag("curriculum_bookmarks_filter")
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val trimesters = listOf(
                    0 to (if (isArabic) "كل الفصول (1 ← 3)" else "Tous les trimestres"),
                    1 to (if (isArabic) "الفصل الأول (سبتمبر - ديسمبر)" else "Trimestre 1 (Sept - Déc)"),
                    2 to (if (isArabic) "الفصل الثاني (جانفي - مارس)" else "Trimestre 2 (Jan - Mars)"),
                    3 to (if (isArabic) "الفصل الثالث (أفريل - ماي)" else "Trimestre 3 (Avril - Mai)")
                )
                items(trimesters, key = { it.first }) { (trimesterCode, label) ->
                    FilterChip(
                        selected = selectedTrimesterFilter == trimesterCode,
                        onClick = { selectedTrimesterFilter = trimesterCode },
                        label = { Text(label) },
                        modifier = Modifier.testTag("trimester_filter_$trimesterCode")
                    )
                }
            }
        }

        // AI Generated Practice Question Preview Card (clearly labeled as non-official!)
        if (aiState is AiGenerationState.Loading || aiState is AiGenerationState.QuestionGenerated || aiState is AiGenerationState.Error) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.7f)
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onTertiaryContainer
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (isArabic) {
                                        "تمرين تدريبي مولّد بالذكاء الاصطناعي (غير رسمي)"
                                    } else {
                                        "Exercice généré par IA (Non officiel)"
                                    },
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            IconButton(onClick = onDismissAiState) {
                                Icon(Icons.Default.Close, contentDescription = "إغلاق")
                            }
                        }

                        when (aiState) {
                            is AiGenerationState.Loading -> {
                                Row(
                                    modifier = Modifier.padding(vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.5.dp)
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        text = if (isArabic) "جاري صياغة تمرين تدريبي مطابق للكفاءة..." else "Génération d'un exercice en cours...",
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                }
                            }
                            is AiGenerationState.Error -> {
                                Text(
                                    text = aiState.message,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.error
                                )
                            }
                            is AiGenerationState.QuestionGenerated -> {
                                val q = aiState.question
                                Text(
                                    text = q.provenance.disclaimerAr,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onTertiaryContainer.copy(alpha = 0.8f)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = if (isArabic) q.stemAr else q.stemFr,
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                val opts = if (isArabic) q.optionsAr else q.optionsFr
                                opts.forEachIndexed { idx, opt ->
                                    val isCorrect = idx in q.correctIndices
                                    Text(
                                        text = "${idx + 1}. $opt ${if (isCorrect) "✓" else ""}",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = if (isCorrect) FontWeight.Bold else FontWeight.Normal
                                    )
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = if (isArabic) "التعليل: ${q.explanationAr}" else "Corrigé : ${q.explanationFr}",
                                    style = MaterialTheme.typography.bodySmall
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Button(
                                    onClick = { onSubmitGeneratedToReviewQueue(q) },
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text(
                                        if (isArabic) "إرسال إلى لوحة المراجعة العلمية لاعتماده" else "Soumettre à la revue éditoriale"
                                    )
                                }
                            }
                            else -> {}
                        }
                    }
                }
            }
        }

        items(displayedSubjects, key = { it.id }) { subject ->
            val isExpanded = expandedSubjectId == subject.id || searchQuery.isNotBlank() || showBookmarksOnly
            val coeff = subject.coefficientFor(stream)
            val orderedLessons = remember(subject, selectedTrimesterFilter, searchQuery, showBookmarksOnly, bookmarkedLessonIds) {
                val qTrim = searchQuery.trim()
                subject.lessons
                    .sortedBy { it.unitNumber }
                    .filter { selectedTrimesterFilter == 0 || it.trimester == selectedTrimesterFilter }
                    .filter { !showBookmarksOnly || it.id in bookmarkedLessonIds }
                    .filter { lesson ->
                        if (qTrim.isEmpty()) true
                        else {
                            lesson.titleAr.contains(qTrim, ignoreCase = true) ||
                                lesson.titleFr.contains(qTrim, ignoreCase = true) ||
                                lesson.curriculumCompetencyAr.contains(qTrim, ignoreCase = true) ||
                                lesson.keyFormulas.any { f -> f.contains(qTrim, ignoreCase = true) }
                        }
                    }
            }
            val subjectTotalQuestions = remember(subject.id) {
                AlgerianCurriculumSeed.questionsForSubject(
                    subjectId = subject.id,
                    lessonId = null
                ).size
            }

            ElevatedCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("subject_card_${subject.id}"),
                shape = RoundedCornerShape(22.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                expandedSubjectId = if (isExpanded) null else subject.id
                            },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = if (isArabic) "المعامل $coeff" else "Coeff $coeff",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isArabic) subject.nameAr else subject.nameFr,
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (isArabic) {
                                    "${subject.lessons.size} وحدات رسمية بالترتيب • $subjectTotalQuestions سؤال وجواب"
                                } else {
                                    "${subject.lessons.size} unités officielles • $subjectTotalQuestions questions"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Icon(
                            imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = null
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { onStartPractice(subject, null) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("subject_practice_${subject.id}"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (isArabic) "تدريب مرتب ($subjectTotalQuestions)" else "Quiz ($subjectTotalQuestions)")
                        }
                        OutlinedButton(
                            onClick = { onStartTimedExam(subject, null) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("subject_exam_${subject.id}"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Timer, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (isArabic) "امتحان شامل" else "Examen")
                        }
                        OutlinedButton(
                            onClick = { onGenerateAiQuestion(subject) },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.testTag("subject_ai_gen_${subject.id}")
                        ) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = "AI", modifier = Modifier.size(18.dp))
                        }
                    }

                    AnimatedVisibility(visible = isExpanded) {
                        Column(
                            modifier = Modifier.padding(top = 14.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            HorizontalDivider()
                            orderedLessons.forEach { lesson ->
                                val unitQuestionCount = remember(subject.id, lesson.id) {
                                    AlgerianCurriculumSeed.questionsForSubject(
                                        subjectId = subject.id,
                                        lessonId = lesson.id
                                    ).size
                                }
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                                    )
                                ) {
                                    Column(modifier = Modifier.padding(14.dp)) {
                                        // Top Metadata Badges: Unit Number, Trimester, Schedule Timeline, Question Count
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(
                                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Surface(
                                                    color = MaterialTheme.colorScheme.primary,
                                                    shape = RoundedCornerShape(8.dp)
                                                ) {
                                                    Text(
                                                        text = if (isArabic) "الوحدة 0${lesson.unitNumber}" else "Unité 0${lesson.unitNumber}",
                                                        style = MaterialTheme.typography.labelMedium,
                                                        fontWeight = FontWeight.Bold,
                                                        color = MaterialTheme.colorScheme.onPrimary,
                                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                                    )
                                                }
                                                Surface(
                                                    color = MaterialTheme.colorScheme.secondaryContainer,
                                                    shape = RoundedCornerShape(8.dp)
                                                ) {
                                                    Text(
                                                        text = if (isArabic) "الفصل ${lesson.trimester}" else "Trimestre ${lesson.trimester}",
                                                        style = MaterialTheme.typography.labelSmall,
                                                        fontWeight = FontWeight.SemiBold,
                                                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                                    )
                                                }
                                            }

                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Surface(
                                                    color = MaterialTheme.colorScheme.tertiaryContainer,
                                                    shape = RoundedCornerShape(8.dp)
                                                ) {
                                                    Text(
                                                        text = if (isArabic) "$unitQuestionCount سؤال مرتب" else "$unitQuestionCount QCM",
                                                        style = MaterialTheme.typography.labelSmall,
                                                        fontWeight = FontWeight.Bold,
                                                        color = MaterialTheme.colorScheme.onTertiaryContainer,
                                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                                    )
                                                }
                                                IconButton(
                                                    onClick = { onToggleBookmark(lesson.id) },
                                                    modifier = Modifier
                                                        .size(32.dp)
                                                        .testTag("bookmark_lesson_${lesson.id}")
                                                ) {
                                                    val isBookmarked = lesson.id in bookmarkedLessonIds
                                                    Icon(
                                                        imageVector = if (isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                                                        contentDescription = if (isArabic) "حفظ الدرس" else "Favori",
                                                        tint = if (isBookmarked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                                        modifier = Modifier.size(18.dp)
                                                    )
                                                }
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(8.dp))

                                        Text(
                                            text = if (isArabic) lesson.titleAr else lesson.titleFr,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold
                                        )

                                        if (lesson.scheduleTimelineAr.isNotBlank()) {
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(
                                                    imageVector = Icons.Default.CalendarMonth,
                                                    contentDescription = null,
                                                    tint = MaterialTheme.colorScheme.secondary,
                                                    modifier = Modifier.size(15.dp)
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(
                                                    text = if (isArabic) {
                                                        "فترة الإنجاز الرسمية: ${lesson.scheduleTimelineAr} • التدرج السنوي: ${lesson.progressionPercentage}%"
                                                    } else {
                                                        "Période officielle : ${lesson.scheduleTimelineFr} • Progression : ${lesson.progressionPercentage}%"
                                                    },
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.secondary
                                                )
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(6.dp))
                                        LinearProgressIndicator(
                                            progress = { (lesson.progressionPercentage / 100f).coerceIn(0.05f, 1f) },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(5.dp)
                                                .clip(RoundedCornerShape(3.dp))
                                        )

                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(
                                            text = if (isArabic) lesson.curriculumCompetencyAr else lesson.curriculumCompetencyFr,
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = FontWeight.Medium,
                                            color = MaterialTheme.colorScheme.primary
                                        )

                                        Spacer(modifier = Modifier.height(6.dp))
                                        val points = if (isArabic) lesson.summaryPointsAr else lesson.summaryPointsFr
                                        points.forEach { pt ->
                                            Text(
                                                text = "• $pt",
                                                style = MaterialTheme.typography.bodySmall,
                                                modifier = Modifier.padding(vertical = 2.dp)
                                            )
                                        }

                                        if (lesson.keyFormulas.isNotEmpty()) {
                                            Spacer(modifier = Modifier.height(8.dp))
                                            Surface(
                                                color = MaterialTheme.colorScheme.surface,
                                                shape = RoundedCornerShape(10.dp),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Column(modifier = Modifier.padding(10.dp)) {
                                                    lesson.keyFormulas.forEach { formula ->
                                                        Text(
                                                            text = formula,
                                                            style = MaterialTheme.typography.labelSmall,
                                                            color = MaterialTheme.colorScheme.secondary
                                                        )
                                                    }
                                                }
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(10.dp))

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Button(
                                                onClick = { onStartPractice(subject, lesson.id) },
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .testTag("unit_practice_btn_${lesson.id}"),
                                                shape = RoundedCornerShape(10.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.PlayArrow,
                                                    contentDescription = null,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text(
                                                    text = if (isArabic) {
                                                        "كويز الوحدة 0${lesson.unitNumber} ($unitQuestionCount)"
                                                    } else {
                                                        "Quiz Unité 0${lesson.unitNumber} ($unitQuestionCount)"
                                                    },
                                                    style = MaterialTheme.typography.labelMedium
                                                )
                                            }
                                            OutlinedButton(
                                                onClick = { onStartTimedExam(subject, lesson.id) },
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .testTag("unit_exam_btn_${lesson.id}"),
                                                shape = RoundedCornerShape(10.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Timer,
                                                    contentDescription = null,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text(
                                                    text = if (isArabic) "امتحان الوحدة" else "Examen Unité",
                                                    style = MaterialTheme.typography.labelMedium
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

@Composable
fun ActiveQuizAndExamPlayer(
    session: ActiveQuizSession,
    isArabic: Boolean,
    aiState: AiGenerationState,
    onSelectOption: (Int) -> Unit,
    onVerifyAnswer: () -> Unit,
    onMoveToQuestion: (Int) -> Unit,
    onFinishSession: () -> Unit,
    onRequestAiExplanation: (Question) -> Unit,
    onExitSession: () -> Unit,
    onRevealHint: () -> Unit = {}
) {
    var showSubmitConfirmDialog by remember { mutableStateOf(false) }

    // Mandatory BackHandler for secondary/sub-screen composable
    BackHandler {
        onExitSession()
    }

    if (session.isFinished) {
        QuizResultSummaryScreen(
            session = session,
            isArabic = isArabic,
            onExit = onExitSession
        )
        return
    }

    val question = session.currentQuestion ?: return
    val isTimedExam = session.mode == "TIMED_EXAM"
    val isVerified = question.id in session.verifiedQuestionIds
    val isHintRevealed = question.id in session.revealedHintIds
    val selectedSet = session.selectedIndicesByQuestion[question.id] ?: emptySet()

    if (showSubmitConfirmDialog) {
        val unansweredCount = (session.questions.size - session.answeredCount).coerceAtLeast(0)
        AlertDialog(
            onDismissRequest = { showSubmitConfirmDialog = false },
            title = {
                Text(
                    if (isArabic) "تأكيد تسليم ورقة الامتحان"
                    else "Confirmer la remise de la copie"
                )
            },
            text = {
                Text(
                    if (isArabic) {
                        "أجبت عن ${session.answeredCount} من أصل ${session.questions.size} سؤالاً (المتبقي بدون إجابة: $unansweredCount). هل تريد إنهاء الامتحان وعرض التنقيط التفصيلي (/20)؟"
                    } else {
                        "Vous avez répondu à ${session.answeredCount}/${session.questions.size} questions ($unansweredCount sans réponse). Terminer et afficher le corrigé ?"
                    }
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showSubmitConfirmDialog = false
                        onFinishSession()
                    }
                ) {
                    Text(if (isArabic) "تسليم ورقة الامتحان" else "Valider la copie")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showSubmitConfirmDialog = false }) {
                    Text(if (isArabic) "مراجعة الإجابات" else "Vérifier mes réponses")
                }
            }
        )
    }

    val currentLesson = remember(question.subjectId, question.lessonId) {
        AlgerianCurriculumSeed.subjects
            .find { it.id == question.subjectId }
            ?.lessons
            ?.find { it.id == question.lessonId }
    }

    val displaySeconds = if (session.timeLimitSeconds != null) {
        (session.timeLimitSeconds - session.elapsedSeconds).coerceAtLeast(0)
    } else {
        session.elapsedSeconds
    }
    val timeFormatted = String.format(
        java.util.Locale.US,
        "%02d:%02d",
        displaySeconds / 60,
        displaySeconds % 60
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        // Top Header with Close, Title, Timer, and Quick Finish
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onExitSession,
                modifier = Modifier.testTag("quiz_close_button")
            ) {
                Icon(Icons.Default.Close, contentDescription = "إغلاق الاختبار")
            }

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = if (isArabic) session.titleAr else session.titleFr,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = if (isArabic) {
                            "السؤال ${session.currentIndex + 1} من ${session.questions.size}"
                        } else {
                            "Question ${session.currentIndex + 1} / ${session.questions.size}"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (currentLesson != null) {
                        Text(
                            text = "•",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = if (isArabic) {
                                "الوحدة 0${currentLesson.unitNumber}"
                            } else {
                                "Unité 0${currentLesson.unitNumber}"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Surface(
                    color = if (isTimedExam) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Timer,
                            contentDescription = null,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = timeFormatted,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                TextButton(
                    onClick = onFinishSession,
                    modifier = Modifier.testTag("quiz_top_finish_button")
                ) {
                    Text(
                        text = if (isArabic) "إنهاء" else "Noter",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        LinearProgressIndicator(
            progress = { (session.currentIndex + 1).toFloat() / session.questions.size.coerceAtLeast(1) },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp))
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Sequential Question Jump Bar (1 .. N ordered from Unit 01 to Last Unit)
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            contentPadding = PaddingValues(vertical = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            itemsIndexed(session.questions, key = { idx, q -> "jump_${idx}_${q.id}" }) { index, qItem ->
                val isCurrent = index == session.currentIndex
                val isAnswered = !session.selectedIndicesByQuestion[qItem.id].isNullOrEmpty()
                val bgColor = when {
                    isCurrent -> MaterialTheme.colorScheme.primary
                    isAnswered -> MaterialTheme.colorScheme.primaryContainer
                    else -> MaterialTheme.colorScheme.surfaceVariant
                }
                val contentColor = when {
                    isCurrent -> MaterialTheme.colorScheme.onPrimary
                    isAnswered -> MaterialTheme.colorScheme.onPrimaryContainer
                    else -> MaterialTheme.colorScheme.onSurfaceVariant
                }
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(bgColor)
                        .clickable { onMoveToQuestion(index) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "${index + 1}",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = if (isCurrent || isAnswered) FontWeight.Bold else FontWeight.Normal,
                        color = contentColor
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Provenance & Curriculum Metadata Card
            Surface(
                color = if (question.provenance == QuestionProvenance.CURRICULUM_VERIFIED) {
                    MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f)
                } else {
                    MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.6f)
                },
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (question.provenance == QuestionProvenance.CURRICULUM_VERIFIED) {
                                Icons.Default.Verified
                            } else {
                                Icons.Default.AutoAwesome
                            },
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isArabic) question.provenance.badgeAr else question.provenance.badgeFr,
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.weight(1f))
                        Text(
                            text = if (isArabic) question.difficulty.labelAr else question.difficulty.labelFr,
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (isArabic) question.curriculumMappingAr else question.curriculumMappingFr,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = if (isArabic) "المصدر: ${question.sourceCitationAr}" else "Source : ${question.sourceCitationFr}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Question Type Chip
            Text(
                text = if (isArabic) question.type.labelAr else question.type.labelFr,
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.secondary
            )

            // Question Stem
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Text(
                    text = if (isArabic) question.stemAr else question.stemFr,
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(18.dp)
                )
            }

            // Options List
            val options = if (isArabic) question.optionsAr else question.optionsFr
            options.forEachIndexed { index, optionText ->
                val isSelected = index in selectedSet
                val isCorrectOption = index in question.correctIndices
                val showFeedback = !isTimedExam && isVerified

                val borderColor = when {
                    showFeedback && isCorrectOption -> BacMintSuccess
                    showFeedback && isSelected && !isCorrectOption -> BacCoralError
                    isSelected -> MaterialTheme.colorScheme.primary
                    else -> MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                }

                val containerColor = when {
                    showFeedback && isCorrectOption -> BacMintSuccess.copy(alpha = 0.14f)
                    showFeedback && isSelected && !isCorrectOption -> BacCoralError.copy(alpha = 0.14f)
                    isSelected -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.65f)
                    else -> MaterialTheme.colorScheme.surface
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(containerColor)
                        .border(1.5.dp, borderColor, RoundedCornerShape(16.dp))
                        .clickable { onSelectOption(index) }
                        .padding(16.dp)
                        .testTag("quiz_option_$index")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "${index + 1}.",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = optionText,
                            style = MaterialTheme.typography.bodyLarge,
                            modifier = Modifier.weight(1f)
                        )
                        if (showFeedback && isCorrectOption) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = BacMintSuccess
                            )
                        }
                    }
                }
            }

            // Hint Before Solution Button (Practice Mode)
            if (!isTimedExam && !isVerified) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onRevealHint,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("quiz_hint_button"),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(Icons.Default.Lightbulb, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (isArabic) "تلميح منهجي قبل الحل" else "Indice avant corrigé")
                    }

                    if (selectedSet.isNotEmpty()) {
                        Button(
                            onClick = onVerifyAnswer,
                            modifier = Modifier
                                .weight(1.2f)
                                .testTag("quiz_verify_answer_button"),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Icon(Icons.AutoMirrored.Filled.FactCheck, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (isArabic) "تحقق من الإجابة" else "Vérifier")
                        }
                    }
                }
            }

            AnimatedVisibility(visible = !isTimedExam && isHintRevealed && !isVerified) {
                Surface(
                    color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.55f),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lightbulb,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isArabic) question.pedagogicalHintAr else question.pedagogicalHintFr,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }

            // Verified Explanation, Distractor Analysis & Structured Bac Rubric
            AnimatedVisibility(visible = !isTimedExam && isVerified) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.55f)
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = if (isArabic) "الحل النموذجي المفصل والتعليل العلمي" else "Corrigé-type détaillé et justification",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (isArabic) question.explanationAr else question.explanationFr,
                            style = MaterialTheme.typography.bodyMedium
                        )

                        Spacer(modifier = Modifier.height(8.dp))
                        Surface(
                            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.8f),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = if (isArabic) {
                                    question.distractorAnalysisAr(selectedSet)
                                } else {
                                    question.distractorAnalysisFr(selectedSet)
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(10.dp)
                            )
                        }

                        val rubric = if (isArabic) question.structuredRubricStepsAr else question.structuredRubricStepsFr
                        if (rubric.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = if (isArabic) "سلم التنقيط المنهجي في البكالوريا:" else "Barème méthodologique du Bac :",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.primary
                            )
                            rubric.forEach { step ->
                                Text(
                                    text = "• $step",
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedButton(
                            onClick = { onRequestAiExplanation(question) },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.testTag("quiz_ai_tutor_button")
                        ) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                if (isArabic) "اطلب تفصيلاً إضافياً من المساعد البيداغوجي الذكي"
                                else "Explication approfondie par le tuteur IA"
                            )
                        }

                        if (aiState is AiGenerationState.Loading) {
                            Spacer(modifier = Modifier.height(8.dp))
                            CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                        } else if (aiState is AiGenerationState.ExplanationReady && aiState.questionId == question.id) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Surface(
                                color = MaterialTheme.colorScheme.surface,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = aiState.text,
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }
                        } else if (aiState is AiGenerationState.Error) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = aiState.message,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Bottom Navigation Controls
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedButton(
                onClick = { onMoveToQuestion(session.currentIndex - 1) },
                enabled = session.currentIndex > 0,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text(if (isArabic) "السابق" else "Précédent")
            }

            if (session.currentIndex < session.questions.lastIndex) {
                Button(
                    onClick = { onMoveToQuestion(session.currentIndex + 1) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("quiz_next_button"),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text(if (isArabic) "التالي" else "Suivant")
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null)
                }
            } else {
                Button(
                    onClick = {
                        if (isTimedExam) showSubmitConfirmDialog = true else onFinishSession()
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("quiz_finish_button"),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (isArabic) "إنهاء وعرض النتيجة" else "Terminer et noter")
                }
            }
        }
    }
}

@Composable
private fun QuizResultSummaryScreen(
    session: ActiveQuizSession,
    isArabic: Boolean,
    onExit: () -> Unit
) {
    val answeredQuestions = remember(session) {
        val answered = session.questions.filter {
            !session.selectedIndicesByQuestion[it.id].isNullOrEmpty()
        }
        if (answered.isNotEmpty()) answered else session.questions.take(15)
    }
    val evaluatedCount = remember(session) {
        val count = session.questions.count { !session.selectedIndicesByQuestion[it.id].isNullOrEmpty() }
        if (count > 0) count else session.questions.size
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = if (isArabic) "النتيجة النهائية والتقييم" else "Résultat final et bilan",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = String.format(java.util.Locale.US, "%.1f / 20", session.bacGradeOutOf20),
                        style = MaterialTheme.typography.displayMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = if (isArabic) {
                            "الإجابات الصحيحة: ${session.correctCount} من $evaluatedCount (${session.scorePercent}%)"
                        } else {
                            "Bonnes réponses : ${session.correctCount} / $evaluatedCount (${session.scorePercent}%)"
                        },
                        style = MaterialTheme.typography.bodyLarge
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (isArabic) {
                            "تم حفظ النتيجة سحابياً وإضافة الأسئلة الخاطئة تلقائياً إلى كراس الأخطاء (SM-2)."
                        } else {
                            "Résultat synchronisé et erreurs ajoutées au carnet de répétition espacée SM-2."
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        items(answeredQuestions, key = { it.id }) { q ->
            val selected = session.selectedIndicesByQuestion[q.id] ?: emptySet()
            val isCorrect = selected.isNotEmpty() && selected == q.correctIndices.toSet()
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isCorrect) {
                        BacMintSuccess.copy(alpha = 0.1f)
                    } else {
                        BacCoralError.copy(alpha = 0.1f)
                    }
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isArabic) q.stemAr else q.stemFr,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (isArabic) "الشرح: ${q.explanationAr}" else "Corrigé : ${q.explanationFr}",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }

        item {
            Button(
                onClick = onExit,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("quiz_result_done_button"),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text(if (isArabic) "العودة إلى لوحة التحكم" else "Retour au tableau de bord")
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
