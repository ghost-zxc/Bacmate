package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.AcademicStream
import com.example.data.model.AppLanguage
import com.example.data.model.CommunityQuestion
import com.example.data.model.DifficultyLevel
import com.example.data.model.QuestionProvenance
import com.example.data.model.SubscriptionTier
import com.example.data.model.UserProfile
import com.example.data.seed.AlgerianCurriculumSeed

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProfileSettingsAndAdminScreen(
    profile: UserProfile,
    userEmail: String?,
    isCurrentUserAdmin: Boolean,
    mySubmittedQuestions: List<CommunityQuestion>,
    approvedCommunityQuestions: List<CommunityQuestion>,
    isArabic: Boolean,
    isDarkTheme: Boolean,
    onToggleDarkTheme: () -> Unit,
    onUpdatePreferences: (String, Int, AcademicStream, AppLanguage, Int) -> Unit,
    onSubmitQuestion: (String, String, AcademicStream, DifficultyLevel, QuestionProvenance, String, String, String, List<String>, Int, String) -> Unit,
    onReviewQuestion: (CommunityQuestion, String, String) -> Unit,
    onSignOut: () -> Unit,
    onExportDataJson: () -> String = { "{}" },
    onDeleteAccountData: () -> Unit = {},
    onBulkImportQuestionsJson: (String, AcademicStream) -> Unit = { _, _ -> }
) {
    val currentStream = AcademicStream.fromId(profile.academicStream)
    val currentLang = AppLanguage.fromCode(profile.language)
    val tier = SubscriptionTier.fromId(profile.subscriptionTier)

    var showAdminQueue by remember { mutableStateOf(false) }
    var showExportDialog by remember { mutableStateOf(false) }
    var exportedJsonText by remember { mutableStateOf("") }
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }

    // Question submission & bulk import state
    var stemAr by remember { mutableStateOf("") }
    var opt1 by remember { mutableStateOf("") }
    var opt2 by remember { mutableStateOf("") }
    var opt3 by remember { mutableStateOf("") }
    var opt4 by remember { mutableStateOf("") }
    var correctIdx by remember { mutableIntStateOf(0) }
    var explanationAr by remember { mutableStateOf("") }
    var sourceCitation by remember { mutableStateOf("سلسلة تمارين المراجعة النهائية للبكالوريا") }
    var curriculumMapping by remember { mutableStateOf("المجال التعلمي 01: التحليل — الدوال العددية") }
    var selectedSubjectId by remember { mutableStateOf("math") }
    var bulkJsonPayload by remember { mutableStateOf("") }
    var reviewFilterStatus by remember { mutableStateOf("ALL") }

    val reviewList = remember(mySubmittedQuestions, approvedCommunityQuestions, reviewFilterStatus) {
        val merged = (mySubmittedQuestions + approvedCommunityQuestions).distinctBy { it.id }
        if (reviewFilterStatus == "ALL") merged else merged.filter { it.reviewStatus == reviewFilterStatus }
    }

    if (showExportDialog) {
        AlertDialog(
            onDismissRequest = { showExportDialog = false },
            title = {
                Text(if (isArabic) "تصدير بيانات المترشح (JSON)" else "Export des données (JSON)")
            },
            text = {
                OutlinedTextField(
                    value = exportedJsonText,
                    onValueChange = {},
                    readOnly = true,
                    maxLines = 12,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(onClick = { showExportDialog = false }) {
                    Text(if (isArabic) "إغلاق" else "Fermer")
                }
            }
        )
    }

    if (showDeleteConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = false },
            title = {
                Text(if (isArabic) "تأكيد حذف بيانات الحساب" else "Confirmer la suppression des données")
            },
            text = {
                Text(
                    if (isArabic) {
                        "سيتم حذف ملفك الشخصي وسجل الاختبارات وكراس الأخطاء والمخطط الدراسي نهائياً من قاعدة البيانات السحابية. لا يمكن التراجع عن هذا الإجراء."
                    } else {
                        "Votre profil, vos résultats, votre carnet d'erreurs et votre planning seront définitivement supprimés."
                    }
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirmDialog = false
                        onDeleteAccountData()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text(if (isArabic) "حذف نهائي" else "Supprimer définitivement")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmDialog = false }) {
                    Text(if (isArabic) "إلغاء" else "Annuler")
                }
            }
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = if (isArabic) "الملف الشخصي، الاشتراك، وإدارة المحتوى" else "Profil, Abonnement & Gestion de contenu",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.primary
            )
        }

        // Student Account, Privacy & Preferences Card
        item {
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = profile.displayName,
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${userEmail ?: ""} • BAC ${profile.examYear}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        OutlinedButton(
                            onClick = onSignOut,
                            modifier = Modifier.testTag("profile_sign_out_button")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (isArabic) "خروج" else "Quitter")
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    HorizontalDivider()
                    Spacer(modifier = Modifier.height(12.dp))

                    // Language & RTL Switcher
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Language, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isArabic) "لغة التطبيق واتجاه القراءة (RTL/LTR)" else "Langue et direction (RTL/LTR)",
                                style = MaterialTheme.typography.titleSmall
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            AppLanguage.entries.forEach { lang ->
                                FilterChip(
                                    selected = currentLang == lang,
                                    onClick = {
                                        onUpdatePreferences(
                                            profile.displayName,
                                            profile.examYear,
                                            currentStream,
                                            lang,
                                            profile.dailyGoalMinutes
                                        )
                                    },
                                    label = { Text(lang.code) },
                                    modifier = Modifier.testTag("profile_lang_${lang.code}")
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Dark Mode Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.DarkMode, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isArabic) "الوضع الليلي المريح للعين" else "Mode Sombre",
                                style = MaterialTheme.typography.titleSmall
                            )
                        }
                        Switch(
                            checked = isDarkTheme,
                            onCheckedChange = { onToggleDarkTheme() },
                            modifier = Modifier.testTag("profile_dark_mode_switch")
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = if (isArabic) "تغيير الشعبة الدراسية:" else "Changer de filière :",
                        style = MaterialTheme.typography.labelLarge
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        AcademicStream.entries.forEach { st ->
                            FilterChip(
                                selected = currentStream == st,
                                onClick = {
                                    onUpdatePreferences(
                                        profile.displayName,
                                        profile.examYear,
                                        st,
                                        currentLang,
                                        profile.dailyGoalMinutes
                                    )
                                },
                                label = { Text(if (isArabic) st.badgeAr else st.titleFr) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider()
                    Spacer(modifier = Modifier.height(12.dp))

                    // Privacy & Data Rights: Export JSON & Delete Account Data
                    Text(
                        text = if (isArabic) "حقوق البيانات والخصوصية:" else "Confidentialité et droits sur les données :",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                exportedJsonText = onExportDataJson()
                                showExportDialog = true
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("export_user_data_button"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (isArabic) "تصدير بياناتي (JSON)" else "Exporter JSON")
                        }

                        OutlinedButton(
                            onClick = { showDeleteConfirmDialog = true },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("delete_account_data_button"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.DeleteForever,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (isArabic) "حذف بيانات الحساب" else "Supprimer le compte",
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }
        }

        // Freemium & Subscription Page (Policy-Compliant — No Fake Payment Success)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.65f)
                )
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.WorkspacePremium,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.secondary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isArabic) "إدارة الاشتراك والحصة اليومية (Freemium)" else "Abonnement & Quotas quotidiens",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (isArabic) {
                            "الباقة الحالية: ${tier.titleAr} • الاختبارات اليومية: ${profile.dailyQuizzesUsedToday}/${tier.dailyQuizLimit} • الشرح الذكي: ${profile.dailyAiRequestsUsedToday}/${tier.dailyAiLimit}"
                        } else {
                            "Offre actuelle : ${tier.titleFr} • Quiz : ${profile.dailyQuizzesUsedToday}/${tier.dailyQuizLimit} • IA : ${profile.dailyAiRequestsUsedToday}/${tier.dailyAiLimit}"
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = if (isArabic) {
                            "• الباقة المجانية: 3 اختبارات تطبيقية يومياً + التحدي اليومي الموحد + مراجعة غير محدودة لكراس الأخطاء SM-2 + المخطط الدراسي.\n" +
                                "• باقة BacMate DZ Pro (شهرية / سنوية لدفعة البكالوريا): امتحانات مؤقتة غير محدودة، تحليلات معمقة، وسقف موسع للشرح البيداغوجي الذكي."
                        } else {
                            "• Offre Gratuite : 3 quiz/jour + Défi Quotidien + Carnet d'erreurs SM-2 illimité + Planning.\n" +
                                "• Offre BacMate DZ Pro : Examens blancs illimités, analytiques avancées et quotas IA étendus."
                        },
                        style = MaterialTheme.typography.bodySmall
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isArabic) {
                                    "إشعار شفافية الدفع: وفق سياسات Google Play، لا يتم تفعيل أي عملية دفع وهمية داخل بيئة المعاينة. يتطلب الدفع الفعلي ربط حساب التاجر في Google Play Console وتفعيل معرّفات الاشتراكات (Google Play Billing SKUs)."
                                } else {
                                    "Note de conformité : Aucun paiement simulé n'est exécuté. L'intégration Google Play Billing requiert un compte marchand Play Console actif en production."
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // Admin Content-Management, Duplicate Check & Bulk JSON Import Area
        item {
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Icon(
                                imageVector = Icons.Default.AdminPanelSettings,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = if (isArabic) "لوحة إدارة ومراجعة المحتوى التعليمي" else "Gestion et validation éditoriale (Admin)",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (isCurrentUserAdmin) {
                                        if (isArabic) "صلاحية المشرف مفعّلة ($userEmail)" else "Accès Administrateur actif ($userEmail)"
                                    } else {
                                        if (isArabic) "وضع المساهمة (الاعتماد النهائي مخصص للمشرف)" else "Mode contribution (validation réservée à l'admin)"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }

                        OutlinedButton(onClick = { showAdminQueue = !showAdminQueue }) {
                            Text(if (showAdminQueue) (if (isArabic) "إخفاء" else "Masquer") else (if (isArabic) "إدارة الأسئلة" else "Gérer"))
                        }
                    }

                    if (showAdminQueue) {
                        Spacer(modifier = Modifier.height(14.dp))
                        HorizontalDivider()
                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = if (isArabic) "اقتراح سؤال جديد للمراجعة والتدقيق العلمي (مع فحص عدم التكرار):" else "Proposer une question (détection des doublons active) :",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(8.dp))
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            AlgerianCurriculumSeed.subjects.forEach { s ->
                                FilterChip(
                                    selected = selectedSubjectId == s.id,
                                    onClick = { selectedSubjectId = s.id },
                                    label = { Text(if (isArabic) s.nameAr else s.nameFr) }
                                )
                            }
                        }

                        OutlinedTextField(
                            value = stemAr,
                            onValueChange = { stemAr = it },
                            label = { Text(if (isArabic) "نص السؤال العلمي بدقة" else "Énoncé de la question") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("admin_question_stem_input")
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = opt1,
                                onValueChange = { opt1 = it },
                                label = { Text("خيار 1 (الصحيح)") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = opt2,
                                onValueChange = { opt2 = it },
                                label = { Text("خيار 2") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = opt3,
                                onValueChange = { opt3 = it },
                                label = { Text("خيار 3") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = opt4,
                                onValueChange = { opt4 = it },
                                label = { Text("خيار 4") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = explanationAr,
                            onValueChange = { explanationAr = it },
                            label = { Text(if (isArabic) "الحل النموذجي والتعليل المنهجي" else "Justification détaillée") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = sourceCitation,
                                onValueChange = { sourceCitation = it },
                                label = { Text(if (isArabic) "المصدر / المرجع" else "Source") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = curriculumMapping,
                                onValueChange = { curriculumMapping = it },
                                label = { Text(if (isArabic) "مطابقة التدرج" else "Unité du programme") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = {
                                val options = listOf(opt1, opt2, opt3, opt4).map { it.trim() }.filter { it.isNotEmpty() }
                                if (stemAr.isNotBlank() && options.size >= 2 && explanationAr.isNotBlank()) {
                                    val subj = AlgerianCurriculumSeed.subjects.find { it.id == selectedSubjectId }
                                    val lessonId = subj?.lessons?.firstOrNull()?.id ?: "math_limits"
                                    onSubmitQuestion(
                                        selectedSubjectId,
                                        lessonId,
                                        currentStream,
                                        DifficultyLevel.BAC_LEVEL,
                                        QuestionProvenance.TEACHER_SUBMITTED,
                                        sourceCitation,
                                        curriculumMapping,
                                        stemAr,
                                        options,
                                        correctIdx,
                                        explanationAr
                                    )
                                    stemAr = ""
                                    opt1 = ""
                                    opt2 = ""
                                    opt3 = ""
                                    opt4 = ""
                                    explanationAr = ""
                                }
                            },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("admin_submit_question_button")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (isArabic) "إرسال السؤال إلى طابور التدقيق" else "Soumettre à la file de validation")
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        HorizontalDivider()
                        Spacer(modifier = Modifier.height(10.dp))

                        // Bulk JSON Question Import
                        Text(
                            text = if (isArabic) "استيراد دفعي للأسئلة بصيغة JSON (مع كشف التكرار):" else "Importation par lot JSON (anti-doublons) :",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(
                            value = bulkJsonPayload,
                            onValueChange = { bulkJsonPayload = it },
                            placeholder = {
                                Text("""[{"subjectId":"math","lessonId":"math_limits","stemAr":"...","optionsAr":["أ","ب"],"correctIndex":0,"explanationAr":"..."}]""")
                            },
                            maxLines = 4,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("admin_bulk_json_input")
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = {
                                if (bulkJsonPayload.isNotBlank()) {
                                    onBulkImportQuestionsJson(bulkJsonPayload, currentStream)
                                    bulkJsonPayload = ""
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("admin_bulk_import_button"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.UploadFile, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (isArabic) "استيراد دفعة JSON إلى طابور المراجعة" else "Importer le lot JSON")
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("ALL", "PENDING_REVIEW", "APPROVED", "REJECTED").forEach { st ->
                                FilterChip(
                                    selected = reviewFilterStatus == st,
                                    onClick = { reviewFilterStatus = st },
                                    label = { Text(st) }
                                )
                            }
                        }
                    }
                }
            }
        }

        // Submitted / Pending Review Questions List
        if (showAdminQueue && reviewList.isNotEmpty()) {
            items(reviewList, key = { it.id }) { cq ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    )
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                color = when (cq.reviewStatus) {
                                    "APPROVED" -> MaterialTheme.colorScheme.primaryContainer
                                    "REJECTED" -> MaterialTheme.colorScheme.errorContainer
                                    else -> MaterialTheme.colorScheme.secondaryContainer
                                },
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = cq.reviewStatus,
                                    style = MaterialTheme.typography.labelSmall,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                            Text(
                                text = "${cq.subjectId} • ${cq.provenance}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = cq.stemAr,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "التعليل: ${cq.explanationAr}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        if (isCurrentUserAdmin && cq.reviewStatus != "APPROVED") {
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = {
                                        onReviewQuestion(cq, "APPROVED", "تم التدقيق والمطابقة مع المنهاج الرسمي")
                                    },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.Verified, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(if (isArabic) "اعتماد (Approve)" else "Approuver")
                                }
                                OutlinedButton(
                                    onClick = {
                                        onReviewQuestion(cq, "REJECTED", "يحتاج تدقيقاً إضافياً في الصياغة")
                                    },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(if (isArabic) "رفض" else "Rejeter")
                                }
                            }
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(28.dp)) }
    }
}
