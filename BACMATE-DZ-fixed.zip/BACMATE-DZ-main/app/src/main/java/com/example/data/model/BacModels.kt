package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp
import java.time.LocalDate
import kotlin.math.max
import kotlin.math.roundToInt

enum class AppLanguage(val code: String, val labelAr: String, val labelFr: String) {
    AR("AR", "العربية (الأساسية)", "Arabe (Principal)"),
    FR("FR", "الفرنسية (ثانوية)", "Français (Secondaire)");

    companion object {
        fun fromCode(code: String): AppLanguage = entries.find { it.code == code } ?: AR
    }
}

enum class AcademicStream(
    val id: String,
    val titleAr: String,
    val titleFr: String,
    val badgeAr: String,
    val mainSubjectsDescAr: String,
    val mainSubjectsDescFr: String
) {
    SCIENCES_EXP(
        id = "SCIENCES_EXP",
        titleAr = "العلوم التجريبية",
        titleFr = "Sciences Expérimentales",
        badgeAr = "ع. تجريبية",
        mainSubjectsDescAr = "علوم الطبيعة (معامل 6) • فيزياء (5) • رياضيات (5)",
        mainSubjectsDescFr = "SVT (Coeff 6) • Physique (5) • Mathématiques (5)"
    ),
    MATH(
        id = "MATH",
        titleAr = "الرياضيات",
        titleFr = "Mathématiques",
        badgeAr = "تقني / رياضيات",
        mainSubjectsDescAr = "الرياضيات (معامل 7) • العلوم الفيزيائية (معامل 6)",
        mainSubjectsDescFr = "Mathématiques (Coeff 7) • Sciences Physiques (Coeff 6)"
    ),
    TECH_MATH(
        id = "TECH_MATH",
        titleAr = "تقني رياضي",
        titleFr = "Techniques Mathématiques",
        badgeAr = "تقني رياضي",
        mainSubjectsDescAr = "تكنولوجيا هندسية (معامل 6) • رياضيات (6) • فيزياء (6)",
        mainSubjectsDescFr = "Génie (Coeff 6) • Mathématiques (6) • Physique (6)"
    ),
    GESTION_ECO(
        id = "GESTION_ECO",
        titleAr = "تسيير واقتصاد",
        titleFr = "Gestion et Économie",
        badgeAr = "تسيير واقتصاد",
        mainSubjectsDescAr = "تسيير محاسبي (6) • اقتصاد (5) • رياضيات (5) • تاريخ وجغرافيا (4)",
        mainSubjectsDescFr = "Comptabilité (6) • Économie (5) • Maths (5) • Hist-Géo (4)"
    ),
    LETTRES_PHILO(
        id = "LETTRES_PHILO",
        titleAr = "آداب وفلسفة",
        titleFr = "Lettres et Philosophie",
        badgeAr = "آداب وفلسفة",
        mainSubjectsDescAr = "الأدب العربي (معامل 6) • الفلسفة (معامل 6) • التاريخ والجغرافيا (4)",
        mainSubjectsDescFr = "Littérature Arabe (Coeff 6) • Philosophie (6) • Hist-Géo (4)"
    ),
    LANGUES(
        id = "LANGUES",
        titleAr = "لغات أجنبية",
        titleFr = "Langues Étrangères",
        badgeAr = "لغات أجنبية",
        mainSubjectsDescAr = "اللغات الأجنبية (معامل 5) • الأدب العربي (5) • الفلسفة (2)",
        mainSubjectsDescFr = "Langues Étrangères (Coeff 5) • Arabe (5) • Philosophie (2)"
    );

    companion object {
        fun fromId(id: String): AcademicStream = entries.find { it.id == id } ?: SCIENCES_EXP
    }
}

enum class QuestionType(val id: String, val labelAr: String, val labelFr: String) {
    SINGLE_CHOICE("SINGLE_CHOICE", "اختيار من متعدد (إجابة واحدة)", "Choix unique (QCM)"),
    MULTIPLE_CHOICE("MULTIPLE_CHOICE", "اختيار متعدد (عدة إجابات)", "Choix multiples"),
    TRUE_FALSE("TRUE_FALSE", "صحيح أو خطأ مع التعليل", "Vrai ou Faux"),
    STRUCTURED("STRUCTURED", "سؤال مهيكل (نموذج البكالوريا)", "Question structurée (Type Bac)");

    companion object {
        fun fromId(id: String): QuestionType = entries.find { it.id == id } ?: SINGLE_CHOICE
    }
}

enum class DifficultyLevel(
    val id: String,
    val labelAr: String,
    val labelFr: String,
    val pointsWeight: Int
) {
    EASY("EASY", "أساسي", "Fondamental", 1),
    MEDIUM("MEDIUM", "متوسط", "Intermédiaire", 2),
    HARD("HARD", "متقدم", "Avancé", 3),
    BAC_LEVEL("BAC_LEVEL", "مستوى بكالوريا امتحاني", "Niveau Examen Bac", 4);

    companion object {
        fun fromId(id: String): DifficultyLevel = entries.find { it.id == id } ?: MEDIUM
    }
}

enum class QuestionProvenance(
    val id: String,
    val badgeAr: String,
    val badgeFr: String,
    val disclaimerAr: String,
    val disclaimerFr: String
) {
    CURRICULUM_VERIFIED(
        id = "CURRICULUM_VERIFIED",
        badgeAr = "مُراجع وفق المنهاج الرسمي",
        badgeFr = "Vérifié conforme au programme officiel",
        disclaimerAr = "سؤال تدريبي مُتحقق منه ومطابق للتدرج السنوي الرسمي لوزارة التربية الوطنية.",
        disclaimerFr = "Question d'entraînement vérifiée conforme à la progression officielle."
    ),
    AI_GENERATED_PRACTICE(
        id = "AI_GENERATED_PRACTICE",
        badgeAr = "تدريب مولّد بالذكاء الاصطناعي (غير رسمي)",
        badgeFr = "Exercice généré par IA (Non officiel)",
        disclaimerAr = "محتوى تدريبي مولّد آلياً للمراجعة الإضافية — ليس موضوع بكالوريا رسمي.",
        disclaimerFr = "Contenu d'entraînement généré par IA — ne constitue pas un sujet officiel du Bac."
    ),
    TEACHER_SUBMITTED(
        id = "TEACHER_SUBMITTED",
        badgeAr = "مُقترح أستاذ / مجتمع المراجعة",
        badgeFr = "Proposé par un enseignant / communauté",
        disclaimerAr = "سؤال مقترح من بنك المساهمات التعليمية.",
        disclaimerFr = "Question proposée issue de la banque collaborative."
    );

    companion object {
        fun fromId(id: String): QuestionProvenance = entries.find { it.id == id } ?: CURRICULUM_VERIFIED
    }
}

enum class SubscriptionTier(
    val id: String,
    val titleAr: String,
    val titleFr: String,
    val dailyQuizLimit: Int,
    val dailyAiLimit: Int
) {
    FREE("FREE", "الباقة المجانية", "Offre Gratuite", 3, 3),
    PREMIUM_MONTHLY("PREMIUM_MONTHLY", "باقة الامتياز الشهرية", "BacMate Pro Mensuel", 100, 50),
    PREMIUM_ANNUAL("PREMIUM_ANNUAL", "باقة الامتياز السنوية (دفعة البكالوريا)", "BacMate Pro Annuel", 100, 100);

    val isPremium: Boolean get() = this != FREE

    companion object {
        fun fromId(id: String): SubscriptionTier = entries.find { it.id == id } ?: FREE
    }
}

enum class AiTutorMode(
    val id: String,
    val labelAr: String,
    val labelFr: String
) {
    HINT("HINT", "تلميح منهجي (بدون حرق الحل)", "Indice méthodologique"),
    STEP_BY_STEP("STEP_BY_STEP", "شرح مبسط خطوة بخطوة", "Explication étape par étape"),
    WORKED_EXAMPLE("WORKED_EXAMPLE", "مثال تطبيقي محلول", "Exemple corrigé"),
    FOLLOW_UP("FOLLOW_UP", "سؤال تدريبي متابع", "Question de suivi")
}

data class Lesson(
    val id: String,
    val subjectId: String,
    val unitNumber: Int,
    val titleAr: String,
    val titleFr: String,
    val curriculumCompetencyAr: String,
    val curriculumCompetencyFr: String,
    val summaryPointsAr: List<String>,
    val summaryPointsFr: List<String>,
    val keyFormulas: List<String>,
    val estimatedMinutes: Int,
    val trimester: Int = 1,
    val scheduleTimelineAr: String = "الفصل الأول • سبتمبر – ديسمبر",
    val scheduleTimelineFr: String = "Trimestre 1 • Sept – Déc",
    val progressionPercentage: Int = 20
)

data class Subject(
    val id: String,
    val nameAr: String,
    val nameFr: String,
    val coefficientsByStream: Map<AcademicStream, Int>,
    val accentHex: Long,
    val lessons: List<Lesson>
) {
    fun coefficientFor(stream: AcademicStream): Int = coefficientsByStream[stream] ?: 2
}

data class Question(
    val id: String,
    val subjectId: String,
    val lessonId: String,
    val streams: List<AcademicStream>,
    val type: QuestionType,
    val difficulty: DifficultyLevel,
    val provenance: QuestionProvenance,
    val sourceCitationAr: String,
    val sourceCitationFr: String,
    val curriculumMappingAr: String,
    val curriculumMappingFr: String,
    val stemAr: String,
    val stemFr: String,
    val optionsAr: List<String>,
    val optionsFr: List<String>,
    val correctIndices: List<Int>,
    val structuredRubricStepsAr: List<String> = emptyList(),
    val structuredRubricStepsFr: List<String> = emptyList(),
    val explanationAr: String,
    val explanationFr: String
) {
    val pedagogicalHintAr: String
        get() = structuredRubricStepsAr.firstOrNull()
            ?: "تلميح منهجي: راجع الكفاءة المستهدفة في ($curriculumMappingAr) وطبق العلاقة الأساسية قبل تعويض القيم العددية."

    val pedagogicalHintFr: String
        get() = structuredRubricStepsFr.firstOrNull()
            ?: "Indice : Mobilisez la compétence ($curriculumMappingFr) et vérifiez l'homogénéité de la formule avant application numérique."

    fun distractorAnalysisAr(selectedIndices: Set<Int>): String {
        val wrongSelected = selectedIndices.filter { it !in correctIndices }
        return if (wrongSelected.isEmpty()) {
            "إجابتك مطابقة تماماً للحل النموذجي. استبعدتَ المشتتات الخاطئة التي تعتمد على عكس الإشارة أو الخلط بين الشروط الابتدائية والنهائية."
        } else {
            val chosenLabels = wrongSelected.mapNotNull { idx -> optionsAr.getOrNull(idx)?.let { "الخيار (${idx + 1}: $it)" } }
            "سبب خطأ ${chosenLabels.joinToString("، ")}: هذا الخيار يمثل خطأً شائعاً في البكالوريا ينتج عن إهمال شروط تطبيق القانون أو الخلط بين المتغير والوسيط في ($curriculumMappingAr)."
        }
    }

    fun distractorAnalysisFr(selectedIndices: Set<Int>): String {
        val wrongSelected = selectedIndices.filter { it !in correctIndices }
        return if (wrongSelected.isEmpty()) {
            "Réponse exacte. Vous avez évité les distracteurs liés aux erreurs de signe ou aux conditions aux limites."
        } else {
            val chosenLabels = wrongSelected.mapNotNull { idx -> optionsFr.getOrNull(idx)?.let { "Choix (${idx + 1})" } }
            "Analyse de l'erreur sur ${chosenLabels.joinToString(", ")} : Ce distracteur correspond à une confusion fréquente sur les hypothèses du cours ($curriculumMappingFr)."
        }
    }
}

enum class WeaknessStatus {
    INSUFFICIENT_DATA, // < 3 questions answered
    CRITICAL_WEAKNESS, // < 50% accuracy with >= 3 questions
    NEEDS_PRACTICE,    // 50%..69% accuracy with >= 3 questions
    MASTERED           // >= 70% accuracy with >= 3 questions
}

data class TopicWeaknessInsight(
    val subjectId: String,
    val subjectNameAr: String,
    val subjectNameFr: String,
    val lessonId: String?,
    val lessonTitleAr: String,
    val lessonTitleFr: String,
    val attemptsCount: Int,
    val totalQuestionsAnswered: Int,
    val accuracyPercent: Int,
    val repeatMistakesCount: Int,
    val status: WeaknessStatus,
    val recommendationAr: String,
    val recommendationFr: String
)

data class AchievementBadge(
    val id: String,
    val titleAr: String,
    val titleFr: String,
    val descriptionAr: String,
    val descriptionFr: String,
    val unlocked: Boolean,
    val progressText: String
)

// ---------------------------------------------------------------------------
// Firestore Persistent Models (Strict @IgnoreExtraProperties & @DocumentId)
// ---------------------------------------------------------------------------

@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val displayName: String = "طالب البكالوريا",
    val examYear: Int = 2026,
    val academicStream: String = AcademicStream.SCIENCES_EXP.id,
    val language: String = AppLanguage.AR.code,
    val dailyGoalMinutes: Int = 60,
    val studyMinutesToday: Int = 0,
    val streakDays: Int = 1,
    val totalQuizzesCompleted: Int = 0,
    val totalQuestionsAnswered: Int = 0,
    val totalCorrectAnswers: Int = 0,
    val dailyQuizzesUsedToday: Int = 0,
    val dailyAiRequestsUsedToday: Int = 0,
    val lastActiveDate: String = "2026-10-23",
    val subscriptionTier: String = SubscriptionTier.FREE.id,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class QuizAttempt(
    @DocumentId val id: String = "",
    val userId: String = "",
    val subjectId: String = "",
    val lessonId: String = "",
    val mode: String = "PRACTICE",
    val scorePercent: Int = 0,
    val bacScoreTimes10: Int = 0,
    val totalQuestions: Int = 1,
    val correctCount: Int = 0,
    val durationSeconds: Int = 0,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    val bacGradeFormatted: String
        get() = String.format(java.util.Locale.US, "%.1f / 20", bacScoreTimes10 / 10.0)
}

@IgnoreExtraProperties
data class ReviewItem(
    @DocumentId val id: String = "",
    val userId: String = "",
    val questionId: String = "",
    val subjectId: String = "",
    val lessonId: String = "",
    val mistakeCount: Int = 1,
    val repetitionCount: Int = 0,
    val intervalDays: Int = 1,
    val easeFactorPermille: Int = 2500,
    val nextReviewEpochDay: Int = 0,
    val personalNote: String = "",
    val mastered: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class StudyTask(
    @DocumentId val id: String = "",
    val userId: String = "",
    val title: String = "",
    val subjectId: String = "math",
    val dayOfWeek: String = "SUN",
    val durationMinutes: Int = 45,
    val completed: Boolean = false,
    val priority: String = "HIGH",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class CommunityQuestion(
    @DocumentId val id: String = "",
    val authorId: String = "",
    val subjectId: String = "math",
    val lessonId: String = "math_limits",
    val stream: String = AcademicStream.SCIENCES_EXP.id,
    val questionType: String = QuestionType.SINGLE_CHOICE.id,
    val difficulty: String = DifficultyLevel.BAC_LEVEL.id,
    val provenance: String = QuestionProvenance.TEACHER_SUBMITTED.id,
    val sourceCitation: String = "",
    val curriculumMapping: String = "",
    val stemAr: String = "",
    val stemFr: String = "",
    val optionsAr: List<String> = emptyList(),
    val optionsFr: List<String> = emptyList(),
    val correctIndices: List<Int> = listOf(0),
    val explanationAr: String = "",
    val explanationFr: String = "",
    val reviewStatus: String = "PENDING_REVIEW",
    val reviewerNote: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun toDomainQuestion(): Question {
        val streamEnum = AcademicStream.fromId(stream)
        return Question(
            id = id.ifBlank { "comm_${stemAr.hashCode()}" },
            subjectId = subjectId,
            lessonId = lessonId,
            streams = listOf(streamEnum),
            type = QuestionType.fromId(questionType),
            difficulty = DifficultyLevel.fromId(difficulty),
            provenance = QuestionProvenance.fromId(provenance),
            sourceCitationAr = sourceCitation,
            sourceCitationFr = sourceCitation,
            curriculumMappingAr = curriculumMapping,
            curriculumMappingFr = curriculumMapping,
            stemAr = stemAr,
            stemFr = stemFr.ifBlank { stemAr },
            optionsAr = optionsAr,
            optionsFr = optionsFr.ifEmpty { optionsAr },
            correctIndices = correctIndices,
            explanationAr = explanationAr,
            explanationFr = explanationFr.ifBlank { explanationAr }
        )
    }
}

/**
 * SuperMemo-2 (SM-2) Spaced Repetition scheduler for Baccalaureate Error Notebook.
 * @param quality 0..5 (0..2 = forgot/hard retry, 3 = recalled with effort, 4 = good, 5 = easy)
 */
object SpacedRepetitionSm2 {
    fun computeNextReview(
        current: ReviewItem?,
        userId: String,
        question: Question,
        quality: Int,
        todayEpochDay: Int = LocalDate.now().toEpochDay().toInt(),
        noteOverride: String? = null
    ): ReviewItem {
        val prevReps = current?.repetitionCount ?: 0
        val prevInterval = current?.intervalDays ?: 1
        val prevEase = current?.easeFactorPermille ?: 2500
        val prevMistakes = current?.mistakeCount ?: 0

        val q = quality.coerceIn(0, 5)
        val newMistakes = if (q < 3) prevMistakes + 1 else max(1, prevMistakes)

        val (newReps, newInterval) = if (q < 3) {
            0 to 1
        } else {
            val nextReps = prevReps + 1
            val nextInt = when (nextReps) {
                1 -> 1
                2 -> 3
                else -> ((prevInterval * (prevEase / 1000.0)).roundToInt()).coerceIn(4, 180)
            }
            nextReps to nextInt
        }

        // EF' = EF + (0.1 - (5 - q) * (0.08 + (5 - q) * 0.02))
        val deltaPermille = ((0.1 - (5 - q) * (0.08 + (5 - q) * 0.02)) * 1000).roundToInt()
        val newEase = (prevEase + deltaPermille).coerceIn(1300, 3500)
        val mastered = newReps >= 3 && q >= 4

        return ReviewItem(
            id = question.id,
            userId = userId,
            questionId = question.id,
            subjectId = question.subjectId,
            lessonId = question.lessonId,
            mistakeCount = newMistakes,
            repetitionCount = newReps,
            intervalDays = newInterval,
            easeFactorPermille = newEase,
            nextReviewEpochDay = todayEpochDay + newInterval,
            personalNote = noteOverride ?: current?.personalNote.orEmpty(),
            mastered = mastered,
            createdAt = current?.createdAt,
            updatedAt = null
        )
    }

    /**
     * Marks a ReviewItem as mastered by the student while scheduling a periodic retention check
     * 14 days out so mastered concepts are still occasionally reviewed.
     */
    fun markAsMasteredWithPeriodicReview(
        current: ReviewItem?,
        userId: String,
        question: Question,
        todayEpochDay: Int = LocalDate.now().toEpochDay().toInt()
    ): ReviewItem {
        val interval = max(14, (current?.intervalDays ?: 7) * 2).coerceAtMost(90)
        return ReviewItem(
            id = question.id,
            userId = userId,
            questionId = question.id,
            subjectId = question.subjectId,
            lessonId = question.lessonId,
            mistakeCount = current?.mistakeCount ?: 1,
            repetitionCount = max(3, (current?.repetitionCount ?: 2) + 1),
            intervalDays = interval,
            easeFactorPermille = (current?.easeFactorPermille ?: 2500).coerceIn(1300, 3500),
            nextReviewEpochDay = todayEpochDay + interval,
            personalNote = current?.personalNote.orEmpty(),
            mastered = true,
            createdAt = current?.createdAt,
            updatedAt = null
        )
    }
}

/**
 * Pure domain analytics engine for Daily Challenge generation, Weakness Analysis
 * (distinguishing low sample size from confirmed weakness), and Achievement Badges.
 */
object BacAnalyticsEngine {

    fun dailyChallengeIdForDate(date: LocalDate = LocalDate.now()): String =
        "daily_challenge_$date"

    /**
     * Generates a deterministic 7-question Daily Challenge for a given date and stream
     * so all students in the same stream get the exact same comparable question set.
     */
    fun getDailyChallengeQuestions(
        stream: AcademicStream,
        allQuestions: List<Question>,
        difficultyFilter: DifficultyLevel? = null,
        date: LocalDate = LocalDate.now(),
        count: Int = 7
    ): List<Question> {
        val streamPool = allQuestions.filter { stream in it.streams }
            .let { pool ->
                if (difficultyFilter != null) pool.filter { it.difficulty == difficultyFilter }.ifEmpty { pool }
                else pool
            }
            .sortedBy { it.id }

        if (streamPool.size <= count) return streamPool

        val seed = date.toEpochDay() * 31L + stream.ordinal * 997L
        val rng = java.util.Random(seed)
        val indices = streamPool.indices.toMutableList()
        java.util.Collections.shuffle(indices, rng)
        return indices.take(count).map { streamPool[it] }
    }

    /**
     * Analyzes real quiz attempts and error notebook items by subject and unit.
     * Explicitly separates INSUFFICIENT_DATA (< 3 questions answered) from confirmed weakness.
     */
    fun analyzeWeaknesses(
        stream: AcademicStream,
        subjects: List<Subject>,
        attempts: List<QuizAttempt>,
        reviews: List<ReviewItem>
    ): List<TopicWeaknessInsight> {
        val insights = mutableListOf<TopicWeaknessInsight>()

        subjects.forEach { subject ->
            val subjAttempts = attempts.filter { it.subjectId == subject.id }
            val totalQ = subjAttempts.sumOf { it.totalQuestions }
            val totalCorrect = subjAttempts.sumOf { it.correctCount }
            val subjReviews = reviews.filter { it.subjectId == subject.id && !it.mastered }
            val repeatMistakes = subjReviews.sumOf { it.mistakeCount }
            val accuracy = if (totalQ > 0) ((totalCorrect * 100.0) / totalQ).roundToInt().coerceIn(0, 100) else 0

            val status = when {
                totalQ < 3 -> WeaknessStatus.INSUFFICIENT_DATA
                accuracy < 50 || repeatMistakes >= 4 -> WeaknessStatus.CRITICAL_WEAKNESS
                accuracy < 70 -> WeaknessStatus.NEEDS_PRACTICE
                else -> WeaknessStatus.MASTERED
            }

            val recAr = when (status) {
                WeaknessStatus.INSUFFICIENT_DATA ->
                    "بيانات غير كافية بعد ($totalQ أسئلة مجابة). أنجز اختباراً قصيراً (5–10 أسئلة) لتشخيص مستواك الفعلي في ${subject.nameAr}."
                WeaknessStatus.CRITICAL_WEAKNESS ->
                    "أولوية قصوى للمراجعة (الدقة $accuracy%، أخطاء متكررة: $repeatMistakes). نوصي بمراجعة ملخص القوانين ثم حل سلسلة الوحدة الأولى بالتدرج."
                WeaknessStatus.NEEDS_PRACTICE ->
                    "أداء متوسط ($accuracy%). ركز على الأسئلة المهيكلة وتجنب الأخطاء الحسابية في كراس الأخطاء."
                WeaknessStatus.MASTERED ->
                    "إتقان جيد ($accuracy%). حافظ على جاهزيتك عبر امتحان مؤقت أسبوعي ومراجعة دورية متباعدة."
            }

            val recFr = when (status) {
                WeaknessStatus.INSUFFICIENT_DATA ->
                    "Données insuffisantes ($totalQ questions). Complétez au moins 3 questions pour un diagnostic fiable."
                WeaknessStatus.CRITICAL_WEAKNESS ->
                    "Priorité élevée ($accuracy% de réussite, $repeatMistakes erreurs). Révisez le résumé de cours et lancez un quiz ciblé."
                WeaknessStatus.NEEDS_PRACTICE ->
                    "Performance intermédiaire ($accuracy%). Consolidez avec le carnet d'erreurs SM-2."
                WeaknessStatus.MASTERED ->
                    "Bonne maîtrise ($accuracy%). Maintenez le rythme avec un examen blanc."
            }

            insights.add(
                TopicWeaknessInsight(
                    subjectId = subject.id,
                    subjectNameAr = subject.nameAr,
                    subjectNameFr = subject.nameFr,
                    lessonId = subject.lessons.firstOrNull()?.id,
                    lessonTitleAr = subject.lessons.firstOrNull()?.titleAr ?: subject.nameAr,
                    lessonTitleFr = subject.lessons.firstOrNull()?.titleFr ?: subject.nameFr,
                    attemptsCount = subjAttempts.size,
                    totalQuestionsAnswered = totalQ,
                    accuracyPercent = accuracy,
                    repeatMistakesCount = repeatMistakes,
                    status = status,
                    recommendationAr = recAr,
                    recommendationFr = recFr
                )
            )
        }

        // Order: Critical Weaknesses first, then Needs Practice, Insufficient Data, Mastered
        return insights.sortedBy {
            when (it.status) {
                WeaknessStatus.CRITICAL_WEAKNESS -> 0
                WeaknessStatus.NEEDS_PRACTICE -> 1
                WeaknessStatus.INSUFFICIENT_DATA -> 2
                WeaknessStatus.MASTERED -> 3
            }
        }
    }

    fun computeAchievements(
        profile: UserProfile,
        attempts: List<QuizAttempt>,
        reviews: List<ReviewItem>,
        tasks: List<StudyTask>
    ): List<AchievementBadge> {
        val dailyChallengeDone = attempts.any { it.lessonId.startsWith("daily_challenge_") }
        val masteredCount = reviews.count { it.mastered }
        val completedTasksCount = tasks.count { it.completed }
        val highMockExam = attempts.any { it.mode == "TIMED_EXAM" && it.totalQuestions >= 5 && it.bacScoreTimes10 >= 140 }

        return listOf(
            AchievementBadge(
                id = "first_diagnostic",
                titleAr = "وسام الانطلاقة المنهجية",
                titleFr = "Premier Diagnostic",
                descriptionAr = "إتمام أول كويز تدريبي والتحقق من الإجابات بالتعليل العلمي.",
                descriptionFr = "Terminer un premier quiz d'entraînement vérifié.",
                unlocked = attempts.isNotEmpty(),
                progressText = "${attempts.size.coerceAtMost(1)} / 1"
            ),
            AchievementBadge(
                id = "daily_challenger",
                titleAr = "بطل التحدي اليومي",
                titleFr = "Champion du Défi Quotidien",
                descriptionAr = "إنجاز التحدي اليومي الموحد لشعبتك بنجاح.",
                descriptionFr = "Compléter le défi quotidien officiel de votre filière.",
                unlocked = dailyChallengeDone,
                progressText = if (dailyChallengeDone) "مكتمل ✓" else "0 / 1"
            ),
            AchievementBadge(
                id = "error_conqueror",
                titleAr = "قاهر الأخطاء المتكررة (SM-2)",
                titleFr = "Maître SM-2",
                descriptionAr = "تحويل 3 أسئلة على الأقل في كراس الأخطاء إلى درجة الإتقان.",
                descriptionFr = "Maîtriser au moins 3 questions du carnet d'erreurs.",
                unlocked = masteredCount >= 3,
                progressText = "${masteredCount.coerceAtMost(3)} / 3"
            ),
            AchievementBadge(
                id = "mock_exam_honors",
                titleAr = "وسام الامتياز في الامتحان التجريبي",
                titleFr = "Mention Bien à l'Examen Blanc",
                descriptionAr = "تحقيق معدل 14/20 أو أكثر في امتحان بكالوريا مؤقت.",
                descriptionFr = "Obtenir ≥ 14/20 lors d'un examen blanc chronométré.",
                unlocked = highMockExam,
                progressText = if (highMockExam) "مكتمل ✓" else "الهدف ≥ 14/20"
            ),
            AchievementBadge(
                id = "planner_consistency",
                titleAr = "وسام الانضباط الأسبوعي",
                titleFr = "Discipline Hebdomadaire",
                descriptionAr = "إنجاز 3 حصص مراجعة مبرمجة في المخطط الدراسي.",
                descriptionFr = "Compléter 3 séances du planning de révision.",
                unlocked = completedTasksCount >= 3,
                progressText = "${completedTasksCount.coerceAtMost(3)} / 3"
            )
        )
    }
}
