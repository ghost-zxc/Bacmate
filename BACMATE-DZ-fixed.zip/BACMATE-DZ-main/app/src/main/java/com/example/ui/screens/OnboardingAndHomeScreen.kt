package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.FormatListBulleted
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.AcademicStream
import com.example.data.model.AppLanguage
import com.example.data.model.DifficultyLevel
import com.example.data.model.QuizAttempt
import com.example.data.model.ReviewItem
import com.example.data.model.StudyTask
import com.example.data.model.Subject
import com.example.data.model.SubscriptionTier
import com.example.data.model.UserProfile
import com.example.data.seed.AlgerianCurriculumSeed
import com.example.data.seed.BacQuestionBankGenerator
import java.time.LocalDate
import java.time.temporal.ChronoUnit

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun OnboardingWizardScreen(
    defaultName: String,
    isArabic: Boolean,
    onComplete: (String, Int, AcademicStream, AppLanguage, Int) -> Unit
) {
    var displayName by remember { mutableStateOf(defaultName.ifBlank { "طالب البكالوريا" }) }
    var selectedYear by remember { mutableIntStateOf(2027) }
    var selectedStream by remember { mutableStateOf(AcademicStream.SCIENCES_EXP) }
    var selectedLanguage by remember { mutableStateOf(if (isArabic) AppLanguage.AR else AppLanguage.FR) }
    var dailyGoal by remember { mutableIntStateOf(60) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = if (isArabic) "إعداد ملف المترشح لبكالوريا الجزائر" else "Configuration du profil Candidat Bac DZ",
                style = MaterialTheme.typography.headlineLarge,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = if (isArabic) {
                    "خصّص التطبيق حسب شعبتك الرسمية ومعاملات موادك للتدرب على أكثر من 1,125 سؤالاً مرتباً بالتدرج السنوي."
                } else {
                    "Personnalisez votre parcours selon votre filière officielle (+1 125 questions ordonnées)."
                },
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        item {
            OutlinedTextField(
                value = displayName,
                onValueChange = { displayName = it },
                label = { Text(if (isArabic) "الاسم أو اللقب الدراسي" else "Nom de l'étudiant") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("onboarding_name_input")
            )
        }

        item {
            Text(
                text = if (isArabic) "دورة البكالوريا المستهدفة" else "Session du Baccalauréat",
                style = MaterialTheme.typography.titleMedium
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                listOf(2026, 2027, 2028).forEach { year ->
                    FilterChip(
                        selected = selectedYear == year,
                        onClick = { selectedYear = year },
                        label = { Text("BAC $year") },
                        modifier = Modifier.testTag("onboarding_year_$year")
                    )
                }
            }
        }

        item {
            Text(
                text = if (isArabic) "الشعبة الدراسية الرسمية (وزارة التربية الوطنية)" else "Filière officielle du Baccalauréat",
                style = MaterialTheme.typography.titleMedium
            )
            Spacer(modifier = Modifier.height(8.dp))
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                AcademicStream.entries.forEach { stream ->
                    val isSelected = selectedStream == stream
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedStream = stream }
                            .testTag("onboarding_stream_${stream.id}"),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) {
                                MaterialTheme.colorScheme.primaryContainer
                            } else {
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)
                            }
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (isSelected) Icons.Default.CheckCircle else Icons.Default.School,
                                contentDescription = null,
                                tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${stream.titleAr} • ${stream.titleFr}",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (isArabic) stream.mainSubjectsDescAr else stream.mainSubjectsDescFr,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            Text(
                text = if (isArabic) "الهدف اليومي للمراجعة (بالدقائق)" else "Objectif quotidien d'étude (minutes)",
                style = MaterialTheme.typography.titleMedium
            )
            Spacer(modifier = Modifier.height(8.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(30, 45, 60, 90, 120).forEach { mins ->
                    FilterChip(
                        selected = dailyGoal == mins,
                        onClick = { dailyGoal = mins },
                        label = { Text(if (isArabic) "$mins د / يوم" else "$mins min / jour") }
                    )
                }
            }
        }

        item {
            Text(
                text = if (isArabic) "لغة الواجهة والدراسة" else "Langue de l'interface",
                style = MaterialTheme.typography.titleMedium
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                AppLanguage.entries.forEach { lang ->
                    FilterChip(
                        selected = selectedLanguage == lang,
                        onClick = { selectedLanguage = lang },
                        label = { Text("${lang.labelAr} (${lang.code})") }
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(8.dp))
            Button(
                onClick = {
                    onComplete(displayName, selectedYear, selectedStream, selectedLanguage, dailyGoal)
                },
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("onboarding_submit_button")
            ) {
                Text(
                    text = if (isArabic) "ابدأ رحلة التحضير للبكالوريا" else "Commencer la préparation au Bac",
                    style = MaterialTheme.typography.titleMedium
                )
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun HomeDashboardScreen(
    profile: UserProfile,
    attempts: List<QuizAttempt>,
    reviews: List<ReviewItem>,
    isArabic: Boolean,
    onStartPracticeQuiz: (Subject?) -> Unit,
    onStartTimedExam: (Subject?) -> Unit,
    onStartSpacedReview: () -> Unit,
    onNavigateToSubjects: () -> Unit,
    onNavigateToSubscription: () -> Unit,
    onStartUnitPracticeQuiz: (Subject, String?) -> Unit = { s, _ -> onStartPracticeQuiz(s) },
    onStartUnitTimedExam: (Subject, String?) -> Unit = { s, _ -> onStartTimedExam(s) },
    onStartDailyChallenge: (DifficultyLevel?) -> Unit = { onStartPracticeQuiz(null) },
    onNavigateToRevision: () -> Unit = onStartSpacedReview,
    onNavigateToPlanner: () -> Unit = onNavigateToSubjects,
    tasks: List<StudyTask> = emptyList()
) {
    val stream = AcademicStream.fromId(profile.academicStream)
    val subjects = remember(stream) { AlgerianCurriculumSeed.subjectsForStream(stream) }
    val dueReviews = remember(reviews) { reviews.filter { !it.mastered } }
    val tier = SubscriptionTier.fromId(profile.subscriptionTier)
    val totalBankQuestions = remember { AlgerianCurriculumSeed.verifiedQuestions.size }

    // Interactive Unit Selector state on Home screen
    var pickerSubjectId by rememberSaveable(stream.id) {
        mutableStateOf(subjects.firstOrNull()?.id ?: "svt")
    }
    val pickerSubject = remember(subjects, pickerSubjectId) {
        subjects.find { it.id == pickerSubjectId } ?: subjects.first()
    }
    val orderedUnits = remember(pickerSubject) {
        pickerSubject.lessons.sortedBy { it.unitNumber }
    }
    // null means "All Units in Sequential Order (Unit 01 -> Last Unit)"
    var pickerLessonId by rememberSaveable(pickerSubject.id) {
        mutableStateOf<String?>(orderedUnits.firstOrNull()?.id)
    }
    val selectedLessonObj = remember(orderedUnits, pickerLessonId) {
        orderedUnits.find { it.id == pickerLessonId }
    }

    // Days until June 15 of target Bac exam year
    val daysUntilBac = remember(profile.examYear) {
        val targetDate = LocalDate.of(profile.examYear.coerceAtLeast(2027), 6, 15)
        ChronoUnit.DAYS.between(LocalDate.now(), targetDate).coerceAtLeast(1)
    }

    val averageBacOutOf20 = remember(attempts) {
        if (attempts.isEmpty()) 0.0 else attempts.map { it.bacScoreTimes10 / 10.0 }.average()
    }

    // Identify weakest subject from attempts or reviews
    val weakSubject = remember(attempts, reviews, subjects) {
        val mistakeCountsBySubject = reviews.groupBy { it.subjectId }.mapValues { entry ->
            entry.value.sumOf { it.mistakeCount }
        }
        val worstId = mistakeCountsBySubject.maxByOrNull { it.value }?.key
        subjects.find { it.id == worstId } ?: subjects.firstOrNull()
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Refined Hero Banner Card
        item {
            Spacer(modifier = Modifier.height(6.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Box {
                    Image(
                        painter = painterResource(id = R.drawable.img_bac_hero),
                        contentDescription = null,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(185.dp),
                        contentScale = ContentScale.Crop
                    )
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(185.dp)
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        MaterialTheme.colorScheme.primary.copy(alpha = 0.50f),
                                        MaterialTheme.colorScheme.primary.copy(alpha = 0.85f)
                                    )
                                )
                            )
                            .padding(20.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                color = MaterialTheme.colorScheme.secondaryContainer,
                                shape = RoundedCornerShape(50)
                            ) {
                                Text(
                                    text = if (isArabic) "شعبة ${stream.titleAr}" else stream.titleFr,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                )
                            }
                            Surface(
                                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f),
                                shape = RoundedCornerShape(50)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.LocalFireDepartment,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.secondary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (isArabic) "${profile.streakDays} يوم متواصل" else "${profile.streakDays} j de série",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }

                        Column {
                            Text(
                                text = if (isArabic) "مرحباً، ${profile.displayName}" else "Bienvenue, ${profile.displayName}",
                                style = MaterialTheme.typography.headlineMedium,
                                color = MaterialTheme.colorScheme.onPrimary,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = if (isArabic) {
                                    "متبقي $daysUntilBac يوم على بكالوريا ${profile.examYear} • بنك $totalBankQuestions سؤال مرتب من الوحدة 01 إلى الأخيرة"
                                } else {
                                    "J-$daysUntilBac avant le Bac ${profile.examYear} • Banque de $totalBankQuestions questions ordonnées"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.94f)
                            )
                        }
                    }
                }
            }
        }

        // 2. 3-Column KPI Strip (Daily Goal, Average /20, Total Ordered Questions)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ElevatedCard(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    val progress = (profile.studyMinutesToday.toFloat() / profile.dailyGoalMinutes.coerceAtLeast(1))
                        .coerceIn(0f, 1f)
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = if (isArabic) "الهدف اليومي" else "Objectif/jour",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${profile.studyMinutesToday}/${profile.dailyGoalMinutes} د",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp))
                        )
                    }
                }

                ElevatedCard(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = if (isArabic) "المعدل التقديري" else "Moyenne Bac",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = String.format(java.util.Locale.US, "%.2f / 20", averageBacOutOf20),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.secondary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isArabic) "${profile.totalQuizzesCompleted} اختبار" else "${profile.totalQuizzesCompleted} quiz",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                ElevatedCard(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = if (isArabic) "بنك الكويزات" else "Banque Quiz",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "$totalBankQuestions+",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isArabic) "${profile.totalQuestionsAnswered} سؤال مجاب" else "${profile.totalQuestionsAnswered} rép.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // 2B. Quick Actions Bar (Daily Challenge, Practice, Mock Exams, AI Tutor, Error Notebook, Study Plan, Competition)
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(vertical = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                val quickActions = listOf(
                    Triple("daily", if (isArabic) "التحدي اليومي" else "Défi du Jour", { onStartDailyChallenge(null) }),
                    Triple("practice", if (isArabic) "تدريب موجه" else "Pratique", { onStartPracticeQuiz(subjects.firstOrNull()) }),
                    Triple("mock", if (isArabic) "امتحان تجريبي" else "Examen Blanc", { onStartTimedExam(subjects.firstOrNull()) }),
                    Triple("tutor", if (isArabic) "المعلم الذكي AI" else "Tuteur IA", onNavigateToSubjects),
                    Triple("errors", if (isArabic) "كراس الأخطاء (${dueReviews.size})" else "Erreurs (${dueReviews.size})", onNavigateToRevision),
                    Triple("plan", if (isArabic) "المخطط الدراسي" else "Planning", onNavigateToPlanner),
                    Triple("comp", if (isArabic) "المنافسة والأوسمة" else "Classement", onNavigateToPlanner)
                )
                items(quickActions, key = { it.first }) { (key, label, action) ->
                    OutlinedButton(
                        onClick = action,
                        shape = RoundedCornerShape(50),
                        modifier = Modifier.testTag("home_quick_action_$key")
                    ) {
                        Text(
                            text = label,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // 2C. Daily Challenge Banner Card
        item {
            DailyChallengeBannerCard(
                stream = stream,
                attempts = attempts,
                isArabic = isArabic,
                onStartDailyChallenge = onStartDailyChallenge
            )
        }

        // 3. Dedicated Interactive Unit Selector & Ordered Quiz Launcher Card
        item {
            ElevatedCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("home_unit_selector_card"),
                shape = RoundedCornerShape(22.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.FilterList,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = if (isArabic) {
                                        "ميزة اختيار الوحدة التدريبية (مرتبة من الأولى إلى الأخيرة)"
                                    } else {
                                        "Sélection de l'Unité (Ordonnée de la 1re à la dernière)"
                                    },
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (isArabic) {
                                        "اختر المادة ثم حدد الوحدة لبدء الكويزات المرتبة حسب التوزيع السنوي الرسمي"
                                    } else {
                                        "Choisissez la matière puis l'unité pour lancer les quiz dans l'ordre officiel"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        if (!tier.isPremium) {
                            OutlinedButton(
                                onClick = onNavigateToSubscription,
                                modifier = Modifier.testTag("home_upgrade_button"),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Icon(Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(if (isArabic) "ترقية" else "Pro")
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Step 1: Subject Selector Row
                    Text(
                        text = if (isArabic) "1. اختر المادة:" else "1. Choisissez la matière :",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(subjects, key = { it.id }) { subj ->
                            val isSelected = subj.id == pickerSubject.id
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    pickerSubjectId = subj.id
                                    pickerLessonId = subj.lessons.minByOrNull { it.unitNumber }?.id
                                },
                                label = {
                                    Text(
                                        text = if (isArabic) {
                                            "${subj.nameAr} (معامل ${subj.coefficientFor(stream)})"
                                        } else {
                                            "${subj.nameFr} (Coeff ${subj.coefficientFor(stream)})"
                                        }
                                    )
                                },
                                modifier = Modifier.testTag("home_picker_subject_${subj.id}")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Step 2: Unit Selector Row (Ordered Unit 01 -> Last Unit + All Units Ordered)
                    Text(
                        text = if (isArabic) {
                            "2. اختر الوحدة من التوزيع السنوي (${orderedUnits.size} وحدات متسلسلة):"
                        } else {
                            "2. Choisissez l'unité (${orderedUnits.size} unités dans l'ordre) :"
                        },
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        item {
                            FilterChip(
                                selected = pickerLessonId == null,
                                onClick = { pickerLessonId = null },
                                label = {
                                    Text(
                                        if (isArabic) {
                                            "كل الوحدات بالترتيب (01 ← 0${orderedUnits.size}) • ${orderedUnits.size * BacQuestionBankGenerator.QUESTIONS_PER_UNIT} سؤال"
                                        } else {
                                            "Toutes les unités (01 → 0${orderedUnits.size}) • ${orderedUnits.size * BacQuestionBankGenerator.QUESTIONS_PER_UNIT} Q"
                                        }
                                    )
                                },
                                modifier = Modifier.testTag("home_picker_unit_all")
                            )
                        }
                        items(orderedUnits, key = { it.id }) { unit ->
                            val isUnitSelected = pickerLessonId == unit.id
                            FilterChip(
                                selected = isUnitSelected,
                                onClick = { pickerLessonId = unit.id },
                                label = {
                                    Text(
                                        if (isArabic) {
                                            "الوحدة 0${unit.unitNumber}: ${unit.titleAr} (${BacQuestionBankGenerator.QUESTIONS_PER_UNIT} س)"
                                        } else {
                                            "Unité 0${unit.unitNumber} : ${unit.titleFr} (${BacQuestionBankGenerator.QUESTIONS_PER_UNIT} Q)"
                                        }
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.secondaryContainer,
                                    selectedLabelColor = MaterialTheme.colorScheme.onSecondaryContainer
                                ),
                                modifier = Modifier.testTag("home_picker_unit_${unit.id}")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Selected Unit Preview Box
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            if (selectedLessonObj != null) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = if (isArabic) {
                                            "الوحدة 0${selectedLessonObj.unitNumber}: ${selectedLessonObj.titleAr}"
                                        } else {
                                            "Unité 0${selectedLessonObj.unitNumber} : ${selectedLessonObj.titleFr}"
                                        },
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Surface(
                                        color = MaterialTheme.colorScheme.primaryContainer,
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text(
                                            text = "${selectedLessonObj.progressionPercentage}%",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = if (isArabic) {
                                        "${selectedLessonObj.scheduleTimelineAr} • ${BacQuestionBankGenerator.QUESTIONS_PER_UNIT} سؤالاً متدرجاً مع الحل المفصل"
                                    } else {
                                        "${selectedLessonObj.scheduleTimelineFr} • ${BacQuestionBankGenerator.QUESTIONS_PER_UNIT} questions corrigées"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            } else {
                                Text(
                                    text = if (isArabic) {
                                        "المسار الكامل لمادة ${pickerSubject.nameAr}: يبدأ من الوحدة 01 إلى الوحدة 0${orderedUnits.size} بالترتيب (${orderedUnits.size * BacQuestionBankGenerator.QUESTIONS_PER_UNIT} سؤالاً)"
                                    } else {
                                        "Parcours complet de ${pickerSubject.nameFr} : de l'Unité 01 à l'Unité 0${orderedUnits.size} (${orderedUnits.size * BacQuestionBankGenerator.QUESTIONS_PER_UNIT} questions)"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Launch Buttons for Selected Unit / Subject
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { onStartUnitPracticeQuiz(pickerSubject, pickerLessonId) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("home_start_practice_quiz_button"),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                if (isArabic) {
                                    if (selectedLessonObj != null) "كويز الوحدة 0${selectedLessonObj.unitNumber}"
                                    else "بدء التدرج الكامل"
                                } else {
                                    if (selectedLessonObj != null) "Quiz Unité 0${selectedLessonObj.unitNumber}"
                                    else "Quiz Complet"
                                }
                            )
                        }

                        OutlinedButton(
                            onClick = { onStartUnitTimedExam(pickerSubject, pickerLessonId) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("home_start_timed_exam_button"),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Icon(Icons.Default.Timer, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (isArabic) "امتحان مؤقت (20 س)" else "Examen (20 Q)")
                        }
                    }
                }
            }
        }

        // 4. Weak Topics & Spaced Repetition Alert Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.55f)
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.18f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (dueReviews.isNotEmpty()) Icons.Default.WarningAmber else Icons.Default.Psychology,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.secondary
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isArabic) {
                                "كراس الأخطاء والتكرار المتباعد (${dueReviews.size} للمراجعة)"
                            } else {
                                "Carnet d'erreurs & SM-2 (${dueReviews.size} à revoir)"
                            },
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isArabic) {
                                "أولوية التقوية: ${weakSubject?.nameAr ?: "علوم الطبيعة والحياة"} (المعامل ${weakSubject?.coefficientFor(stream) ?: 6})"
                            } else {
                                "Priorité : ${weakSubject?.nameFr ?: "SVT"} (Coeff ${weakSubject?.coefficientFor(stream) ?: 6})"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = onStartSpacedReview,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.testTag("home_spaced_review_button")
                    ) {
                        Text(if (isArabic) "راجع الآن" else "Réviser")
                    }
                }
            }
        }

        // 5. Subjects by Official Stream Coefficient with Direct Unit Chips
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isArabic) "التوزيع السنوي للمواد حسب المعامل" else "Matières et Progression Annuelle",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = if (isArabic) "عرض المنهاج الكامل" else "Tout le programme",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.clickable { onNavigateToSubjects() }
                )
            }
        }

        items(subjects, key = { it.id }) { subject ->
            val coeff = subject.coefficientFor(stream)
            val orderedSubjectUnits = remember(subject) { subject.lessons.sortedBy { it.unitNumber } }
            val subjectQuestionCount = orderedSubjectUnits.size * BacQuestionBankGenerator.QUESTIONS_PER_UNIT
            val subjectColor = Color(subject.accentHex)

            ElevatedCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onStartUnitPracticeQuiz(subject, null) }
                    .testTag("home_subject_card_${subject.id}"),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            color = subjectColor.copy(alpha = 0.14f),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.border(1.dp, subjectColor.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                        ) {
                            Text(
                                text = if (isArabic) "معامل $coeff" else "Coeff $coeff",
                                style = MaterialTheme.typography.labelLarge,
                                color = subjectColor,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isArabic) subject.nameAr else subject.nameFr,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (isArabic) {
                                    "${orderedSubjectUnits.size} وحدات رسمية متسلسلة • $subjectQuestionCount سؤال وجواب"
                                } else {
                                    "${orderedSubjectUnits.size} unités officielles • $subjectQuestionCount questions corrigées"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.TrendingUp,
                            contentDescription = null,
                            tint = subjectColor
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                    Spacer(modifier = Modifier.height(8.dp))

                    // Ordered Unit Pills inside each Subject Card for 1-Tap Unit Selection
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(orderedSubjectUnits, key = { it.id }) { unit ->
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable { onStartUnitPracticeQuiz(subject, unit.id) }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.FormatListBulleted,
                                        contentDescription = null,
                                        modifier = Modifier.size(14.dp),
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (isArabic) {
                                            "و0${unit.unitNumber}: ${unit.titleAr.take(22)}"
                                        } else {
                                            "U0${unit.unitNumber}: ${unit.titleFr.take(22)}"
                                        },
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // 6. Recent Attempts Summary
        if (attempts.isNotEmpty()) {
            item {
                Text(
                    text = if (isArabic) "آخر الاختبارات والامتحانات المؤقتة" else "Derniers quiz et examens blancs",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
            }
            items(attempts.take(3), key = { it.id }) { attempt ->
                val subj = subjects.find { it.id == attempt.subjectId }
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = if (isArabic) (subj?.nameAr ?: attempt.subjectId) else (subj?.nameFr ?: attempt.subjectId),
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${attempt.mode} • ${attempt.correctCount}/${attempt.totalQuestions}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(
                                text = attempt.bacGradeFormatted,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}
