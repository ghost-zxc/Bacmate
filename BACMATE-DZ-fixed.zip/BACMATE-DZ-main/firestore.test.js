const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_student_1";
const BOB_UID = "bob_student_2";
const ADMIN_EMAIL = "younesdjeridane@gmail.com";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

function validProfilePayload(uid, now) {
  return {
    userId: uid,
    displayName: "أمين بن علي",
    examYear: 2026,
    academicStream: "SCIENCES_EXP",
    language: "AR",
    dailyGoalMinutes: 60,
    studyMinutesToday: 25,
    streakDays: 4,
    totalQuizzesCompleted: 3,
    totalQuestionsAnswered: 30,
    totalCorrectAnswers: 24,
    dailyQuizzesUsedToday: 1,
    dailyAiRequestsUsedToday: 1,
    lastActiveDate: "2026-10-23",
    subscriptionTier: "FREE",
    createdAt: now,
    updatedAt: now,
  };
}

test("Unauthenticated user: cannot read or write user profiles", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).get());
});

test("Authenticated owner: can create and read own valid UserProfile", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const now = new Date();
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set(validProfilePayload(ALICE_UID, now))
  );
  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).get());
});

test("Cross-user isolation: Bob cannot read or update Alice's UserProfile", async () => {
  const now = new Date();
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    await ctx.firestore().collection("users").doc(ALICE_UID).set(validProfilePayload(ALICE_UID, now));
  });

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(bobDb.collection("users").doc(ALICE_UID).get());
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).update({ displayName: "Hacked", updatedAt: new Date() })
  );
});

test("Shadow Update Test: rejects ghost fields on UserProfile update", async () => {
  const now = new Date();
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    await ctx.firestore().collection("users").doc(ALICE_UID).set(validProfilePayload(ALICE_UID, now));
  });

  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      displayName: "أمين",
      isVerifiedAdmin: true,
      updatedAt: new Date(),
    })
  );
});

test("Subcollections: owner can create and query QuizAttempt, ReviewItem, and StudyTask", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const now = new Date();

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("attempts").doc("attempt_1").set({
      userId: ALICE_UID,
      subjectId: "math",
      lessonId: "math_limits",
      mode: "PRACTICE",
      scorePercent: 80,
      bacScoreTimes10: 160,
      totalQuestions: 5,
      correctCount: 4,
      durationSeconds: 180,
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("reviews").doc("q_math_1").set({
      userId: ALICE_UID,
      questionId: "q_math_1",
      subjectId: "math",
      lessonId: "math_limits",
      mistakeCount: 1,
      repetitionCount: 0,
      intervalDays: 1,
      easeFactorPermille: 2500,
      nextReviewEpochDay: 20750,
      personalNote: "تذكر مبرهنة الحصر",
      mastered: false,
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("studyTasks").doc("task_1").set({
      userId: ALICE_UID,
      title: "مراجعة الدوال الأسية",
      subjectId: "math",
      dayOfWeek: "SUN",
      durationMinutes: 60,
      completed: false,
      priority: "HIGH",
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).collection("attempts").get());
  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).collection("reviews").get());
  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).collection("studyTasks").get());
});

test("CommunityQuestions: Email Spoofing Test rejects unverified admin email on review approval", async () => {
  const now = new Date();
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    await ctx.firestore().collection("communityQuestions").doc("q_sub_1").set({
      authorId: ALICE_UID,
      subjectId: "physics",
      lessonId: "phys_rc",
      stream: "SCIENCES_EXP",
      questionType: "SINGLE_CHOICE",
      difficulty: "BAC_LEVEL",
      provenance: "TEACHER_SUBMITTED",
      sourceCitation: "سلسلة تمارين أستاذ الفيزياء",
      curriculumMapping: "الوحدة 03: الظواهر الكهربائية",
      stemAr: "ما هي عبارة ثابت الزمن في دارة RC؟",
      stemFr: "Quelle est l'expression de la constante de temps dans un circuit RC ?",
      optionsAr: ["τ = R.C", "τ = R/C"],
      optionsFr: ["τ = R.C", "τ = R/C"],
      correctIndices: [0],
      explanationAr: "ثابت الزمن في دارة شحن مكثفة يساوي جداء المقاومة في السعة.",
      explanationFr: "La constante de temps vaut le produit R par C.",
      reviewStatus: "PENDING_REVIEW",
      reviewerNote: "",
      createdAt: now,
      updatedAt: now,
    });
  });

  // Spoofed admin with email_verified: false MUST fail
  const spoofAdminDb = testEnv
    .authenticatedContext("spoof_uid", { email: ADMIN_EMAIL, email_verified: false })
    .firestore();
  await assertFails(
    spoofAdminDb.collection("communityQuestions").doc("q_sub_1").update({
      reviewStatus: "APPROVED",
      reviewerNote: "Spoofed approval",
      updatedAt: new Date(),
    })
  );

  // Verified admin with email_verified: true succeeds
  const realAdminDb = testEnv
    .authenticatedContext("admin_uid", { email: ADMIN_EMAIL, email_verified: true })
    .firestore();
  await assertSucceeds(
    realAdminDb.collection("communityQuestions").doc("q_sub_1").update({
      reviewStatus: "APPROVED",
      reviewerNote: "تمت المطابقة مع المنهاج الرسمي",
      updatedAt: new Date(),
    })
  );
});
